window.YTD.tweet.part0 = [ {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NPtmhfX1bK",
        "expanded_url" : "https://www.youtube.com/watch?v=cWvBjA9293I",
        "display_url" : "youtube.com/watch?v=cWvBjA…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1234914714255159296",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234914714255159296",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 03 18:53:06 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NPtmhfX1bK",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1234913368831492096/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/UAEoWrpkHp",
        "media_url" : "http://pbs.twimg.com/media/ESNLF-xUUAEUGQw.jpg",
        "id_str" : "1234913288950927361",
        "id" : "1234913288950927361",
        "media_url_https" : "https://pbs.twimg.com/media/ESNLF-xUUAEUGQw.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/UAEoWrpkHp"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1234913368831492096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234913368831492096",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 03 18:47:45 +0000 2020",
    "favorited" : false,
    "full_text" : "Nate strikes again. Deal with it! https://t.co/UAEoWrpkHp",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1234913368831492096/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/UAEoWrpkHp",
        "media_url" : "http://pbs.twimg.com/media/ESNLF-xUUAEUGQw.jpg",
        "id_str" : "1234913288950927361",
        "id" : "1234913288950927361",
        "media_url_https" : "https://pbs.twimg.com/media/ESNLF-xUUAEUGQw.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/UAEoWrpkHp"
      }, {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1234913368831492096/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/UAEoWrpkHp",
        "media_url" : "http://pbs.twimg.com/media/ESNLF_VU4AE16A3.jpg",
        "id_str" : "1234913289101959169",
        "id" : "1234913289101959169",
        "media_url_https" : "https://pbs.twimg.com/media/ESNLF_VU4AE16A3.jpg",
        "sizes" : {
          "small" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/UAEoWrpkHp"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232814214063902720/photo/1",
        "indices" : [ "55", "78" ],
        "url" : "https://t.co/oV8Liou2Mr",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERvV_WuUwAAzssl.jpg",
        "id_str" : "1232814207424315392",
        "id" : "1232814207424315392",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERvV_WuUwAAzssl.jpg",
        "sizes" : {
          "small" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/oV8Liou2Mr"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "78" ],
    "favorite_count" : "0",
    "id_str" : "1232814214063902720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232814214063902720",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 23:46:27 +0000 2020",
    "favorited" : false,
    "full_text" : "Still a civilian. Just in extraordinary circumstances. https://t.co/oV8Liou2Mr",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232814214063902720/photo/1",
        "indices" : [ "55", "78" ],
        "url" : "https://t.co/oV8Liou2Mr",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERvV_WuUwAAzssl.jpg",
        "id_str" : "1232814207424315392",
        "video_info" : {
          "aspect_ratio" : [ "1", "1" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ERvV_WuUwAAzssl.mp4"
          } ]
        },
        "id" : "1232814207424315392",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERvV_WuUwAAzssl.jpg",
        "sizes" : {
          "small" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/oV8Liou2Mr"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CsoHrDQGxq",
        "expanded_url" : "https://www.youtube.com/watch?v=pxTtbSjfKro",
        "display_url" : "youtube.com/watch?v=pxTtbS…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232773988016779266",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232773988016779266",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 21:06:37 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CsoHrDQGxq",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/bzKxvttC6m",
        "expanded_url" : "https://www.quantico.marines.mil/",
        "display_url" : "quantico.marines.mil",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232747355578830848",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232747355578830848",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:20:47 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/bzKxvttC6m",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/R9ve3exwvc",
        "expanded_url" : "https://www.youtube.com/watch?v=pCvmOCUtuPE",
        "display_url" : "youtube.com/watch?v=pCvmOC…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232746908759674881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232746908759674881",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:19:01 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/R9ve3exwvc",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LiAsa0aWmw",
        "expanded_url" : "https://www.youtube.com/watch?v=SZfa5Hsi18I",
        "display_url" : "youtube.com/watch?v=SZfa5H…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232746640450043904",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232746640450043904",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:17:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/LiAsa0aWmw",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/R6yqxBzaFo",
        "expanded_url" : "https://www.marines.mil/",
        "display_url" : "marines.mil",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1232746314909175808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232746314909175808",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:16:39 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/R6yqxBzaFo USMC",
    "lang" : "tl"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232745642427944960/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/2CAO7WRBlj",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERuXn7bUwAA0sGm.jpg",
        "id_str" : "1232745635238952960",
        "id" : "1232745635238952960",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERuXn7bUwAA0sGm.jpg",
        "sizes" : {
          "small" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/2CAO7WRBlj"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232745642427944960",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232745642427944960",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:13:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/2CAO7WRBlj",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232745642427944960/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/2CAO7WRBlj",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERuXn7bUwAA0sGm.jpg",
        "id_str" : "1232745635238952960",
        "video_info" : {
          "aspect_ratio" : [ "240", "101" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ERuXn7bUwAA0sGm.mp4"
          } ]
        },
        "id" : "1232745635238952960",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERuXn7bUwAA0sGm.jpg",
        "sizes" : {
          "small" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "202",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/2CAO7WRBlj"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ONUL7ADcXh",
        "expanded_url" : "https://www.youtube.com/watch?v=0ZqP8moItcc",
        "display_url" : "youtube.com/watch?v=0ZqP8m…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232745263728431106",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232745263728431106",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:12:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ONUL7ADcXh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232744536553619456/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/3hkJJsJa1w",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERuWngRU4AAnknS.jpg",
        "id_str" : "1232744528437633024",
        "id" : "1232744528437633024",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERuWngRU4AAnknS.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3hkJJsJa1w"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232744536553619456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232744536553619456",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 19:09:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3hkJJsJa1w",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232744536553619456/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/3hkJJsJa1w",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ERuWngRU4AAnknS.jpg",
        "id_str" : "1232744528437633024",
        "video_info" : {
          "aspect_ratio" : [ "25", "14" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ERuWngRU4AAnknS.mp4"
          } ]
        },
        "id" : "1232744528437633024",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ERuWngRU4AAnknS.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/3hkJJsJa1w"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/AmGdmEFUjO",
        "expanded_url" : "https://www.youtube.com/watch?v=Ht-wkF1TcTM",
        "display_url" : "youtube.com/watch?v=Ht-wkF…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232734835753439232",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232734835753439232",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 18:31:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/AmGdmEFUjO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/uqjdKGmlud",
        "expanded_url" : "https://www.youtube.com/watch?v=zuQK6t2Esng",
        "display_url" : "youtube.com/watch?v=zuQK6t…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232734418311110658",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232734418311110658",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 18:29:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/uqjdKGmlud",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/QITZoSKvvk",
        "expanded_url" : "https://www.youtube.com/watch?v=tRfKdNxIOcQ",
        "display_url" : "youtube.com/watch?v=tRfKdN…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232734374702960641",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232734374702960641",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 18:29:12 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/QITZoSKvvk",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/oIA6peVcw1",
        "expanded_url" : "https://www.youtube.com/watch?v=0e2kaQqxmQ0",
        "display_url" : "youtube.com/watch?v=0e2kaQ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232733883449237504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232733883449237504",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 18:27:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/oIA6peVcw1",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/WSKlfkjfUT",
        "expanded_url" : "https://music.apple.com/ca/album/decoys-like-curvers/715397242?i=715397500",
        "display_url" : "music.apple.com/ca/album/decoy…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232722424690380801",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232722424690380801",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 17:41:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/WSKlfkjfUT",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1UMM9XvRdJ",
        "expanded_url" : "https://music.apple.com/ca/album/lost-symphonies/498973058?i=498973109",
        "display_url" : "music.apple.com/ca/album/lost-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232586261635821568",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232586261635821568",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:40:39 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1UMM9XvRdJ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/QCoGZWdeQc",
        "expanded_url" : "https://music.apple.com/ca/album/forever/1451002478?i=1451002648",
        "display_url" : "music.apple.com/ca/album/forev…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232584896163373057",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232584896163373057",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:35:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/QCoGZWdeQc",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232584540373184512/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/NklJeatkhG",
        "media_url" : "http://pbs.twimg.com/media/ERsFGt1UwAInlza.jpg",
        "id_str" : "1232584535956570114",
        "id" : "1232584535956570114",
        "media_url_https" : "https://pbs.twimg.com/media/ERsFGt1UwAInlza.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          },
          "large" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          },
          "small" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NklJeatkhG"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232584540373184512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232584540373184512",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:33:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NklJeatkhG",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1232584540373184512/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/NklJeatkhG",
        "media_url" : "http://pbs.twimg.com/media/ERsFGt1UwAInlza.jpg",
        "id_str" : "1232584535956570114",
        "id" : "1232584535956570114",
        "media_url_https" : "https://pbs.twimg.com/media/ERsFGt1UwAInlza.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          },
          "large" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          },
          "small" : {
            "w" : "474",
            "h" : "316",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NklJeatkhG"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ITgWEPDLqm",
        "expanded_url" : "https://m.youtube.com/watch?v=gG_dA32oH44",
        "display_url" : "m.youtube.com/watch?v=gG_dA3…",
        "indices" : [ "62", "85" ]
      } ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1232584309246222338",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232584309246222338",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:32:54 +0000 2020",
    "favorited" : false,
    "full_text" : "Jay-Z &amp; Kanye West - Ni**as In Paris (Explicit) - YouTube https://t.co/ITgWEPDLqm",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tc9d5sm5px",
        "expanded_url" : "https://m.youtube.com/watch?v=Sdz2oW0NMFk",
        "display_url" : "m.youtube.com/watch?v=Sdz2oW…",
        "indices" : [ "49", "72" ]
      } ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "0",
    "id_str" : "1232583960569368576",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232583960569368576",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:31:31 +0000 2020",
    "favorited" : false,
    "full_text" : "Madonna - Music (Official Music Video) - YouTube https://t.co/tc9d5sm5px",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Y3udMW1ONl",
        "expanded_url" : "https://m.youtube.com/watch?v=SN6jcMruHfA",
        "display_url" : "m.youtube.com/watch?v=SN6jcM…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1232583711343837184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232583711343837184",
    "possibly_sensitive" : false,
    "created_at" : "Wed Feb 26 08:30:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Y3udMW1ONl",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "K",
        "indices" : [ "10", "12" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "98", "106" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/a415UjxqmN",
        "expanded_url" : "https://youtu.be/U1mlCPMYtPk",
        "display_url" : "youtu.be/U1mlCPMYtPk",
        "indices" : [ "70", "93" ]
      } ]
    },
    "display_text_range" : [ "0", "106" ],
    "favorite_count" : "0",
    "id_str" : "1238653987412312064",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238653987412312064",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 02:31:38 +0000 2020",
    "favorited" : false,
    "full_text" : "AMERICA F*#K YEAH! MUSIC VIDEO - Team America World Police THEME SONG https://t.co/a415UjxqmN via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "80", "88" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/F2kWD1GcVb",
        "expanded_url" : "https://youtu.be/y2GwrR-4Q9E",
        "display_url" : "youtu.be/y2GwrR-4Q9E",
        "indices" : [ "52", "75" ]
      } ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "0",
    "id_str" : "1238653577146458113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238653577146458113",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 02:30:00 +0000 2020",
    "favorited" : false,
    "full_text" : "\"Dicks, pussies and assholes\" speech - Team America https://t.co/F2kWD1GcVb via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238653244936613888/photo/1",
        "indices" : [ "3", "26" ],
        "url" : "https://t.co/wv4L4Mwzfe",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCUjnRUUAEFAUj.jpg",
        "id_str" : "1238653237084835841",
        "id" : "1238653237084835841",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCUjnRUUAEFAUj.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/wv4L4Mwzfe"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "id_str" : "1238653244936613888",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238653244936613888",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 02:28:41 +0000 2020",
    "favorited" : false,
    "full_text" : ";) https://t.co/wv4L4Mwzfe",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238653244936613888/photo/1",
        "indices" : [ "3", "26" ],
        "url" : "https://t.co/wv4L4Mwzfe",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCUjnRUUAEFAUj.jpg",
        "id_str" : "1238653237084835841",
        "video_info" : {
          "aspect_ratio" : [ "5", "4" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETCUjnRUUAEFAUj.mp4"
          } ]
        },
        "id" : "1238653237084835841",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCUjnRUUAEFAUj.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "256",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/wv4L4Mwzfe"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238653112497213440/photo/1",
        "indices" : [ "25", "48" ],
        "url" : "https://t.co/dbmHuvHxPb",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCUbxzUcAA5eU4.jpg",
        "id_str" : "1238653102472851456",
        "id" : "1238653102472851456",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCUbxzUcAA5eU4.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          },
          "large" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/dbmHuvHxPb"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "id_str" : "1238653112497213440",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238653112497213440",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 02:28:09 +0000 2020",
    "favorited" : false,
    "full_text" : "Whhhhhiiiiiiissssssssss! https://t.co/dbmHuvHxPb",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238653112497213440/photo/1",
        "indices" : [ "25", "48" ],
        "url" : "https://t.co/dbmHuvHxPb",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCUbxzUcAA5eU4.jpg",
        "id_str" : "1238653102472851456",
        "video_info" : {
          "aspect_ratio" : [ "97", "122" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETCUbxzUcAA5eU4.mp4"
          } ]
        },
        "id" : "1238653102472851456",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCUbxzUcAA5eU4.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          },
          "large" : {
            "w" : "194",
            "h" : "244",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/dbmHuvHxPb"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238640869370036224/photo/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/w6BdC61AtC",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCJTO1UYAAFfdi.jpg",
        "id_str" : "1238640861019136000",
        "id" : "1238640861019136000",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCJTO1UYAAFfdi.jpg",
        "sizes" : {
          "small" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "large" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "144",
            "h" : "144",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/w6BdC61AtC"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1238640869370036224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238640869370036224",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 01:39:30 +0000 2020",
    "favorited" : false,
    "full_text" : "Dildos or global collapse? Nbd https://t.co/w6BdC61AtC",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238640869370036224/photo/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/w6BdC61AtC",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCJTO1UYAAFfdi.jpg",
        "id_str" : "1238640861019136000",
        "video_info" : {
          "aspect_ratio" : [ "125", "72" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETCJTO1UYAAFfdi.mp4"
          } ]
        },
        "id" : "1238640861019136000",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCJTO1UYAAFfdi.jpg",
        "sizes" : {
          "small" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "large" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "144",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "144",
            "h" : "144",
            "resize" : "crop"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/w6BdC61AtC"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "57", "65" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/dXBZxdYxEQ",
        "expanded_url" : "https://youtu.be/obGEd3O1NnM",
        "display_url" : "youtu.be/obGEd3O1NnM",
        "indices" : [ "29", "52" ]
      } ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1238636960052199424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238636960052199424",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 01:23:58 +0000 2020",
    "favorited" : false,
    "full_text" : "Volumes \"Behind The Curtain\" https://t.co/dXBZxdYxEQ via @YouTube Wrar!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238622146189914112/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/q5hGTu1MaX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETB4RcSUEAAw46p.jpg",
        "id_str" : "1238622138573000704",
        "id" : "1238622138573000704",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETB4RcSUEAAw46p.jpg",
        "sizes" : {
          "small" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/q5hGTu1MaX"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1238622146189914112",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238622146189914112",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 00:25:06 +0000 2020",
    "favorited" : false,
    "full_text" : "Today. https://t.co/q5hGTu1MaX",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238622146189914112/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/q5hGTu1MaX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETB4RcSUEAAw46p.jpg",
        "id_str" : "1238622138573000704",
        "video_info" : {
          "aspect_ratio" : [ "4", "3" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETB4RcSUEAAw46p.mp4"
          } ]
        },
        "id" : "1238622138573000704",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETB4RcSUEAAw46p.jpg",
        "sizes" : {
          "small" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "200",
            "h" : "150",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/q5hGTu1MaX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238511356099170304/photo/1",
        "indices" : [ "53", "76" ],
        "url" : "https://t.co/pOzseoz507",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETATgoHUMAAL6SO.jpg",
        "id_str" : "1238511348771729408",
        "id" : "1238511348771729408",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETATgoHUMAAL6SO.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/pOzseoz507"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "76" ],
    "favorite_count" : "0",
    "id_str" : "1238511356099170304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238511356099170304",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 13 17:04:52 +0000 2020",
    "favorited" : false,
    "full_text" : "Laddddies and gentlemen. The president of Emuuurica! https://t.co/pOzseoz507",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238511356099170304/photo/1",
        "indices" : [ "53", "76" ],
        "url" : "https://t.co/pOzseoz507",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETATgoHUMAAL6SO.jpg",
        "id_str" : "1238511348771729408",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETATgoHUMAAL6SO.mp4"
          } ]
        },
        "id" : "1238511348771729408",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETATgoHUMAAL6SO.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/pOzseoz507"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238300725618200577/photo/1",
        "indices" : [ "71", "94" ],
        "url" : "https://t.co/xt9VkdMxE5",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9T8U3U8AQ9lYM.jpg",
        "id_str" : "1238300718408200196",
        "id" : "1238300718408200196",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9T8U3U8AQ9lYM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          },
          "large" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/xt9VkdMxE5"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "94" ],
    "favorite_count" : "0",
    "id_str" : "1238300725618200577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238300725618200577",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 13 03:07:54 +0000 2020",
    "favorited" : false,
    "full_text" : "I’m just a simple peasant boy from Rural Saskatchewan. Leave me alone. https://t.co/xt9VkdMxE5",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238300725618200577/photo/1",
        "indices" : [ "71", "94" ],
        "url" : "https://t.co/xt9VkdMxE5",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9T8U3U8AQ9lYM.jpg",
        "id_str" : "1238300718408200196",
        "video_info" : {
          "aspect_ratio" : [ "70", "57" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ES9T8U3U8AQ9lYM.mp4"
          } ]
        },
        "id" : "1238300718408200196",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9T8U3U8AQ9lYM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          },
          "large" : {
            "w" : "280",
            "h" : "228",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/xt9VkdMxE5"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238282507105099776/photo/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/OzEH7IB6ll",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9DX5NU8AAexh-.jpg",
        "id_str" : "1238282500322947072",
        "id" : "1238282500322947072",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9DX5NU8AAexh-.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/OzEH7IB6ll"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "0",
    "id_str" : "1238282507105099776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238282507105099776",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 13 01:55:30 +0000 2020",
    "favorited" : false,
    "full_text" : "🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅🦅 https://t.co/OzEH7IB6ll",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238282507105099776/photo/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/OzEH7IB6ll",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9DX5NU8AAexh-.jpg",
        "id_str" : "1238282500322947072",
        "video_info" : {
          "aspect_ratio" : [ "249", "140" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ES9DX5NU8AAexh-.mp4"
          } ]
        },
        "id" : "1238282500322947072",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9DX5NU8AAexh-.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/OzEH7IB6ll"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238281631779045376/photo/1",
        "indices" : [ "50", "73" ],
        "url" : "https://t.co/x3PNygYqaC",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9Ck8VUcAAMoZT.jpg",
        "id_str" : "1238281624988446720",
        "id" : "1238281624988446720",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9Ck8VUcAAMoZT.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/x3PNygYqaC"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "73" ],
    "favorite_count" : "0",
    "id_str" : "1238281631779045376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238281631779045376",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 13 01:52:01 +0000 2020",
    "favorited" : false,
    "full_text" : "Secretly self employed mother fuckers. Good luck! https://t.co/x3PNygYqaC",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238281631779045376/photo/1",
        "indices" : [ "50", "73" ],
        "url" : "https://t.co/x3PNygYqaC",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES9Ck8VUcAAMoZT.jpg",
        "id_str" : "1238281624988446720",
        "video_info" : {
          "aspect_ratio" : [ "93", "70" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ES9Ck8VUcAAMoZT.mp4"
          } ]
        },
        "id" : "1238281624988446720",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES9Ck8VUcAAMoZT.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "372",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/x3PNygYqaC"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238256518786662403/photo/1",
        "indices" : [ "77", "100" ],
        "url" : "https://t.co/kbAzaW3rP2",
        "media_url" : "http://pbs.twimg.com/media/ES8rurcUcAEMGxz.jpg",
        "id_str" : "1238256503485657089",
        "id" : "1238256503485657089",
        "media_url_https" : "https://pbs.twimg.com/media/ES8rurcUcAEMGxz.jpg",
        "sizes" : {
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kbAzaW3rP2"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "100" ],
    "favorite_count" : "0",
    "id_str" : "1238256518786662403",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238256518786662403",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 13 00:12:14 +0000 2020",
    "favorited" : false,
    "full_text" : "This is the University of Saskatchewan campus and it’s a very bad ass place. https://t.co/kbAzaW3rP2",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238256518786662403/photo/1",
        "indices" : [ "77", "100" ],
        "url" : "https://t.co/kbAzaW3rP2",
        "media_url" : "http://pbs.twimg.com/media/ES8rurcUcAEMGxz.jpg",
        "id_str" : "1238256503485657089",
        "id" : "1238256503485657089",
        "media_url_https" : "https://pbs.twimg.com/media/ES8rurcUcAEMGxz.jpg",
        "sizes" : {
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kbAzaW3rP2"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1238007399211909120",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238007399211909120",
    "created_at" : "Thu Mar 12 07:42:19 +0000 2020",
    "favorited" : false,
    "full_text" : "Mission: Success",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/B2TBqSpOL9",
        "expanded_url" : "https://music.apple.com/ca/album/error-operator/1449566998?i=1449567024",
        "display_url" : "music.apple.com/ca/album/error…",
        "indices" : [ "17", "40" ]
      } ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "id_str" : "1238000656184557568",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238000656184557568",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 12 07:15:32 +0000 2020",
    "favorited" : false,
    "full_text" : "Nailed itttt ttt https://t.co/B2TBqSpOL9",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "61", "69" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/BD6bb58hbt",
        "expanded_url" : "https://youtu.be/O4A10teaSiQ",
        "display_url" : "youtu.be/O4A10teaSiQ",
        "indices" : [ "33", "56" ]
      } ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1237973676529569792",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237973676529569792",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 12 05:28:19 +0000 2020",
    "favorited" : false,
    "full_text" : "Oh, Sleeper - Son Of The Morning https://t.co/BD6bb58hbt via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ "57", "73" ],
        "id_str" : "25073877",
        "id" : "25073877"
      } ],
      "urls" : [ {
        "url" : "https://t.co/cwAuJQVKs2",
        "expanded_url" : "https://youtu.be/J9FImc2LOr8",
        "display_url" : "youtu.be/J9FImc2LOr8",
        "indices" : [ "21", "44" ]
      } ]
    },
    "display_text_range" : [ "0", "73" ],
    "favorite_count" : "0",
    "id_str" : "1237971966742548485",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1237971966742548485",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 12 05:21:31 +0000 2020",
    "favorited" : false,
    "full_text" : "Space Jam Theme Song https://t.co/cwAuJQVKs2  Travel ban @realDonaldTrump",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Palin",
        "screen_name" : "SarahPalinUSA",
        "indices" : [ "0", "14" ],
        "id_str" : "65493023",
        "id" : "65493023"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1237965469543305217/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/7z7qzeyjnO",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES4jBxrUUAAZhRG.jpg",
        "id_str" : "1237965460995330048",
        "id" : "1237965460995330048",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES4jBxrUUAAZhRG.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/7z7qzeyjnO"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "id_str" : "1237965469543305217",
    "in_reply_to_user_id" : "65493023",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237965469543305217",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 12 04:55:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@SarahPalinUSA haha. https://t.co/7z7qzeyjnO",
    "lang" : "tl",
    "in_reply_to_screen_name" : "SarahPalinUSA",
    "in_reply_to_user_id_str" : "65493023",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1237965469543305217/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/7z7qzeyjnO",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ES4jBxrUUAAZhRG.jpg",
        "id_str" : "1237965460995330048",
        "video_info" : {
          "aspect_ratio" : [ "4", "3" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ES4jBxrUUAAZhRG.mp4"
          } ]
        },
        "id" : "1237965460995330048",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ES4jBxrUUAAZhRG.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/7z7qzeyjnO"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/hupxrshdc5",
        "expanded_url" : "https://music.apple.com/ca/album/breathing-in-a-new-mentality/714549741?i=714549786",
        "display_url" : "music.apple.com/ca/album/breat…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "1",
    "id_str" : "1237868166954373126",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237868166954373126",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 11 22:29:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/hupxrshdc5 Cow patty coronavirus.",
    "lang" : "in"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "TikTok",
        "indices" : [ "35", "42" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qMWCPSXXba",
        "expanded_url" : "http://Nate.scot",
        "display_url" : "Nate.scot",
        "indices" : [ "10", "33" ]
      }, {
        "url" : "https://t.co/3kDopWEZD0",
        "expanded_url" : "https://vm.tiktok.com/pJyQ62/",
        "display_url" : "vm.tiktok.com/pJyQ62/",
        "indices" : [ "43", "66" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1237555875931275264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237555875931275264",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 11 01:48:08 +0000 2020",
    "favorited" : false,
    "full_text" : "Check out https://t.co/qMWCPSXXba! #TikTok https://t.co/3kDopWEZD0",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "TikTok",
        "indices" : [ "23", "30" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/gj8OJPkjQ3",
        "expanded_url" : "https://vm.tiktok.com/pJFHCu/",
        "display_url" : "vm.tiktok.com/pJFHCu/",
        "indices" : [ "31", "54" ]
      } ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "1",
    "id_str" : "1237555797543882752",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237555797543882752",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 11 01:47:49 +0000 2020",
    "favorited" : false,
    "full_text" : "Check out Nathan Koch! #TikTok https://t.co/gj8OJPkjQ3",
    "lang" : "ht"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1237528393056317440",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237528393056317440",
    "created_at" : "Tue Mar 10 23:58:55 +0000 2020",
    "favorited" : false,
    "full_text" : "1 out of 3 hoes is mad!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/5MsqicnLtv",
        "expanded_url" : "https://www.youtube.com/watch?v=qjr7hZD3DKo",
        "display_url" : "youtube.com/watch?v=qjr7hZ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1236543430911643648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1236543430911643648",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 08 06:45:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/5MsqicnLtv Crazy but no.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/8OzWSSvAQJ",
        "expanded_url" : "https://www.youtube.com/watch?v=tFMo3UJ4B4g",
        "display_url" : "youtube.com/watch?v=tFMo3U…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "84" ],
    "favorite_count" : "0",
    "id_str" : "1235968584435679233",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1235968584435679233",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 06 16:40:48 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/8OzWSSvAQJ The Corona Virus? The Plague? Ashes? Ashes We All Fall Down?",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1235283320981860352/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/TjgBos2OpD",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ESSbn2eWoAY6EsB.jpg",
        "id_str" : "1235283306746388486",
        "id" : "1235283306746388486",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ESSbn2eWoAY6EsB.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          },
          "small" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/TjgBos2OpD"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1235283320981860352",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1235283320981860352",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 04 19:17:48 +0000 2020",
    "favorited" : false,
    "full_text" : "Drop it low! https://t.co/TjgBos2OpD",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1235283320981860352/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/TjgBos2OpD",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ESSbn2eWoAY6EsB.jpg",
        "id_str" : "1235283306746388486",
        "video_info" : {
          "aspect_ratio" : [ "59", "46" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ESSbn2eWoAY6EsB.mp4"
          } ]
        },
        "id" : "1235283306746388486",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ESSbn2eWoAY6EsB.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          },
          "small" : {
            "w" : "472",
            "h" : "368",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/TjgBos2OpD"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lFUy7rTmd5",
        "expanded_url" : "https://www.youtube.com/watch?v=mbNGXZO4vbA",
        "display_url" : "youtube.com/watch?v=mbNGXZ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251388203799441409",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251388203799441409",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 05:52:52 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lFUy7rTmd5",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ZlU6Gs4E2Y",
        "expanded_url" : "https://www.youtube.com/watch?v=QZFovTnjGio",
        "display_url" : "youtube.com/watch?v=QZFovT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1251386565902778368",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251386565902778368",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 05:46:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ZlU6Gs4E2Y Monuments is fucking dead.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "54", "62" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/zt5AsS1cJo",
        "expanded_url" : "https://youtu.be/Q1ixsLWFC5o",
        "display_url" : "youtu.be/Q1ixsLWFC5o",
        "indices" : [ "26", "49" ]
      } ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1251342528378527745",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251342528378527745",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 02:51:22 +0000 2020",
    "favorited" : false,
    "full_text" : "Architects - Hollow Crown https://t.co/zt5AsS1cJo via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "63", "71" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/zPwOqttEtx",
        "expanded_url" : "https://youtu.be/rKwMni-2szU",
        "display_url" : "youtu.be/rKwMni-2szU",
        "indices" : [ "35", "58" ]
      } ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1251338544989208578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251338544989208578",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 02:35:32 +0000 2020",
    "favorited" : false,
    "full_text" : "Matthew Good - 21st Century Living https://t.co/zPwOqttEtx via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251338238457008128/photo/1",
        "indices" : [ "12", "35" ],
        "url" : "https://t.co/JvtP1p7XLb",
        "media_url" : "http://pbs.twimg.com/media/EV2lfBrVAAANJ34.jpg",
        "id_str" : "1251338223923560448",
        "id" : "1251338223923560448",
        "media_url_https" : "https://pbs.twimg.com/media/EV2lfBrVAAANJ34.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          },
          "large" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/JvtP1p7XLb"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "id_str" : "1251338238457008128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251338238457008128",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 02:34:19 +0000 2020",
    "favorited" : false,
    "full_text" : "Not Stonks. https://t.co/JvtP1p7XLb",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251338238457008128/photo/1",
        "indices" : [ "12", "35" ],
        "url" : "https://t.co/JvtP1p7XLb",
        "media_url" : "http://pbs.twimg.com/media/EV2lfBrVAAANJ34.jpg",
        "id_str" : "1251338223923560448",
        "id" : "1251338223923560448",
        "media_url_https" : "https://pbs.twimg.com/media/EV2lfBrVAAANJ34.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          },
          "large" : {
            "w" : "474",
            "h" : "474",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/JvtP1p7XLb"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nathan Koch",
        "screen_name" : "nathanlkoch",
        "indices" : [ "3", "15" ],
        "id_str" : "1089683769450262529",
        "id" : "1089683769450262529"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "139" ],
    "favorite_count" : "0",
    "id_str" : "1251300819716243457",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251300819716243457",
    "created_at" : "Sat Apr 18 00:05:38 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @nathanlkoch: I'm aware misinformation is used to discredit sources. I'm not going to lie. This is Alex Jones type shit but I thought I…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "88", "96" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/ZfEsLWomOE",
        "expanded_url" : "https://youtu.be/Md6Dvxdr0AQ",
        "display_url" : "youtu.be/Md6Dvxdr0AQ",
        "indices" : [ "60", "83" ]
      } ]
    },
    "display_text_range" : [ "0", "96" ],
    "favorite_count" : "0",
    "id_str" : "1251300193418596355",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251300193418596355",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 00:03:08 +0000 2020",
    "favorited" : false,
    "full_text" : "World War Z Official Trailer #1 (2013) - Brad Pitt Movie HD https://t.co/ZfEsLWomOE via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "85", "93" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/LWH8NGfED1",
        "expanded_url" : "https://youtu.be/lo-toYiurYs",
        "display_url" : "youtu.be/lo-toYiurYs",
        "indices" : [ "57", "80" ]
      } ]
    },
    "display_text_range" : [ "0", "93" ],
    "favorite_count" : "0",
    "id_str" : "1251297646591070214",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251297646591070214",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 23:53:01 +0000 2020",
    "favorited" : false,
    "full_text" : "The Devil Wears Prada - Worldwide (Official Music Video) https://t.co/LWH8NGfED1 via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "64", "72" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/vZBCsv5fcs",
        "expanded_url" : "https://youtu.be/-nufOttSLoI",
        "display_url" : "youtu.be/-nufOttSLoI",
        "indices" : [ "36", "59" ]
      } ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "0",
    "id_str" : "1251208962436927490",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251208962436927490",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 18:00:37 +0000 2020",
    "favorited" : false,
    "full_text" : "Volumes - NO LOVE (feat. Fronzilla) https://t.co/vZBCsv5fcs via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251207691139035137/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/5rxSVRB0nU",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV0uwlNVcAEwmUA.jpg",
        "id_str" : "1251207683635507201",
        "id" : "1251207683635507201",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV0uwlNVcAEwmUA.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          },
          "large" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/5rxSVRB0nU"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1251207691139035137",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251207691139035137",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 17:55:34 +0000 2020",
    "favorited" : false,
    "full_text" : "Wuhahahaha https://t.co/5rxSVRB0nU",
    "lang" : "tl",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251207691139035137/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/5rxSVRB0nU",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV0uwlNVcAEwmUA.jpg",
        "id_str" : "1251207683635507201",
        "video_info" : {
          "aspect_ratio" : [ "22", "15" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EV0uwlNVcAEwmUA.mp4"
          } ]
        },
        "id" : "1251207683635507201",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV0uwlNVcAEwmUA.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          },
          "large" : {
            "w" : "440",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/5rxSVRB0nU"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "68", "76" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/OLW2T6X2Fz",
        "expanded_url" : "https://youtu.be/WIUAC03YMlA",
        "display_url" : "youtu.be/WIUAC03YMlA",
        "indices" : [ "40", "63" ]
      } ]
    },
    "display_text_range" : [ "0", "76" ],
    "favorite_count" : "0",
    "id_str" : "1251207049364434945",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251207049364434945",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 17:53:01 +0000 2020",
    "favorited" : false,
    "full_text" : "Jamiroquai - Deeper Underground (Video) https://t.co/OLW2T6X2Fz via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "58", "66" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/fu2We0XMyo",
        "expanded_url" : "https://youtu.be/6pXQD4nix-w",
        "display_url" : "youtu.be/6pXQD4nix-w",
        "indices" : [ "30", "53" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1250997663123685377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250997663123685377",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 04:00:59 +0000 2020",
    "favorited" : false,
    "full_text" : "August Burns Red - \"Meridian\" https://t.co/fu2We0XMyo via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "51", "59" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/6v63Z2PEv4",
        "expanded_url" : "https://youtu.be/j6gdJfeZhB8",
        "display_url" : "youtu.be/j6gdJfeZhB8",
        "indices" : [ "23", "46" ]
      } ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1250985195441922052",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250985195441922052",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 03:11:27 +0000 2020",
    "favorited" : false,
    "full_text" : "Spongebob's Evil Laugh https://t.co/6v63Z2PEv4 via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "42", "50" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/npNtgOf22b",
        "expanded_url" : "https://youtu.be/wJo3R3XNlis",
        "display_url" : "youtu.be/wJo3R3XNlis",
        "indices" : [ "14", "37" ]
      } ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1250976292369022976",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250976292369022976",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 17 02:36:04 +0000 2020",
    "favorited" : false,
    "full_text" : "Basher Henrik https://t.co/npNtgOf22b via @YouTube",
    "lang" : "da"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qSb6LMcqwu",
        "expanded_url" : "https://m.youtube.com/watch?v=mrP9SrMJ00c",
        "display_url" : "m.youtube.com/watch?v=mrP9Sr…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250878868690309121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250878868690309121",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 20:08:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qSb6LMcqwu",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NI8yCztrby",
        "expanded_url" : "https://m.youtube.com/watch?v=DsCWdKjMcsA",
        "display_url" : "m.youtube.com/watch?v=DsCWdK…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250738417765212160",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250738417765212160",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 10:50:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NI8yCztrby",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/61kQDbF24p",
        "expanded_url" : "https://www.youtube.com/watch?v=ODpYCtey2r0",
        "display_url" : "youtube.com/watch?v=ODpYCt…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250677865571430400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250677865571430400",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 06:50:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/61kQDbF24p",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/XGcqRxhEd8",
        "expanded_url" : "https://www.youtube.com/watch?v=RwCPvKsoZJk",
        "display_url" : "youtube.com/watch?v=RwCPvK…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250674313251876865",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250674313251876865",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 06:36:07 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/XGcqRxhEd8",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/zKEQ9TbTzf",
        "expanded_url" : "https://youtu.be/xRt6_LmnSSc?t=49",
        "display_url" : "youtu.be/xRt6_LmnSSc?t=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250673258459828224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250673258459828224",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 06:31:55 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/zKEQ9TbTzf",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "78", "86" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/icyhUbiVFJ",
        "expanded_url" : "https://youtu.be/rKFyR8SaQz4",
        "display_url" : "youtu.be/rKFyR8SaQz4",
        "indices" : [ "50", "73" ]
      } ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1250656688518168577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250656688518168577",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 05:26:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Your Demise - The Clocks Aren´t Ticking Backwards https://t.co/icyhUbiVFJ via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "57", "65" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/ssYYI5BjiK",
        "expanded_url" : "https://youtu.be/HYM_dT-LD1E",
        "display_url" : "youtu.be/HYM_dT-LD1E",
        "indices" : [ "29", "52" ]
      } ]
    },
    "display_text_range" : [ "0", "65" ],
    "favorite_count" : "0",
    "id_str" : "1250618871561805824",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250618871561805824",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 16 02:55:49 +0000 2020",
    "favorited" : false,
    "full_text" : "Every Time I Die - Ebolarama https://t.co/ssYYI5BjiK via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/DPbkOTmsN5",
        "expanded_url" : "https://youtu.be/ejw9pDVYvpM",
        "display_url" : "youtu.be/ejw9pDVYvpM",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250272985811791872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250272985811791872",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 15 04:01:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/DPbkOTmsN5",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "68", "76" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/ammw3xshPX",
        "expanded_url" : "https://youtu.be/AWggPLXeOkU",
        "display_url" : "youtu.be/AWggPLXeOkU",
        "indices" : [ "40", "63" ]
      } ]
    },
    "display_text_range" : [ "0", "76" ],
    "favorite_count" : "0",
    "id_str" : "1250271610344374272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250271610344374272",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 15 03:55:55 +0000 2020",
    "favorited" : false,
    "full_text" : "BRING ME THE HORIZON - Pray for Plagues https://t.co/ammw3xshPX via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/opX1gPqLhc",
        "expanded_url" : "https://m.youtube.com/watch?v=bjv7CVhZXNs",
        "display_url" : "m.youtube.com/watch?v=bjv7CV…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251747653949337600",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251747653949337600",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:41:11 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/opX1gPqLhc",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/IX1LOXKzst",
        "expanded_url" : "https://m.youtube.com/watch?v=5V6XePtOJ-g",
        "display_url" : "m.youtube.com/watch?v=5V6XeP…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251746947783778304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251746947783778304",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:38:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/IX1LOXKzst",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LKMylQe7AW",
        "expanded_url" : "https://m.youtube.com/watch?v=7RmLkY1387A",
        "display_url" : "m.youtube.com/watch?v=7RmLkY…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251746204938940419",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251746204938940419",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:35:26 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/LKMylQe7AW",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1eFupzqalS",
        "expanded_url" : "https://youtu.be/P2fPmyH6Q6E",
        "display_url" : "youtu.be/P2fPmyH6Q6E",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251729765859377152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251729765859377152",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 04:30:06 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1eFupzqalS",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cFuew8W87I",
        "expanded_url" : "https://youtu.be/_c_vBskRKbs",
        "display_url" : "youtu.be/_c_vBskRKbs",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251729310789980161",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251729310789980161",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 04:28:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cFuew8W87I",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251691966443728902/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/5UZ9VtHjCX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7nNFHVcAAB0vp.jpg",
        "id_str" : "1251691958352834560",
        "id" : "1251691958352834560",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7nNFHVcAAB0vp.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/5UZ9VtHjCX"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251691966443728902",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251691966443728902",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 01:59:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/5UZ9VtHjCX",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251691966443728902/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/5UZ9VtHjCX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7nNFHVcAAB0vp.jpg",
        "id_str" : "1251691958352834560",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EV7nNFHVcAAB0vp.mp4"
          } ]
        },
        "id" : "1251691958352834560",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7nNFHVcAAB0vp.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/5UZ9VtHjCX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251691830720290817/photo/1",
        "indices" : [ "71", "94" ],
        "url" : "https://t.co/VMT3kKvcA1",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7nFLbVcAA0CN1.jpg",
        "id_str" : "1251691822608379904",
        "id" : "1251691822608379904",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7nFLbVcAA0CN1.jpg",
        "sizes" : {
          "small" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VMT3kKvcA1"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "94" ],
    "favorite_count" : "0",
    "id_str" : "1251691830720290817",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251691830720290817",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 01:59:22 +0000 2020",
    "favorited" : false,
    "full_text" : "Going low tech. CQ CQ CQ This is VA5UPB. Y’all can suck my dick. Over. https://t.co/VMT3kKvcA1",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251691830720290817/photo/1",
        "indices" : [ "71", "94" ],
        "url" : "https://t.co/VMT3kKvcA1",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7nFLbVcAA0CN1.jpg",
        "id_str" : "1251691822608379904",
        "video_info" : {
          "aspect_ratio" : [ "125", "93" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EV7nFLbVcAA0CN1.mp4"
          } ]
        },
        "id" : "1251691822608379904",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7nFLbVcAA0CN1.jpg",
        "sizes" : {
          "small" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/VMT3kKvcA1"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251687931795984384/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/mwJUMQqgsh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7jiR3UEAA-6nr.jpg",
        "id_str" : "1251687924506038272",
        "id" : "1251687924506038272",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7jiR3UEAA-6nr.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/mwJUMQqgsh"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251687931795984384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251687931795984384",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 01:43:52 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/mwJUMQqgsh",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251687931795984384/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/mwJUMQqgsh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EV7jiR3UEAA-6nr.jpg",
        "id_str" : "1251687924506038272",
        "video_info" : {
          "aspect_ratio" : [ "1", "1" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EV7jiR3UEAA-6nr.mp4"
          } ]
        },
        "id" : "1251687924506038272",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EV7jiR3UEAA-6nr.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "500",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/mwJUMQqgsh"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/6ZWk9eknEn",
        "expanded_url" : "https://m.youtube.com/watch?v=Moleb4XACAo",
        "display_url" : "m.youtube.com/watch?v=Moleb4…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251643996893360128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251643996893360128",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 22:49:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/6ZWk9eknEn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/FXmatFes2l",
        "expanded_url" : "https://youtu.be/ntWieh7YIgY",
        "display_url" : "youtu.be/ntWieh7YIgY",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251634859849641984",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251634859849641984",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 22:12:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/FXmatFes2l",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/IzhIRT8JwU",
        "expanded_url" : "https://en.m.wikipedia.org/wiki/Coronavirus_disease_2019",
        "display_url" : "en.m.wikipedia.org/wiki/Coronavir…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251634029138309121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251634029138309121",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 22:09:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/IzhIRT8JwU",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/AT9J4K9s8e",
        "expanded_url" : "https://en.m.wikipedia.org/wiki/Agenda_21",
        "display_url" : "en.m.wikipedia.org/wiki/Agenda_21",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251633802310348800",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251633802310348800",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 22:08:47 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/AT9J4K9s8e",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ESHNCKxubz",
        "expanded_url" : "https://youtu.be/enBllfqkMEw",
        "display_url" : "youtu.be/enBllfqkMEw",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251633418967724032",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251633418967724032",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 22:07:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ESHNCKxubz",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/OkGDJOPPn0",
        "expanded_url" : "https://m.youtube.com/watch?v=ujfnyv5pg_M",
        "display_url" : "m.youtube.com/watch?v=ujfnyv…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251628982748852224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251628982748852224",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:49:38 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/OkGDJOPPn0",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1fXQPL1l98",
        "expanded_url" : "https://youtu.be/eNxycOyfdaQ",
        "display_url" : "youtu.be/eNxycOyfdaQ",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251628203451527170",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251628203451527170",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:46:32 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1fXQPL1l98",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NOpDmjFmzK",
        "expanded_url" : "https://youtu.be/ipbGsHL1oZw",
        "display_url" : "youtu.be/ipbGsHL1oZw",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251626472546041856",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251626472546041856",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:39:39 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NOpDmjFmzK",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/EEppi83fEl",
        "expanded_url" : "https://m.youtube.com/watch?v=obGEd3O1NnM",
        "display_url" : "m.youtube.com/watch?v=obGEd3…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251622276480380928",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251622276480380928",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:22:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/EEppi83fEl",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/8XSyNQGBD0",
        "expanded_url" : "https://duckduckgo.com/?q=fema+coffins&t=iphone&iax=images&ia=images",
        "display_url" : "duckduckgo.com/?q=fema+coffin…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251622105273135110",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251622105273135110",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:22:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/8XSyNQGBD0",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CqfS19YCVT",
        "expanded_url" : "https://m.youtube.com/watch?v=9lMn8GZIBPw",
        "display_url" : "m.youtube.com/watch?v=9lMn8G…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251621152125927424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251621152125927424",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:18:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CqfS19YCVT",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/OMOPhqjRgM",
        "expanded_url" : "https://music.apple.com/ca/album/vivification/445045583?i=445045584",
        "display_url" : "music.apple.com/ca/album/vivif…",
        "indices" : [ "12", "35" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251620736474611713/photo/1",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/0NgwExsSgQ",
        "media_url" : "http://pbs.twimg.com/media/EV6mJHKU4AELE6X.jpg",
        "id_str" : "1251620421926969345",
        "id" : "1251620421926969345",
        "media_url_https" : "https://pbs.twimg.com/media/EV6mJHKU4AELE6X.jpg",
        "sizes" : {
          "small" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          },
          "large" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0NgwExsSgQ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1251620736474611713",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251620736474611713",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 21:16:52 +0000 2020",
    "favorited" : false,
    "full_text" : "Hahahahaha. https://t.co/OMOPhqjRgM https://t.co/0NgwExsSgQ",
    "lang" : "tl",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251620736474611713/photo/1",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/0NgwExsSgQ",
        "media_url" : "http://pbs.twimg.com/media/EV6mJHKU4AELE6X.jpg",
        "id_str" : "1251620421926969345",
        "id" : "1251620421926969345",
        "media_url_https" : "https://pbs.twimg.com/media/EV6mJHKU4AELE6X.jpg",
        "sizes" : {
          "small" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          },
          "large" : {
            "w" : "460",
            "h" : "161",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0NgwExsSgQ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Oj4dr7XfGh",
        "expanded_url" : "https://www.youtube.com/watch?v=RdxdnVqn08E",
        "display_url" : "youtube.com/watch?v=RdxdnV…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251389576246996997",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251389576246996997",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 05:58:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Oj4dr7XfGh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0oSCIAu1Vo",
        "expanded_url" : "https://www.youtube.com/watch?v=uYnlzpSSevM",
        "display_url" : "youtube.com/watch?v=uYnlzp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251389259044417536",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251389259044417536",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 18 05:57:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0oSCIAu1Vo",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1252735462789181440/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/RUgZEMj32b",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWKcQcjU8AAfU4z.jpg",
        "id_str" : "1252735452718624768",
        "id" : "1252735452718624768",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWKcQcjU8AAfU4z.jpg",
        "sizes" : {
          "medium" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          },
          "large" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/RUgZEMj32b"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "0",
    "id_str" : "1252735462789181440",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252735462789181440",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 23:06:23 +0000 2020",
    "favorited" : false,
    "full_text" : "Leave me alone https://t.co/RUgZEMj32b",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1252735462789181440/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/RUgZEMj32b",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWKcQcjU8AAfU4z.jpg",
        "id_str" : "1252735452718624768",
        "video_info" : {
          "aspect_ratio" : [ "151", "113" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWKcQcjU8AAfU4z.mp4"
          } ]
        },
        "id" : "1252735452718624768",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWKcQcjU8AAfU4z.jpg",
        "sizes" : {
          "medium" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          },
          "large" : {
            "w" : "302",
            "h" : "226",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/RUgZEMj32b"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "185" ],
    "favorite_count" : "0",
    "id_str" : "1252734937024745472",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252734937024745472",
    "created_at" : "Tue Apr 21 23:04:18 +0000 2020",
    "favorited" : false,
    "full_text" : "So. If you could all fuck off. That’d be great.  Obsessive fucking losers. Even right now your seething over my social media. I’m not your friend. I’m not playing games with you either.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1252731268766109696/photo/1",
        "indices" : [ "40", "63" ],
        "url" : "https://t.co/Y2BKI577Pv",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWKYcgtUEAAwrCg.jpg",
        "id_str" : "1252731261946171392",
        "id" : "1252731261946171392",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWKYcgtUEAAwrCg.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Y2BKI577Pv"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1252731268766109696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252731268766109696",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 22:49:43 +0000 2020",
    "favorited" : false,
    "full_text" : "Am I joking or am I being on the level? https://t.co/Y2BKI577Pv",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1252731268766109696/photo/1",
        "indices" : [ "40", "63" ],
        "url" : "https://t.co/Y2BKI577Pv",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWKYcgtUEAAwrCg.jpg",
        "id_str" : "1252731261946171392",
        "video_info" : {
          "aspect_ratio" : [ "249", "139" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWKYcgtUEAAwrCg.mp4"
          } ]
        },
        "id" : "1252731261946171392",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWKYcgtUEAAwrCg.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/Y2BKI577Pv"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "190" ],
    "favorite_count" : "0",
    "id_str" : "1252730755924422656",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252730755924422656",
    "created_at" : "Tue Apr 21 22:47:41 +0000 2020",
    "favorited" : false,
    "full_text" : "“He’s an insider!” my response: “Yeah bruh, I’m a high level member of the Illuminati. Shape shifting lizard demons are trying to corrupt humanity. You will never stop us! Hahaha” Man, STFU.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/nI2SdgKh4c",
        "expanded_url" : "https://m.youtube.com/watch?v=CN4IIgFz93k",
        "display_url" : "m.youtube.com/watch?v=CN4IIg…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252687651834118146",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252687651834118146",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 19:56:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/nI2SdgKh4c",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/aGr0Sb5mQg",
        "expanded_url" : "https://m.youtube.com/watch?v=PQzuW7w1dVs",
        "display_url" : "m.youtube.com/watch?v=PQzuW7…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252549284202856449",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252549284202856449",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 10:46:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/aGr0Sb5mQg",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cIRMUC97Qk",
        "expanded_url" : "https://m.youtube.com/watch?v=j7KmBZHoAWQ",
        "display_url" : "m.youtube.com/watch?v=j7KmBZ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252544598615842818",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252544598615842818",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 10:27:58 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cIRMUC97Qk",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qpv9EjbYCh",
        "expanded_url" : "https://m.youtube.com/watch?v=b4Kdp3CHoK4",
        "display_url" : "m.youtube.com/watch?v=b4Kdp3…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252537564558323712",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252537564558323712",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 21 10:00:01 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qpv9EjbYCh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/c4hegxux4T",
        "expanded_url" : "https://m.youtube.com/watch?v=rJyQFb4mc4U",
        "display_url" : "m.youtube.com/watch?v=rJyQFb…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252341795591086095",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252341795591086095",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 21:02:06 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/c4hegxux4T",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/X1rGTdynWR",
        "expanded_url" : "https://m.youtube.com/watch?v=rlsJItvSsc8",
        "display_url" : "m.youtube.com/watch?v=rlsJIt…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252336820869754885",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252336820869754885",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 20:42:20 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/X1rGTdynWR",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/S7Fzh0AiAd",
        "expanded_url" : "https://m.youtube.com/watch?v=sEMKG8xkm4A",
        "display_url" : "m.youtube.com/watch?v=sEMKG8…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252327708148682752",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252327708148682752",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 20:06:07 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/S7Fzh0AiAd",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/KjsShXsSzi",
        "expanded_url" : "https://www.dailymotion.com/video/x5t1e0z",
        "display_url" : "dailymotion.com/video/x5t1e0z",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252326676807081984",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252326676807081984",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 20:02:01 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/KjsShXsSzi",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/K2wVrTk4a6",
        "expanded_url" : "https://multicians.org/project-mac.html",
        "display_url" : "multicians.org/project-mac.ht…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1252115232597569537",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252115232597569537",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 06:01:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/K2wVrTk4a6 Project Mac. PsyOps. Bottom PDFs.",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/s1nKoe6jKJ",
        "expanded_url" : "https://youtu.be/WL15eTRcAsg",
        "display_url" : "youtu.be/WL15eTRcAsg",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1252086353858195457",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252086353858195457",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 20 04:07:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/s1nKoe6jKJ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251939158236356609/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/RHNXGNfW8a",
        "media_url" : "http://pbs.twimg.com/media/EV_H_UJVAAAVFna.jpg",
        "id_str" : "1251939111985807360",
        "id" : "1251939111985807360",
        "media_url_https" : "https://pbs.twimg.com/media/EV_H_UJVAAAVFna.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/RHNXGNfW8a"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1251939158236356609",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251939158236356609",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 18:22:09 +0000 2020",
    "favorited" : false,
    "full_text" : "Bleh!!! https://t.co/RHNXGNfW8a",
    "lang" : "in",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1251939158236356609/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/RHNXGNfW8a",
        "media_url" : "http://pbs.twimg.com/media/EV_H_UJVAAAVFna.jpg",
        "id_str" : "1251939111985807360",
        "id" : "1251939111985807360",
        "media_url_https" : "https://pbs.twimg.com/media/EV_H_UJVAAAVFna.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "285",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/RHNXGNfW8a"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cJG0f5Y1Qj",
        "expanded_url" : "https://m.youtube.com/watch?v=G1GdDt5mrqo",
        "display_url" : "m.youtube.com/watch?v=G1GdDt…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251937578468601857",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251937578468601857",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 18:15:53 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cJG0f5Y1Qj",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LBjGUAFqvF",
        "expanded_url" : "https://m.youtube.com/watch?v=HlpPXp49d8k",
        "display_url" : "m.youtube.com/watch?v=HlpPXp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251934831723737088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251934831723737088",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 18:04:58 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/LBjGUAFqvF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xMVsgjQCn5",
        "expanded_url" : "https://en.m.wikipedia.org/wiki/Georgia_Guidestones",
        "display_url" : "en.m.wikipedia.org/wiki/Georgia_G…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251934660067651585",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251934660067651585",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 18:04:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/xMVsgjQCn5",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CmL19IA5Hn",
        "expanded_url" : "https://youtu.be/s2jvANh2aEc",
        "display_url" : "youtu.be/s2jvANh2aEc",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251791492202422272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251791492202422272",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 08:35:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CmL19IA5Hn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "2" ],
    "favorite_count" : "0",
    "id_str" : "1251757801602351104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251757801602351104",
    "created_at" : "Sun Apr 19 06:21:31 +0000 2020",
    "favorited" : false,
    "full_text" : "73",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/H6vxDMmNsO",
        "expanded_url" : "https://m.youtube.com/watch?v=RbV59W-gM64",
        "display_url" : "m.youtube.com/watch?v=RbV59W…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251753103818293249",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251753103818293249",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 06:02:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/H6vxDMmNsO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/OAtYOnoDg9",
        "expanded_url" : "https://m.youtube.com/watch?v=FSEBstlH6WY",
        "display_url" : "m.youtube.com/watch?v=FSEBst…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251751981217013761",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251751981217013761",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:58:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/OAtYOnoDg9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/VvpA2zAnCL",
        "expanded_url" : "https://youtu.be/VduTNiOXpik",
        "display_url" : "youtu.be/VduTNiOXpik",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251751128187809794",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251751128187809794",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:55:00 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/VvpA2zAnCL",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/YzGVJiG2U6",
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1248875865670221824",
        "display_url" : "twitter.com/nathankoch_lea…",
        "indices" : [ "5", "28" ]
      } ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1251749372460781569",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251749372460781569",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:48:01 +0000 2020",
    "favorited" : false,
    "full_text" : "Buzz https://t.co/YzGVJiG2U6",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wey4p0Mm6s",
        "expanded_url" : "https://m.youtube.com/watch?v=XDtP3yFZQow",
        "display_url" : "m.youtube.com/watch?v=XDtP3y…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1251748764823384064",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1251748764823384064",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 19 05:45:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wey4p0Mm6s",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253522503823028225/photo/1",
        "indices" : [ "185", "208" ],
        "url" : "https://t.co/ULYcryeum1",
        "media_url" : "http://pbs.twimg.com/media/EWVntVFUMAA7EGn.jpg",
        "id_str" : "1253522099743764480",
        "id" : "1253522099743764480",
        "media_url_https" : "https://pbs.twimg.com/media/EWVntVFUMAA7EGn.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/ULYcryeum1"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "208" ],
    "favorite_count" : "0",
    "id_str" : "1253522503823028225",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253522503823028225",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 03:13:48 +0000 2020",
    "favorited" : false,
    "full_text" : "“Do you have bags under your eyes” “Your head must be pounding” “Go back inside so we can X-ray the shit out of you” “I’m going to rub it in your face while your dying in the hospital” https://t.co/ULYcryeum1",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253522503823028225/photo/1",
        "indices" : [ "185", "208" ],
        "url" : "https://t.co/ULYcryeum1",
        "media_url" : "http://pbs.twimg.com/media/EWVntVFUMAA7EGn.jpg",
        "id_str" : "1253522099743764480",
        "id" : "1253522099743764480",
        "media_url_https" : "https://pbs.twimg.com/media/EWVntVFUMAA7EGn.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/ULYcryeum1"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "73" ],
    "favorite_count" : "0",
    "id_str" : "1253520536216285184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253520536216285184",
    "created_at" : "Fri Apr 24 03:05:59 +0000 2020",
    "favorited" : false,
    "full_text" : "That doesn’t even include the daily bullshit from racialized streetgangs.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0AuBeksjUY",
        "expanded_url" : "Https://www.twitter.com/nathankoch_is",
        "display_url" : "twitter.com/nathankoch_is",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253520365659156481",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253520365659156481",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 03:05:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0AuBeksjUY",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "94" ],
    "favorite_count" : "0",
    "id_str" : "1253520051623170052",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253520051623170052",
    "created_at" : "Fri Apr 24 03:04:04 +0000 2020",
    "favorited" : false,
    "full_text" : "I have been being terrorized by the government and the citizens of this country for years now.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "95" ],
    "favorite_count" : "0",
    "id_str" : "1253519907141988353",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253519907141988353",
    "created_at" : "Fri Apr 24 03:03:29 +0000 2020",
    "favorited" : false,
    "full_text" : "The likelihood of me developing serious health concerns later for being here is extremely high.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "223" ],
    "favorite_count" : "0",
    "id_str" : "1253519557332856832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253519557332856832",
    "created_at" : "Fri Apr 24 03:02:06 +0000 2020",
    "favorited" : false,
    "full_text" : "Also happen regularly. It is often occurrence to spend hours arguing with GCHQ over YouTube in craft. Patrons at such fine establishments as the lighthouse and the Salvation Army have been following orders. Including staff.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "278" ],
    "favorite_count" : "0",
    "id_str" : "1253519124497436673",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253519124497436673",
    "created_at" : "Fri Apr 24 03:00:23 +0000 2020",
    "favorited" : false,
    "full_text" : "While this has been taking place shots about death and brain cancer have been a regular occurrence. “Go back inside so we can X-ray the shit out of you” are common phrases behind cloaks. Shots regarding previous agent and the government and origins from the tv and counting cars",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "274" ],
    "favorite_count" : "0",
    "id_str" : "1253518652764119045",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253518652764119045",
    "created_at" : "Fri Apr 24 02:58:30 +0000 2020",
    "favorited" : false,
    "full_text" : "Several years ago while in Saskatoon sparks started coming out of the floor and something I can only describe as a beam that causes discomfort, pain and hypertension. The issue followed me to Regina. And on a daily basis neighbors or embedded devices have been torturing me.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "222" ],
    "favorite_count" : "0",
    "id_str" : "1253518125338750977",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253518125338750977",
    "created_at" : "Fri Apr 24 02:56:24 +0000 2020",
    "favorited" : false,
    "full_text" : "Since returning in Saskatchewan there have been daily instances of Canadian Agencies with the guidance of Britain being extremely aggressive. Counting cars. Tv. Radio. Internet mediam. Billboards. Reguarding the following.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "246" ],
    "favorite_count" : "0",
    "id_str" : "1253517652133216258",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253517652133216258",
    "created_at" : "Fri Apr 24 02:54:32 +0000 2020",
    "favorited" : false,
    "full_text" : "While in Ottawa I had several very negative interactions with British agents while working at a hostile and in Ottawa, Saskatoon, Regina I have had at least four interactions with having neighbors with the same name as a Mossad agent in Whistler.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "256" ],
    "favorite_count" : "0",
    "id_str" : "1253517138892972032",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253517138892972032",
    "created_at" : "Fri Apr 24 02:52:29 +0000 2020",
    "favorited" : false,
    "full_text" : "While in Iceland I cam in contact with ISI agents who put pressure on me to force me to move in with Russian and Russian/Mossad agents. Later are being deported back to Canada it has been a none stop onslaught of Harassment from Mossad and Canadian agents.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LDKRfHlNAh",
        "expanded_url" : "Https://www.instagram.com/alienducks",
        "display_url" : "instagram.com/alienducks",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253516623417184256",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253516623417184256",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 02:50:26 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/LDKRfHlNAh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "275" ],
    "favorite_count" : "0",
    "id_str" : "1253516487492435969",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253516487492435969",
    "created_at" : "Fri Apr 24 02:49:54 +0000 2020",
    "favorited" : false,
    "full_text" : "Since 2014 CSIS has been psychologically torturing me on behalf of The British and Mossad. After years of abuse I decided it was best for me to leave Canada. I flew to Iceland. After months of waiting and being sucked back in with the Hacktivist album I was deported in 2016.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Et9YlhRNFh",
        "expanded_url" : "https://m.youtube.com/watch?v=joTDrR5r7sE",
        "display_url" : "m.youtube.com/watch?v=joTDrR…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253509012621938690",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253509012621938690",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 02:20:12 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Et9YlhRNFh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mYXjGV4v30",
        "expanded_url" : "https://youtu.be/AIvoQhOM0eQ",
        "display_url" : "youtu.be/AIvoQhOM0eQ",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253504837137752065",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253504837137752065",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 02:03:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/mYXjGV4v30",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "id_str" : "1253500108382982145",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253500108382982145",
    "created_at" : "Fri Apr 24 01:44:49 +0000 2020",
    "favorited" : false,
    "full_text" : "It’s not really funny. People are dying.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Tyz6Mumric",
        "expanded_url" : "https://m.youtube.com/watch?v=qSCUhqsy4Nk",
        "display_url" : "m.youtube.com/watch?v=qSCUhq…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253496640452747264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253496640452747264",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 01:31:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Tyz6Mumric",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253193850153127937/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/mQw49baosG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWQ9KKdU0AICDG4.jpg",
        "id_str" : "1253193841131180034",
        "id" : "1253193841131180034",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWQ9KKdU0AICDG4.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/mQw49baosG"
      } ],
      "hashtags" : [ {
        "text" : "earth",
        "indices" : [ "0", "6" ]
      } ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1253193850153127937",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253193850153127937",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 23 05:27:51 +0000 2020",
    "favorited" : false,
    "full_text" : "#earth https://t.co/mQw49baosG",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253193850153127937/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/mQw49baosG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWQ9KKdU0AICDG4.jpg",
        "id_str" : "1253193841131180034",
        "video_info" : {
          "aspect_ratio" : [ "83", "62" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWQ9KKdU0AICDG4.mp4"
          } ]
        },
        "id" : "1253193841131180034",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWQ9KKdU0AICDG4.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/mQw49baosG"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/b7dTl6hiVs",
        "expanded_url" : "https://m.youtube.com/watch?v=28VwBw_k_YY",
        "display_url" : "m.youtube.com/watch?v=28VwBw…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253193705030250503",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253193705030250503",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 23 05:27:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/b7dTl6hiVs",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/SrgRzzXb4f",
        "expanded_url" : "https://www.youtube.com/watch?v=Ge0lldlZY9k",
        "display_url" : "youtube.com/watch?v=Ge0lld…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253027325064605696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253027325064605696",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 22 18:26:09 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/SrgRzzXb4f",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253025988536987648/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/K0Xa16xkuu",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWOkfcuUMAApfW9.jpg",
        "id_str" : "1253025981532483584",
        "id" : "1253025981532483584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWOkfcuUMAApfW9.jpg",
        "sizes" : {
          "medium" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "large" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "124",
            "h" : "124",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/K0Xa16xkuu"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253025988536987648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253025988536987648",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 22 18:20:50 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/K0Xa16xkuu",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253025988536987648/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/K0Xa16xkuu",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWOkfcuUMAApfW9.jpg",
        "id_str" : "1253025981532483584",
        "video_info" : {
          "aspect_ratio" : [ "75", "31" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWOkfcuUMAApfW9.mp4"
          } ]
        },
        "id" : "1253025981532483584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWOkfcuUMAApfW9.jpg",
        "sizes" : {
          "medium" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "large" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "124",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "124",
            "h" : "124",
            "resize" : "crop"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/K0Xa16xkuu"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/9iUyLbk3sp",
        "expanded_url" : "https://www.youtube.com/watch?v=b1wjoBlhH_M",
        "display_url" : "youtube.com/watch?v=b1wjoB…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253024223208984577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253024223208984577",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 22 18:13:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/9iUyLbk3sp",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253016085869113344/photo/1",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/fQNqfNPFHg",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWObewDU8AE2H1r.jpg",
        "id_str" : "1253016073936367617",
        "id" : "1253016073936367617",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWObewDU8AE2H1r.jpg",
        "sizes" : {
          "large" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/fQNqfNPFHg"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "id_str" : "1253016085869113344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253016085869113344",
    "possibly_sensitive" : false,
    "created_at" : "Wed Apr 22 17:41:29 +0000 2020",
    "favorited" : false,
    "full_text" : "Happy Earth Day. https://t.co/fQNqfNPFHg",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1253016085869113344/photo/1",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/fQNqfNPFHg",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWObewDU8AE2H1r.jpg",
        "id_str" : "1253016073936367617",
        "video_info" : {
          "aspect_ratio" : [ "125", "96" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWObewDU8AE2H1r.mp4"
          } ]
        },
        "id" : "1253016073936367617",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWObewDU8AE2H1r.jpg",
        "sizes" : {
          "large" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "250",
            "h" : "192",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/fQNqfNPFHg"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "141" ],
    "favorite_count" : "0",
    "id_str" : "1252880615491293184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252880615491293184",
    "created_at" : "Wed Apr 22 08:43:10 +0000 2020",
    "favorited" : false,
    "full_text" : "“That’s how they’re gonna do it man. They’re going to pump us full of fear for months then release a vaccine. That’s how they’ll get us man.”",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "84" ],
    "favorite_count" : "0",
    "id_str" : "1252743614972583936",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1252743614972583936",
    "created_at" : "Tue Apr 21 23:38:47 +0000 2020",
    "favorited" : false,
    "full_text" : "If you really wanna get people going start asking “So, have you been immunized yet?”",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1270191471329591301/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/Zn70PcHMM9",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EaCgaBNUEAAWM3_.jpg",
        "id_str" : "1270191463779799040",
        "id" : "1270191463779799040",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EaCgaBNUEAAWM3_.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Zn70PcHMM9"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1270191471329591301",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1270191471329591301",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jun 09 03:10:20 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Zn70PcHMM9",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1270191471329591301/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/Zn70PcHMM9",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EaCgaBNUEAAWM3_.jpg",
        "id_str" : "1270191463779799040",
        "video_info" : {
          "aspect_ratio" : [ "120", "91" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EaCgaBNUEAAWM3_.mp4"
          } ]
        },
        "id" : "1270191463779799040",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EaCgaBNUEAAWM3_.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "364",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/Zn70PcHMM9"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1270191096333602816/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/GCf1ej5V6O",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EaCgENkVAAAzFHj.jpg",
        "id_str" : "1270191089140432896",
        "id" : "1270191089140432896",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EaCgENkVAAAzFHj.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/GCf1ej5V6O"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1270191096333602816",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1270191096333602816",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jun 09 03:08:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/GCf1ej5V6O",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1270191096333602816/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/GCf1ej5V6O",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EaCgENkVAAAzFHj.jpg",
        "id_str" : "1270191089140432896",
        "video_info" : {
          "aspect_ratio" : [ "249", "140" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EaCgENkVAAAzFHj.mp4"
          } ]
        },
        "id" : "1270191089140432896",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EaCgENkVAAAzFHj.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/GCf1ej5V6O"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wjrpqvN0ib",
        "expanded_url" : "https://www.youtube.com/watch?v=3LC7s0UyaDs&feature=youtu.be",
        "display_url" : "youtube.com/watch?v=3LC7s0…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1259323961910804481",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1259323961910804481",
    "possibly_sensitive" : false,
    "created_at" : "Sun May 10 03:26:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wjrpqvN0ib",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1254998801057644544/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/dOkEnqq87w",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWqmwLbUwAAO9s6.jpg",
        "id_str" : "1254998792807432192",
        "id" : "1254998792807432192",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWqmwLbUwAAO9s6.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/dOkEnqq87w"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1254998801057644544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254998801057644544",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 28 05:00:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Missing the point. https://t.co/dOkEnqq87w",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1254998801057644544/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/dOkEnqq87w",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EWqmwLbUwAAO9s6.jpg",
        "id_str" : "1254998792807432192",
        "video_info" : {
          "aspect_ratio" : [ "110", "111" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EWqmwLbUwAAO9s6.mp4"
          } ]
        },
        "id" : "1254998792807432192",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EWqmwLbUwAAO9s6.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "222",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/dOkEnqq87w"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/kBsiow8XHv",
        "expanded_url" : "https://www.tskoli.is/",
        "display_url" : "tskoli.is",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254958333741522944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254958333741522944",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 28 02:19:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/kBsiow8XHv",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/3IJYe9slkX",
        "expanded_url" : "https://www.youtube.com/watch?v=EotznoKUm9Q",
        "display_url" : "youtube.com/watch?v=Eotzno…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254955307450593282",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254955307450593282",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 28 02:07:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3IJYe9slkX",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/paxP8Hvtgl",
        "expanded_url" : "https://www.google.com/maps/@64.1481781,-21.9414883,3a,75y,98.47h,85.22t/data=!3m8!1e1!3m6!1sAF1QipOulf9_QjEcXodkaWfHXRtEgUv_QTOf_-RhRUhw!2e10!3e11!6shttps:%2F%2Flh5.googleusercontent.com%2Fp%2FAF1QipOulf9_QjEcXodkaWfHXRtEgUv_QTOf_-RhRUhw%3Dw203-h100-k-no-pi0-ya313.43265-ro-0-fo100!7i5660!8i2830",
        "display_url" : "google.com/maps/@64.14817…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254955164579983360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254955164579983360",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 28 02:06:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/paxP8Hvtgl",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/346tbXpCdh",
        "expanded_url" : "https://www.youtube.com/watch?v=xJjCnWm5cvE",
        "display_url" : "youtube.com/watch?v=xJjCnW…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254947933197238272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254947933197238272",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 28 01:37:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/346tbXpCdh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mfAbU93QA7",
        "expanded_url" : "https://m.youtube.com/watch?v=a8zUG57iLns",
        "display_url" : "m.youtube.com/watch?v=a8zUG5…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254893072158056449",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254893072158056449",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 27 21:59:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/mfAbU93QA7",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/slpQcB3oE9",
        "expanded_url" : "https://www.youtube.com/watch?v=GRiC35zeziU",
        "display_url" : "youtube.com/watch?v=GRiC35…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254591021465231360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254591021465231360",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 27 01:59:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/slpQcB3oE9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/jJTXyXge0T",
        "expanded_url" : "https://www.youtube.com/watch?v=nBHkIWAJitg",
        "display_url" : "youtube.com/watch?v=nBHkIW…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254589919374131200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254589919374131200",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 27 01:55:20 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jJTXyXge0T",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/PAkfsCbofW",
        "expanded_url" : "https://m.youtube.com/watch?v=UcRtFYAz2Yo",
        "display_url" : "m.youtube.com/watch?v=UcRtFY…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254561513123135488",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254561513123135488",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 27 00:02:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/PAkfsCbofW",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/3oe5B5zkc1",
        "expanded_url" : "https://youtu.be/q9q5BoEgvUU",
        "display_url" : "youtu.be/q9q5BoEgvUU",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254448676002385920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254448676002385920",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 26 16:34:05 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3oe5B5zkc1",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qtpkkc42zQ",
        "expanded_url" : "https://www.youtube.com/watch?v=9EcjWd-O4jI",
        "display_url" : "youtube.com/watch?v=9EcjWd…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254443798056165377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254443798056165377",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 26 16:14:42 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qtpkkc42zQ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wqbjYmXR8X",
        "expanded_url" : "https://www.youtube.com/watch?v=spyTqeP8i7c",
        "display_url" : "youtube.com/watch?v=spyTqe…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254441697481613312",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254441697481613312",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 26 16:06:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wqbjYmXR8X",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NYRwulofNt",
        "expanded_url" : "https://www.youtube.com/watch?v=o15TNTxyva8&feature=emb_title",
        "display_url" : "youtube.com/watch?v=o15TNT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254441289338089474",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254441289338089474",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 26 16:04:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NYRwulofNt",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/U7XM4XOzua",
        "expanded_url" : "http://viewsync.net/watch?v=thwgYTSugw4&t=0&v=tFMo3UJ4B4g&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=thwgYT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1254439765316759554",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1254439765316759554",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 26 15:58:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/U7XM4XOzua",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Oyb5bViLR9",
        "expanded_url" : "https://youtu.be/xaPepCVepCg",
        "display_url" : "youtu.be/xaPepCVepCg",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1253794990695698432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253794990695698432",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 24 21:16:34 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Oyb5bViLR9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "79" ],
    "favorite_count" : "0",
    "id_str" : "1253526075713269761",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253526075713269761",
    "created_at" : "Fri Apr 24 03:28:00 +0000 2020",
    "favorited" : false,
    "full_text" : "High pitch sounds all night. Being tazed through walls and floors. Rays. Daily.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1288279463109619712/photo/1",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/HvJdMO11KX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EeDjVvFUYAEQui5.jpg",
        "id_str" : "1288279455983493121",
        "id" : "1288279455983493121",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EeDjVvFUYAEQui5.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          },
          "large" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HvJdMO11KX"
      } ],
      "hashtags" : [ {
        "text" : "breckenridge",
        "indices" : [ "0", "13" ]
      }, {
        "text" : "breckenridgecolorado",
        "indices" : [ "14", "35" ]
      }, {
        "text" : "colorado",
        "indices" : [ "36", "45" ]
      } ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1288279463109619712",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1288279463109619712",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 29 01:05:33 +0000 2020",
    "favorited" : false,
    "full_text" : "#breckenridge #breckenridgecolorado #colorado https://t.co/HvJdMO11KX",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1288279463109619712/photo/1",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/HvJdMO11KX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EeDjVvFUYAEQui5.jpg",
        "id_str" : "1288279455983493121",
        "video_info" : {
          "aspect_ratio" : [ "245", "184" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EeDjVvFUYAEQui5.mp4"
          } ]
        },
        "id" : "1288279455983493121",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EeDjVvFUYAEQui5.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          },
          "large" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "490",
            "h" : "368",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/HvJdMO11KX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/dbnUIbScxF",
        "expanded_url" : "https://imgur.com/gallery/nacCMdT",
        "display_url" : "imgur.com/gallery/nacCMdT",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1288274939888336896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1288274939888336896",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 29 00:47:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/dbnUIbScxF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/N3uBYlKmKV",
        "expanded_url" : "https://www.youtube.com/watch?v=_WQvvanjP4Y",
        "display_url" : "youtube.com/watch?v=_WQvva…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1286061719853252608",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286061719853252608",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 22:13:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/N3uBYlKmKV",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cMB3uQeNcK",
        "expanded_url" : "https://www.youtube.com/watch?v=3LC7s0UyaDs",
        "display_url" : "youtube.com/watch?v=3LC7s0…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1286055919843860480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286055919843860480",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 21:49:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cMB3uQeNcK",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/sw6MN5udux",
        "expanded_url" : "https://www.youtube.com/watch?v=a8zUG57iLns",
        "display_url" : "youtube.com/watch?v=a8zUG5…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1286055874650226688",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286055874650226688",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 21:49:48 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/sw6MN5udux",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/5ZSWszJtP3",
        "expanded_url" : "https://www.youtube.com/watch?v=cZZ4ve922S4",
        "display_url" : "youtube.com/watch?v=cZZ4ve…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1286055757687881728",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286055757687881728",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 21:49:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/5ZSWszJtP3",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Ec1JaVDoVv",
        "expanded_url" : "https://www.youtube.com/watch?v=o66FUc61MvU",
        "display_url" : "youtube.com/watch?v=o66FUc…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1286055174801244160",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286055174801244160",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 21:47:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Ec1JaVDoVv not stonks",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/S9WGIRBoGN",
        "expanded_url" : "https://www.youtube.com/watch?v=uZg8PYgL47E",
        "display_url" : "youtube.com/watch?v=uZg8PY…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1286043459371982849",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286043459371982849",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 21:00:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/S9WGIRBoGN",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ovyOudkw15",
        "expanded_url" : "https://www.youtube.com/watch?v=N0Wn3Eey6dY",
        "display_url" : "youtube.com/watch?v=N0Wn3E…",
        "indices" : [ "143", "166" ]
      } ]
    },
    "display_text_range" : [ "0", "166" ],
    "favorite_count" : "0",
    "id_str" : "1285746106500972544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285746106500972544",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 01:18:54 +0000 2020",
    "favorited" : false,
    "full_text" : "If I'm wrong at least you have a good story to tell about that time you moved into middle America and lived on spam and potatos for two years. https://t.co/ovyOudkw15",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/PrvsKxw9eP",
        "expanded_url" : "https://www.google.com/search?client=firefox-b-e&q=global+urban+population",
        "display_url" : "google.com/search?client=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285746075064651776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285746075064651776",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 01:18:46 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/PrvsKxw9eP",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NZo2mpQqbv",
        "expanded_url" : "https://news.google.com/covid19/map?hl=en-CA&mid=/m/0d060g&gl=CA&ceid=CA:en",
        "display_url" : "news.google.com/covid19/map?hl…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285743398284955651",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285743398284955651",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 01:08:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NZo2mpQqbv",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/pxMospkdrt",
        "expanded_url" : "https://music.apple.com/ca/album/mean-what-you-say/714630088",
        "display_url" : "music.apple.com/ca/album/mean-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "159" ],
    "favorite_count" : "0",
    "id_str" : "1285740924161548288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285740924161548288",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 00:58:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/pxMospkdrt \"Get out of the city, Stock up on food, guns and ammo.\" The name of the game is going to be extreme isolation for a few years. I think.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/l4mPAfDtUw",
        "expanded_url" : "https://www.youtube.com/watch?v=OV8Pxqoey2M",
        "display_url" : "youtube.com/watch?v=OV8Pxq…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1285714660466012163/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/3nKsix0FmG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EdfGqkqUcAASSuc.jpg",
        "id_str" : "1285714653335547904",
        "id" : "1285714653335547904",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EdfGqkqUcAASSuc.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3nKsix0FmG"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1285714660466012163",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285714660466012163",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 23:13:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/l4mPAfDtUw https://t.co/3nKsix0FmG",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1285714660466012163/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/3nKsix0FmG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EdfGqkqUcAASSuc.jpg",
        "id_str" : "1285714653335547904",
        "video_info" : {
          "aspect_ratio" : [ "19", "12" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EdfGqkqUcAASSuc.mp4"
          } ]
        },
        "id" : "1285714653335547904",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EdfGqkqUcAASSuc.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "380",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/3nKsix0FmG"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/im58xffcD8",
        "expanded_url" : "https://en.wikipedia.org/wiki/Allied_Force_Headquarters",
        "display_url" : "en.wikipedia.org/wiki/Allied_Fo…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285713003967545344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285713003967545344",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 23:07:22 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/im58xffcD8",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/TqGN8rxKiM",
        "expanded_url" : "https://www.youtube.com/watch?v=P2fPmyH6Q6E",
        "display_url" : "youtube.com/watch?v=P2fPmy…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285712524101529601",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285712524101529601",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 23:05:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/TqGN8rxKiM",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NBmMZ0lLkq",
        "expanded_url" : "https://www.youtube.com/watch?v=QFcv5Ma8u8k",
        "display_url" : "youtube.com/watch?v=QFcv5M…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285705454547619843",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285705454547619843",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:37:22 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NBmMZ0lLkq",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qNra4FVlQZ",
        "expanded_url" : "https://www.youtube.com/watch?v=zkEvxrjRvU4",
        "display_url" : "youtube.com/watch?v=zkEvxr…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699947548024832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699947548024832",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:15:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qNra4FVlQZ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1285699549403783169/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/BSp8awyNlq",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ede47ACUYAAjC2S.jpg",
        "id_str" : "1285699542399082496",
        "id" : "1285699542399082496",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ede47ACUYAAjC2S.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          },
          "large" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/BSp8awyNlq"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699549403783169",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699549403783169",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:13:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/BSp8awyNlq",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1285699549403783169/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/BSp8awyNlq",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ede47ACUYAAjC2S.jpg",
        "id_str" : "1285699542399082496",
        "video_info" : {
          "aspect_ratio" : [ "175", "96" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Ede47ACUYAAjC2S.mp4"
          } ]
        },
        "id" : "1285699542399082496",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ede47ACUYAAjC2S.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          },
          "large" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "350",
            "h" : "192",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/BSp8awyNlq"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CQoww7EeKW",
        "expanded_url" : "https://www.youtube.com/watch?v=HYM_dT-LD1E",
        "display_url" : "youtube.com/watch?v=HYM_dT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699415815184384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699415815184384",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:13:22 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CQoww7EeKW",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NuaCytD7bq",
        "expanded_url" : "https://www.youtube.com/watch?v=aDJi5r6DuP0",
        "display_url" : "youtube.com/watch?v=aDJi5r…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699345615118337",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699345615118337",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:13:05 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NuaCytD7bq",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Gsg2nm8pfa",
        "expanded_url" : "https://www.youtube.com/watch?v=3toDGoetgoI",
        "display_url" : "youtube.com/watch?v=3toDGo…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699283182915584",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699283182915584",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:12:50 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Gsg2nm8pfa",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/aeJLq0LSjn",
        "expanded_url" : "https://www.youtube.com/watch?v=dn3j6-yQKWQ",
        "display_url" : "youtube.com/watch?v=dn3j6-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1285699114974552064",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285699114974552064",
    "possibly_sensitive" : false,
    "created_at" : "Tue Jul 21 22:12:10 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/aeJLq0LSjn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1284760397577248768/photo/1",
        "indices" : [ "43", "66" ],
        "url" : "https://t.co/kCbLm4waNR",
        "media_url" : "http://pbs.twimg.com/media/EdRis2jUMAEXfyO.png",
        "id_str" : "1284760316404838401",
        "id" : "1284760316404838401",
        "media_url_https" : "https://pbs.twimg.com/media/EdRis2jUMAEXfyO.png",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "645",
            "resize" : "fit"
          },
          "large" : {
            "w" : "878",
            "h" : "833",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "878",
            "h" : "833",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kCbLm4waNR"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1284760397577248768",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1284760397577248768",
    "possibly_sensitive" : false,
    "created_at" : "Sun Jul 19 08:02:03 +0000 2020",
    "favorited" : false,
    "full_text" : "Geo - Crypto regarding population control. https://t.co/kCbLm4waNR",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1284760397577248768/photo/1",
        "indices" : [ "43", "66" ],
        "url" : "https://t.co/kCbLm4waNR",
        "media_url" : "http://pbs.twimg.com/media/EdRis2jUMAEXfyO.png",
        "id_str" : "1284760316404838401",
        "id" : "1284760316404838401",
        "media_url_https" : "https://pbs.twimg.com/media/EdRis2jUMAEXfyO.png",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "645",
            "resize" : "fit"
          },
          "large" : {
            "w" : "878",
            "h" : "833",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "878",
            "h" : "833",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kCbLm4waNR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/YR79YbaPxK",
        "expanded_url" : "https://www.youtube.com/watch?v=E5cbJpWlYCA",
        "display_url" : "youtube.com/watch?v=E5cbJp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1284760284813357058",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1284760284813357058",
    "possibly_sensitive" : false,
    "created_at" : "Sun Jul 19 08:01:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/YR79YbaPxK",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/x8pbPSthwD",
        "expanded_url" : "https://www.youtube.com/watch?v=R7yfISlGLNU",
        "display_url" : "youtube.com/watch?v=R7yfIS…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291830603868803072/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/aSBpIaGaSO",
        "media_url" : "http://pbs.twimg.com/media/Ee2BFamUMAAOkCw.jpg",
        "id_str" : "1291830598164557824",
        "id" : "1291830598164557824",
        "media_url_https" : "https://pbs.twimg.com/media/Ee2BFamUMAAOkCw.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/aSBpIaGaSO"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291830603868803072",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291830603868803072",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 20:16:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/x8pbPSthwD https://t.co/aSBpIaGaSO",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291830603868803072/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/aSBpIaGaSO",
        "media_url" : "http://pbs.twimg.com/media/Ee2BFamUMAAOkCw.jpg",
        "id_str" : "1291830598164557824",
        "id" : "1291830598164557824",
        "media_url_https" : "https://pbs.twimg.com/media/Ee2BFamUMAAOkCw.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/aSBpIaGaSO"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/uOWQsXg3yK",
        "expanded_url" : "https://www.youtube.com/watch?v=qv9YI8Oqs30",
        "display_url" : "youtube.com/watch?v=qv9YI8…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291817391643455488/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/sCZH6PTgIi",
        "media_url" : "http://pbs.twimg.com/media/Ee103UvUwAAulQu.jpg",
        "id_str" : "1291817161934028800",
        "id" : "1291817161934028800",
        "media_url_https" : "https://pbs.twimg.com/media/Ee103UvUwAAulQu.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1080",
            "h" : "607",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1080",
            "h" : "607",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "382",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/sCZH6PTgIi"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291817391643455488",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291817391643455488",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 19:24:01 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/uOWQsXg3yK https://t.co/sCZH6PTgIi",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291817391643455488/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/sCZH6PTgIi",
        "media_url" : "http://pbs.twimg.com/media/Ee103UvUwAAulQu.jpg",
        "id_str" : "1291817161934028800",
        "id" : "1291817161934028800",
        "media_url_https" : "https://pbs.twimg.com/media/Ee103UvUwAAulQu.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1080",
            "h" : "607",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1080",
            "h" : "607",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "382",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/sCZH6PTgIi"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291807684375638016/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/jF1Q0YpK4U",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee1sO78UwAAT9YD.jpg",
        "id_str" : "1291807671989878784",
        "id" : "1291807671989878784",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee1sO78UwAAT9YD.jpg",
        "sizes" : {
          "large" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/jF1Q0YpK4U"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291807684375638016",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291807684375638016",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 18:45:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jF1Q0YpK4U",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291807684375638016/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/jF1Q0YpK4U",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee1sO78UwAAT9YD.jpg",
        "id_str" : "1291807671989878784",
        "video_info" : {
          "aspect_ratio" : [ "80", "41" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Ee1sO78UwAAT9YD.mp4"
          } ]
        },
        "id" : "1291807671989878784",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee1sO78UwAAT9YD.jpg",
        "sizes" : {
          "large" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "246",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/jF1Q0YpK4U"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/N7BSpAdAGH",
        "expanded_url" : "https://www.youtube.com/watch?v=yrwTDfdck7I",
        "display_url" : "youtube.com/watch?v=yrwTDf…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291807456687845377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291807456687845377",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 18:44:32 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/N7BSpAdAGH",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/WcdIy0WTFn",
        "expanded_url" : "https://www.youtube.com/watch?v=I2sYeqF4urM",
        "display_url" : "youtube.com/watch?v=I2sYeq…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291802684639473664",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291802684639473664",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 18:25:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/WcdIy0WTFn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291802179339079681/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/4rPQU8e6TJ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee1nOy7U0AEgdgd.jpg",
        "id_str" : "1291802172011630593",
        "id" : "1291802172011630593",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee1nOy7U0AEgdgd.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/4rPQU8e6TJ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291802179339079681",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291802179339079681",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 18:23:34 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/4rPQU8e6TJ",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291802179339079681/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/4rPQU8e6TJ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee1nOy7U0AEgdgd.jpg",
        "id_str" : "1291802172011630593",
        "video_info" : {
          "aspect_ratio" : [ "1", "1" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Ee1nOy7U0AEgdgd.mp4"
          } ]
        },
        "id" : "1291802172011630593",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee1nOy7U0AEgdgd.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "220",
            "h" : "220",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/4rPQU8e6TJ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cJweCXBIZW",
        "expanded_url" : "https://www.youtube.com/watch?v=itWc60jVm58",
        "display_url" : "youtube.com/watch?v=itWc60…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/ulXyCQgUru",
        "expanded_url" : "https://www.youtube.com/watch?v=wWCXuxU1yuI",
        "display_url" : "youtube.com/watch?v=wWCXux…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/IjRBMXcxoj",
        "expanded_url" : "https://www.youtube.com/watch?v=RbWJG86qqWM",
        "display_url" : "youtube.com/watch?v=RbWJG8…",
        "indices" : [ "48", "71" ]
      }, {
        "url" : "https://t.co/i2UlHk1sFk",
        "expanded_url" : "https://en.wikipedia.org/wiki/British_royal_family",
        "display_url" : "en.wikipedia.org/wiki/British_r…",
        "indices" : [ "72", "95" ]
      } ]
    },
    "display_text_range" : [ "0", "95" ],
    "favorite_count" : "0",
    "id_str" : "1291799808554889217",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291799808554889217",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 18:14:09 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cJweCXBIZW https://t.co/ulXyCQgUru https://t.co/IjRBMXcxoj https://t.co/i2UlHk1sFk",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1t7bPzJRxl",
        "expanded_url" : "https://genius.com/Hacktivist-false-idols-lyrics",
        "display_url" : "genius.com/Hacktivist-fal…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/lnRyOJvGA7",
        "expanded_url" : "https://www.youtube.com/watch?v=QgvMSw6Quf8",
        "display_url" : "youtube.com/watch?v=QgvMSw…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/jZ0DWTvcJN",
        "expanded_url" : "https://en.wikipedia.org/wiki/Hacktivist_(band)",
        "display_url" : "en.wikipedia.org/wiki/Hacktivis…",
        "indices" : [ "48", "71" ]
      } ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1291507243859341315",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291507243859341315",
    "possibly_sensitive" : false,
    "created_at" : "Thu Aug 06 22:51:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1t7bPzJRxl https://t.co/lnRyOJvGA7 https://t.co/jZ0DWTvcJN",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lfPQu80srF",
        "expanded_url" : "https://www.youtube.com/watch?v=JrBdYmStZJ4",
        "display_url" : "youtube.com/watch?v=JrBdYm…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/eMXoD3Ig8o",
        "expanded_url" : "https://en.wikipedia.org/wiki/The_Wachowskis",
        "display_url" : "en.wikipedia.org/wiki/The_Wacho…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291476099151454209",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291476099151454209",
    "possibly_sensitive" : false,
    "created_at" : "Thu Aug 06 20:47:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lfPQu80srF https://t.co/eMXoD3Ig8o",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "Lebanon",
        "indices" : [ "39", "47" ]
      }, {
        "text" : "LebanonExplosion",
        "indices" : [ "57", "74" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qprY7raN29",
        "expanded_url" : "https://www.youtube.com/watch?v=518uB9qnQdI",
        "display_url" : "youtube.com/watch?v=518uB9…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1291474997559488512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291474997559488512",
    "possibly_sensitive" : false,
    "created_at" : "Thu Aug 06 20:43:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qprY7raN29 Foreign aid in #Lebanon be like. #LebanonExplosion",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291206532223262720/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/vJsjkCXI8Z",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EetJfP3VoAA51si.jpg",
        "id_str" : "1291206519355187200",
        "id" : "1291206519355187200",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EetJfP3VoAA51si.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "large" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/vJsjkCXI8Z"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291206532223262720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291206532223262720",
    "possibly_sensitive" : false,
    "created_at" : "Thu Aug 06 02:56:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/vJsjkCXI8Z",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291206532223262720/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/vJsjkCXI8Z",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EetJfP3VoAA51si.jpg",
        "id_str" : "1291206519355187200",
        "video_info" : {
          "aspect_ratio" : [ "69", "58" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EetJfP3VoAA51si.mp4"
          } ]
        },
        "id" : "1291206519355187200",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EetJfP3VoAA51si.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "large" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/vJsjkCXI8Z"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/alorv4TMuq",
        "expanded_url" : "https://www.youtube.com/watch?v=aDaOgu2CQtI",
        "display_url" : "youtube.com/watch?v=aDaOgu…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1291153798170370048",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291153798170370048",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 23:27:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/alorv4TMuq If i have a say in the matter",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0GyNtJKXGV",
        "expanded_url" : "https://www.youtube.com/watch?v=Ps2Jc28tQrw",
        "display_url" : "youtube.com/watch?v=Ps2Jc2…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291147066580692992",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291147066580692992",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 23:00:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0GyNtJKXGV",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rUhrWbm13v",
        "expanded_url" : "https://www.youtube.com/watch?v=4THFRpw68oQ",
        "display_url" : "youtube.com/watch?v=4THFRp…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/rjJ0axTCeP",
        "expanded_url" : "https://en.wikipedia.org/wiki/AJR_(band)",
        "display_url" : "en.wikipedia.org/wiki/AJR_(band)",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/t6LjuVmrAw",
        "expanded_url" : "https://en.wikipedia.org/wiki/Bertelsmann_Music_Group",
        "display_url" : "en.wikipedia.org/wiki/Bertelsma…",
        "indices" : [ "48", "71" ]
      }, {
        "url" : "https://t.co/sarznz6W6G",
        "expanded_url" : "https://en.wikipedia.org/wiki/Black_Butter_Records",
        "display_url" : "en.wikipedia.org/wiki/Black_But…",
        "indices" : [ "72", "95" ]
      }, {
        "url" : "https://t.co/PfBv9q86ph",
        "expanded_url" : "https://en.wikipedia.org/wiki/Warner_Records",
        "display_url" : "en.wikipedia.org/wiki/Warner_Re…",
        "indices" : [ "96", "119" ]
      } ]
    },
    "display_text_range" : [ "0", "119" ],
    "favorite_count" : "0",
    "id_str" : "1291145144020766720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291145144020766720",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 22:52:45 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/rUhrWbm13v https://t.co/rjJ0axTCeP https://t.co/t6LjuVmrAw https://t.co/sarznz6W6G https://t.co/PfBv9q86ph",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "id_str" : "1291143572444418048",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291143572444418048",
    "created_at" : "Wed Aug 05 22:46:30 +0000 2020",
    "favorited" : false,
    "full_text" : "Maybe, Just fucking maybe.......",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wm3wNqc9Fz",
        "expanded_url" : "https://en.wikipedia.org/wiki/Volumes_(band)",
        "display_url" : "en.wikipedia.org/wiki/Volumes_(…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/rxTaWKjTLQ",
        "expanded_url" : "https://en.wikipedia.org/wiki/Mediaskare_Records",
        "display_url" : "en.wikipedia.org/wiki/Mediaskar…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/5JhL6f5ueJ",
        "expanded_url" : "https://en.wikipedia.org/wiki/Century_Media_Recordshttps://en.wikipedia.org/wiki/Fearless_Records",
        "display_url" : "en.wikipedia.org/wiki/Century_M…",
        "indices" : [ "48", "71" ]
      }, {
        "url" : "https://t.co/yYcl3J6FHD",
        "expanded_url" : "https://en.wikipedia.org/wiki/Sony_Music",
        "display_url" : "en.wikipedia.org/wiki/Sony_Music",
        "indices" : [ "72", "95" ]
      } ]
    },
    "display_text_range" : [ "0", "95" ],
    "favorite_count" : "0",
    "id_str" : "1291141923315490818",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291141923315490818",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 22:39:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wm3wNqc9Fz https://t.co/rxTaWKjTLQ https://t.co/5JhL6f5ueJ https://t.co/yYcl3J6FHD",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/n5cRV6nZPS",
        "expanded_url" : "https://www.youtube.com/watch?v=4s594xwW09g",
        "display_url" : "youtube.com/watch?v=4s594x…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/JEsyRUoUDx",
        "expanded_url" : "https://en.wikipedia.org/wiki/Presidency_of_Donald_Trump",
        "display_url" : "en.wikipedia.org/wiki/Presidenc…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291141328412188672",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291141328412188672",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 22:37:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/n5cRV6nZPS https://t.co/JEsyRUoUDx",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291130646052536320/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/DhUz32saM6",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EesEeayU0AAzU3X.jpg",
        "id_str" : "1291130638804766720",
        "id" : "1291130638804766720",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EesEeayU0AAzU3X.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/DhUz32saM6"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291130646052536320",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291130646052536320",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 21:55:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/DhUz32saM6",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291130646052536320/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/DhUz32saM6",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EesEeayU0AAzU3X.jpg",
        "id_str" : "1291130638804766720",
        "video_info" : {
          "aspect_ratio" : [ "125", "72" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EesEeayU0AAzU3X.mp4"
          } ]
        },
        "id" : "1291130638804766720",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EesEeayU0AAzU3X.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "288",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/DhUz32saM6"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Q5KnXrM7tC",
        "expanded_url" : "https://en.wikipedia.org/wiki/Conditions_(band)",
        "display_url" : "en.wikipedia.org/wiki/Condition…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291128597151748096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291128597151748096",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 21:47:00 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Q5KnXrM7tC",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qj42Bf9jgo",
        "expanded_url" : "https://www.youtube.com/watch?v=CEq8z44KlxI",
        "display_url" : "youtube.com/watch?v=CEq8z4…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291128216485126145/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/GxdAcuBMdR",
        "media_url" : "http://pbs.twimg.com/media/EesCQLSUwAAp7qV.jpg",
        "id_str" : "1291128195102588928",
        "id" : "1291128195102588928",
        "media_url_https" : "https://pbs.twimg.com/media/EesCQLSUwAAp7qV.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/GxdAcuBMdR"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291128216485126145",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291128216485126145",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 21:45:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qj42Bf9jgo https://t.co/GxdAcuBMdR",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291128216485126145/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/GxdAcuBMdR",
        "media_url" : "http://pbs.twimg.com/media/EesCQLSUwAAp7qV.jpg",
        "id_str" : "1291128195102588928",
        "id" : "1291128195102588928",
        "media_url_https" : "https://pbs.twimg.com/media/EesCQLSUwAAp7qV.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "320",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/GxdAcuBMdR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/R4djMLYims",
        "expanded_url" : "https://vimeo.com/9201084",
        "display_url" : "vimeo.com/9201084",
        "indices" : [ "7", "30" ]
      } ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1291105522129616896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291105522129616896",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 05 20:15:18 +0000 2020",
    "favorited" : false,
    "full_text" : "ummmmm https://t.co/R4djMLYims",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "219" ],
    "favorite_count" : "0",
    "id_str" : "1290913831284174850",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1290913831284174850",
    "created_at" : "Wed Aug 05 07:33:36 +0000 2020",
    "favorited" : false,
    "full_text" : "I was on a clickhole last night and was reading about wako and was on a page about Oklahoma, ended up reading about ammonia nitrate bombs. For me, there is a correlation. The question now is who had the intent to do it.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291952893965213697/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/MUhrgMFDwr",
        "media_url" : "http://pbs.twimg.com/media/Ee3wS5VUwAA3kiB.jpg",
        "id_str" : "1291952875543773184",
        "id" : "1291952875543773184",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3wS5VUwAA3kiB.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MUhrgMFDwr"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291952893965213697",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291952893965213697",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 04:22:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/MUhrgMFDwr",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291952893965213697/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/MUhrgMFDwr",
        "media_url" : "http://pbs.twimg.com/media/Ee3wS5VUwAA3kiB.jpg",
        "id_str" : "1291952875543773184",
        "id" : "1291952875543773184",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3wS5VUwAA3kiB.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MUhrgMFDwr"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291952460810973184/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/Qlmd7rYNkt",
        "media_url" : "http://pbs.twimg.com/media/Ee3v5jcUcAA0Qaz.jpg",
        "id_str" : "1291952440170803200",
        "id" : "1291952440170803200",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3v5jcUcAA0Qaz.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Qlmd7rYNkt"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291952460810973184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291952460810973184",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 04:20:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Qlmd7rYNkt",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291952460810973184/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/Qlmd7rYNkt",
        "media_url" : "http://pbs.twimg.com/media/Ee3v5jcUcAA0Qaz.jpg",
        "id_str" : "1291952440170803200",
        "id" : "1291952440170803200",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3v5jcUcAA0Qaz.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Qlmd7rYNkt"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/346tbXpCdh",
        "expanded_url" : "https://www.youtube.com/watch?v=xJjCnWm5cvE",
        "display_url" : "youtube.com/watch?v=xJjCnW…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291938028445814784",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291938028445814784",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 03:23:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/346tbXpCdh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0fee847D58",
        "expanded_url" : "https://www.youtube.com/watch?v=oo9gkV9EvVA",
        "display_url" : "youtube.com/watch?v=oo9gkV…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291936979592966145",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291936979592966145",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 03:19:13 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0fee847D58",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/sqIvW6PdJX",
        "expanded_url" : "https://www.youtube.com/watch?v=N68t7NvuTgQ",
        "display_url" : "youtube.com/watch?v=N68t7N…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291927983372951552",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291927983372951552",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:43:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/sqIvW6PdJX",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/laYN2KcBHq",
        "expanded_url" : "https://www.youtube.com/watch?v=8P2d2o6Vs5A",
        "display_url" : "youtube.com/watch?v=8P2d2o…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291927320568033280",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291927320568033280",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:40:50 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/laYN2KcBHq",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/gjihEUikL3",
        "expanded_url" : "https://www.youtube.com/watch?v=ye0H91hxUMw",
        "display_url" : "youtube.com/watch?v=ye0H91…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291925780738367488",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291925780738367488",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:34:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/gjihEUikL3",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "129" ],
    "favorite_count" : "0",
    "id_str" : "1291924878262558721",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291924878262558721",
    "created_at" : "Sat Aug 08 02:31:08 +0000 2020",
    "favorited" : false,
    "full_text" : "Don't pull that black magic shit with me just because I saw the word \"Ammonia Nitrate\" on a Wikipedia article! Fuck you! NO FEAR!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/fq6GAOLec7",
        "expanded_url" : "https://www.youtube.com/watch?v=EqQuihD0hoI",
        "display_url" : "youtube.com/watch?v=EqQuih…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291924534606483459",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291924534606483459",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:29:46 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/fq6GAOLec7",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tnoUTnHS26",
        "expanded_url" : "https://www.youtube.com/watch?v=ubIpoPjBUds",
        "display_url" : "youtube.com/watch?v=ubIpoP…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291924047685537794",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291924047685537794",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:27:50 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/tnoUTnHS26",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/2JREEN05tU",
        "expanded_url" : "https://grapevine.is/page/26/?s=fire",
        "display_url" : "grapevine.is/page/26/?s=fire",
        "indices" : [ "15", "38" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291923019602915328/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/3yzO9eVELT",
        "media_url" : "http://pbs.twimg.com/media/Ee3VCJqU8AEFs0G.jpg",
        "id_str" : "1291922901055107073",
        "id" : "1291922901055107073",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3VCJqU8AEFs0G.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3yzO9eVELT"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1291923019602915328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291923019602915328",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:23:45 +0000 2020",
    "favorited" : false,
    "full_text" : "(squinty eyes) https://t.co/2JREEN05tU https://t.co/3yzO9eVELT",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291923019602915328/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/3yzO9eVELT",
        "media_url" : "http://pbs.twimg.com/media/Ee3VCJqU8AEFs0G.jpg",
        "id_str" : "1291922901055107073",
        "id" : "1291922901055107073",
        "media_url_https" : "https://pbs.twimg.com/media/Ee3VCJqU8AEFs0G.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3yzO9eVELT"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/c4v8LjSHjt",
        "expanded_url" : "https://grapevine.is/news/2016/03/16/man-confesses-to-arson/",
        "display_url" : "grapevine.is/news/2016/03/1…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "id_str" : "1291922680619270144",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291922680619270144",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:22:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/c4v8LjSHjt We saw that shit coming!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "iceland",
        "indices" : [ "0", "8" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/pcYLyBhsht",
        "expanded_url" : "https://www.youtube.com/watch?v=50dvRikt-YU",
        "display_url" : "youtube.com/watch?v=50dvRi…",
        "indices" : [ "9", "32" ]
      } ]
    },
    "display_text_range" : [ "0", "90" ],
    "favorite_count" : "0",
    "id_str" : "1291919015686762496",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291919015686762496",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 02:07:50 +0000 2020",
    "favorited" : false,
    "full_text" : "#iceland https://t.co/pcYLyBhsht these mfs. send me the link to the warehouse fire please.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "225" ],
    "favorite_count" : "0",
    "id_str" : "1291918573040857088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291918573040857088",
    "created_at" : "Sat Aug 08 02:06:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Remember that warehouse fire in Iceland in 2016? The same reason I left Canada is the same shit these mother fuckers are pulling still to this day. There's no good guys there's no bad guys. I need to get the fuck out of here.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "106" ],
    "favorite_count" : "0",
    "id_str" : "1291916774527574017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291916774527574017",
    "created_at" : "Sat Aug 08 01:58:56 +0000 2020",
    "favorited" : false,
    "full_text" : "In fact you are the same mother fuckers who have been targeting me for years! Connect the dots here folks.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "125" ],
    "favorite_count" : "0",
    "id_str" : "1291916550148993027",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291916550148993027",
    "created_at" : "Sat Aug 08 01:58:02 +0000 2020",
    "favorited" : false,
    "full_text" : "You will never find me talking in craft via any Canadian platform regarding intelligence. Anyone claiming to is full of shit!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291871503122759680/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/x14MR6eXM9",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee2mR-dUMAAP77X.jpg",
        "id_str" : "1291871495879143424",
        "id" : "1291871495879143424",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee2mR-dUMAAP77X.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          },
          "small" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/x14MR6eXM9"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291871503122759680",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291871503122759680",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 22:59:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/x14MR6eXM9",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291871503122759680/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/x14MR6eXM9",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee2mR-dUMAAP77X.jpg",
        "id_str" : "1291871495879143424",
        "video_info" : {
          "aspect_ratio" : [ "179", "122" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Ee2mR-dUMAAP77X.mp4"
          } ]
        },
        "id" : "1291871495879143424",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee2mR-dUMAAP77X.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          },
          "small" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "358",
            "h" : "244",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/x14MR6eXM9"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Cd8eiXwHPv",
        "expanded_url" : "https://www.youtube.com/watch?v=T_D3d1RWBrI",
        "display_url" : "youtube.com/watch?v=T_D3d1…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291871018223407104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291871018223407104",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 22:57:07 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Cd8eiXwHPv",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "0",
    "id_str" : "1291860874672578560",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291860874672578560",
    "created_at" : "Fri Aug 07 22:16:48 +0000 2020",
    "favorited" : false,
    "full_text" : "THE FALLEN",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/b6MwCjlsQl",
        "expanded_url" : "https://www.youtube.com/watch?v=OEvM8KnMeuU",
        "display_url" : "youtube.com/watch?v=OEvM8K…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291859534156189696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291859534156189696",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 22:11:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/b6MwCjlsQl",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/3WW4grQlOe",
        "expanded_url" : "https://www.youtube.com/watch?v=umUjCxbAM_Y",
        "display_url" : "youtube.com/watch?v=umUjCx…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291854552098996226",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291854552098996226",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 21:51:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3WW4grQlOe",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/jIzLYERZez",
        "expanded_url" : "https://en.wikipedia.org/wiki/2016_Brussels_bombings",
        "display_url" : "en.wikipedia.org/wiki/2016_Brus…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291843097534410752",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291843097534410752",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 21:06:10 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jIzLYERZez",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/uIzM7QwNOn",
        "expanded_url" : "https://en.wikipedia.org/wiki/November_2015_Paris_attacks",
        "display_url" : "en.wikipedia.org/wiki/November_…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291843002277609474",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291843002277609474",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 21:05:47 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/uIzM7QwNOn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/UaUDXTAuYw",
        "expanded_url" : "https://www.youtube.com/watch?v=QOmTtG3skHs",
        "display_url" : "youtube.com/watch?v=QOmTtG…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1291835250444603392",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291835250444603392",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 20:34:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/UaUDXTAuYw",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/amAiX6Py7H",
        "expanded_url" : "https://www.youtube.com/watch?v=4h6bjyvlbpM",
        "display_url" : "youtube.com/watch?v=4h6bjy…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291833203322322945/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/JgXGUe5HC9",
        "media_url" : "http://pbs.twimg.com/media/Ee2DaoeUYAAxNAU.jpg",
        "id_str" : "1291833161689620480",
        "id" : "1291833161689620480",
        "media_url_https" : "https://pbs.twimg.com/media/Ee2DaoeUYAAxNAU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          },
          "large" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/JgXGUe5HC9"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1291833203322322945",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291833203322322945",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 07 20:26:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/amAiX6Py7H https://t.co/JgXGUe5HC9",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1291833203322322945/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/JgXGUe5HC9",
        "media_url" : "http://pbs.twimg.com/media/Ee2DaoeUYAAxNAU.jpg",
        "id_str" : "1291833161689620480",
        "id" : "1291833161689620480",
        "media_url_https" : "https://pbs.twimg.com/media/Ee2DaoeUYAAxNAU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          },
          "large" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "444",
            "h" : "252",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/JgXGUe5HC9"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/XIZuFl8dWS",
        "expanded_url" : "https://www.youtube.com/watch?v=dJB0BkJlbbw",
        "display_url" : "youtube.com/watch?v=dJB0Bk…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292884173141622784",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292884173141622784",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 18:03:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/XIZuFl8dWS",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/4xp6Ns2Z4C",
        "expanded_url" : "https://www.youtube.com/watch?v=_YEscK-H1t8",
        "display_url" : "youtube.com/watch?v=_YEscK…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "242" ],
    "favorite_count" : "0",
    "id_str" : "1292879232008245248",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292879232008245248",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 17:43:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/4xp6Ns2Z4C \"Where were you when they had no faith in us?\nWhere were you when they shut us out?\nIt's funny you show up now\nAnd if it fell apart I know that you'd be nowhere to be found.\nWe did this on our own.\nThanks for nothing!\"",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "0",
    "id_str" : "1292870100085661696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292870100085661696",
    "created_at" : "Mon Aug 10 17:07:06 +0000 2020",
    "favorited" : false,
    "full_text" : "They’re angry. Targeting. Shit talking. Gaslighting increase.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iKEqxOdcup",
        "expanded_url" : "https://www.youtube.com/watch?v=xjatJ36cJvM",
        "display_url" : "youtube.com/watch?v=xjatJ3…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292727904971849729",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292727904971849729",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:42:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/iKEqxOdcup",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/j0NqPRsj01",
        "expanded_url" : "https://www.youtube.com/watch?v=bLGFwkRx2HA",
        "display_url" : "youtube.com/watch?v=bLGFwk…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292727836277485568",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292727836277485568",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:41:48 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/j0NqPRsj01",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/7VNGX1mfr8",
        "expanded_url" : "https://www.youtube.com/watch?v=SN6jcMruHfA",
        "display_url" : "youtube.com/watch?v=SN6jcM…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292725696083554304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292725696083554304",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:33:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/7VNGX1mfr8",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292721220480143366/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/uj2YgOef5B",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfCrGCZUcAE7_z3.jpg",
        "id_str" : "1292721213265965057",
        "id" : "1292721213265965057",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfCrGCZUcAE7_z3.jpg",
        "sizes" : {
          "medium" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/uj2YgOef5B"
      } ],
      "hashtags" : [ {
        "text" : "Thoseniggas",
        "indices" : [ "0", "12" ]
      } ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1292721220480143366",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292721220480143366",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:15:31 +0000 2020",
    "favorited" : false,
    "full_text" : "#Thoseniggas https://t.co/uj2YgOef5B",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292721220480143366/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/uj2YgOef5B",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfCrGCZUcAE7_z3.jpg",
        "id_str" : "1292721213265965057",
        "video_info" : {
          "aspect_ratio" : [ "83", "44" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EfCrGCZUcAE7_z3.mp4"
          } ]
        },
        "id" : "1292721213265965057",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfCrGCZUcAE7_z3.jpg",
        "sizes" : {
          "medium" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "264",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/uj2YgOef5B"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/PaA5RcbqGP",
        "expanded_url" : "https://www.youtube.com/watch?v=89PKBpGm4bQ",
        "display_url" : "youtube.com/watch?v=89PKBp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292720946135015424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292720946135015424",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:14:25 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/PaA5RcbqGP",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1292719259072622592",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292719259072622592",
    "created_at" : "Mon Aug 10 07:07:43 +0000 2020",
    "favorited" : false,
    "full_text" : "2808 song is 4 minutes and 11 seconds long.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/HSgRgpjGr3",
        "expanded_url" : "https://www.youtube.com/watch?v=DzyKSyLavUY",
        "display_url" : "youtube.com/watch?v=DzyKSy…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/rqSs0d8XjU",
        "expanded_url" : "https://en.wikipedia.org/wiki/Welcome_Reality",
        "display_url" : "en.wikipedia.org/wiki/Welcome_R…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1292719108295778304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292719108295778304",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 07:07:07 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/HSgRgpjGr3 https://t.co/rqSs0d8XjU",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "lebanonleak",
        "indices" : [ "5", "17" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "id_str" : "1292714347261616128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292714347261616128",
    "created_at" : "Mon Aug 10 06:48:12 +0000 2020",
    "favorited" : false,
    "full_text" : "Just #lebanonleak relevant intel",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "id_str" : "1292713828937953282",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292713828937953282",
    "created_at" : "Mon Aug 10 06:46:08 +0000 2020",
    "favorited" : false,
    "full_text" : "Episodes 15 -&gt;",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "82" ],
    "favorite_count" : "0",
    "id_str" : "1292711410972024832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292711410972024832",
    "created_at" : "Mon Aug 10 06:36:32 +0000 2020",
    "favorited" : false,
    "full_text" : "There's a bunch of shots regarding the Lebanon explosion in Bobs Burgers Seasons 7",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "203" ],
    "favorite_count" : "0",
    "id_str" : "1292616978276872192",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292616978276872192",
    "created_at" : "Mon Aug 10 00:21:17 +0000 2020",
    "favorited" : false,
    "full_text" : "If Canadian intelligence called they'd have to own up to the fact they have been targeting me and doing psyops on me. Which has been going on for years. I'd say theres parallels in behavior and language.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "102" ],
    "favorite_count" : "0",
    "id_str" : "1292608706329239553",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292608706329239553",
    "created_at" : "Sun Aug 09 23:48:25 +0000 2020",
    "favorited" : false,
    "full_text" : "\"why buy the cow when you can get the milk for free\" truly colleagues in the \"intelligence\" community.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1292608248441266176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292608248441266176",
    "created_at" : "Sun Aug 09 23:46:36 +0000 2020",
    "favorited" : false,
    "full_text" : "All this gnarly shit, my phone hasn't so much as rang.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/FV1ABfauA2",
        "expanded_url" : "https://www.youtube.com/watch?v=VcOQM5qH77U",
        "display_url" : "youtube.com/watch?v=VcOQM5…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292188103474438144",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292188103474438144",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 19:57:06 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/FV1ABfauA2",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292179653918994432/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/sB7TsYVnzX",
        "media_url" : "http://pbs.twimg.com/media/Ee6-ijYUMAASwjU.jpg",
        "id_str" : "1292179643923968000",
        "id" : "1292179643923968000",
        "media_url_https" : "https://pbs.twimg.com/media/Ee6-ijYUMAASwjU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "836",
            "h" : "836",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "836",
            "h" : "836",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/sB7TsYVnzX"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292179653918994432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292179653918994432",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 19:23:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/sB7TsYVnzX",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292179653918994432/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/sB7TsYVnzX",
        "media_url" : "http://pbs.twimg.com/media/Ee6-ijYUMAASwjU.jpg",
        "id_str" : "1292179643923968000",
        "id" : "1292179643923968000",
        "media_url_https" : "https://pbs.twimg.com/media/Ee6-ijYUMAASwjU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "836",
            "h" : "836",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "836",
            "h" : "836",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/sB7TsYVnzX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1ZagUczaAi",
        "expanded_url" : "https://www.youtube.com/watch?v=F46r-_jPPHY",
        "display_url" : "youtube.com/watch?v=F46r-_…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1292178225397788672",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292178225397788672",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 19:17:51 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1ZagUczaAi they're pushing it",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292174335935803392/photo/1",
        "indices" : [ "74", "97" ],
        "url" : "https://t.co/mytfrJTHcj",
        "media_url" : "http://pbs.twimg.com/media/Ee65h-zUEAAoHTu.jpg",
        "id_str" : "1292174136546955264",
        "id" : "1292174136546955264",
        "media_url_https" : "https://pbs.twimg.com/media/Ee65h-zUEAAoHTu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/mytfrJTHcj"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "97" ],
    "favorite_count" : "0",
    "id_str" : "1292174335935803392",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292174335935803392",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 19:02:23 +0000 2020",
    "favorited" : false,
    "full_text" : "The Devil and His projections. That's a cube on top of the RBC in Regina. https://t.co/mytfrJTHcj",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292174335935803392/photo/1",
        "indices" : [ "74", "97" ],
        "url" : "https://t.co/mytfrJTHcj",
        "media_url" : "http://pbs.twimg.com/media/Ee65h-zUEAAoHTu.jpg",
        "id_str" : "1292174136546955264",
        "id" : "1292174136546955264",
        "media_url_https" : "https://pbs.twimg.com/media/Ee65h-zUEAAoHTu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/mytfrJTHcj"
      }, {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292174335935803392/photo/1",
        "indices" : [ "74", "97" ],
        "url" : "https://t.co/mytfrJTHcj",
        "media_url" : "http://pbs.twimg.com/media/Ee65jf6UMAA68Vy.jpg",
        "id_str" : "1292174162614562816",
        "id" : "1292174162614562816",
        "media_url_https" : "https://pbs.twimg.com/media/Ee65jf6UMAA68Vy.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1680",
            "h" : "1050",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/mytfrJTHcj"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/zGrBtpRSsO",
        "expanded_url" : "https://www.youtube.com/watch?v=IJmIGC0nwK0",
        "display_url" : "youtube.com/watch?v=IJmIGC…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292167636936081409",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292167636936081409",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 18:35:46 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/zGrBtpRSsO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/kPBbBg9PO0",
        "expanded_url" : "https://www.youtube.com/watch?v=B7iIS91fMAc",
        "display_url" : "youtube.com/watch?v=B7iIS9…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292160561011019776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292160561011019776",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 18:07:39 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/kPBbBg9PO0",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/5GUGxVkMcC",
        "expanded_url" : "https://en.wikipedia.org/wiki/Danish_Security_and_Intelligence_Service",
        "display_url" : "en.wikipedia.org/wiki/Danish_Se…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292160282496602112/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/0OeCZtXdVg",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee6s7KTVoAIZ7sT.jpg",
        "id_str" : "1292160275479633922",
        "id" : "1292160275479633922",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee6s7KTVoAIZ7sT.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0OeCZtXdVg"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1292160282496602112",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292160282496602112",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 18:06:33 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/5GUGxVkMcC https://t.co/0OeCZtXdVg",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292160282496602112/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/0OeCZtXdVg",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ee6s7KTVoAIZ7sT.jpg",
        "id_str" : "1292160275479633922",
        "video_info" : {
          "aspect_ratio" : [ "83", "62" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Ee6s7KTVoAIZ7sT.mp4"
          } ]
        },
        "id" : "1292160275479633922",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ee6s7KTVoAIZ7sT.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "372",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/0OeCZtXdVg"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mRJSOiiewC",
        "expanded_url" : "https://www.youtube.com/watch?v=eC-F_VZ2T1c",
        "display_url" : "youtube.com/watch?v=eC-F_V…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/66qdtrtSm9",
        "expanded_url" : "https://en.wikipedia.org/wiki/Nordic_Council",
        "display_url" : "en.wikipedia.org/wiki/Nordic_Co…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1292159013770031104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292159013770031104",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 18:01:30 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/mRJSOiiewC https://t.co/66qdtrtSm9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/jeYcjTlceo",
        "expanded_url" : "https://www.youtube.com/watch?v=rmtU2WJfPgU",
        "display_url" : "youtube.com/watch?v=rmtU2W…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292156947110617090",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292156947110617090",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 08 17:53:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jeYcjTlceo",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/GT3dkoS34x",
        "expanded_url" : "https://youtu.be/EqjkWNsePoU?t=6077",
        "display_url" : "youtu.be/EqjkWNsePoU?t=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1293991901608083456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293991901608083456",
    "possibly_sensitive" : false,
    "created_at" : "Thu Aug 13 19:24:45 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/GT3dkoS34x Lebanon, Iran... etc...",
    "lang" : "es"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xUl1XQlzbR",
        "expanded_url" : "https://www.youtube.com/watch?v=IrUodQTv_Po",
        "display_url" : "youtube.com/watch?v=IrUodQ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293447856804651008",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293447856804651008",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 07:22:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/xUl1XQlzbR",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Rvof5RGwBG",
        "expanded_url" : "https://www.youtube.com/watch?v=F6qSR1QYeQE",
        "display_url" : "youtube.com/watch?v=F6qSR1…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293445144235012096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293445144235012096",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 07:12:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Rvof5RGwBG",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/eapTa6RSlB",
        "expanded_url" : "https://www.youtube.com/watch?v=w8HdOHrc3OQ",
        "display_url" : "youtube.com/watch?v=w8HdOH…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293442262534299653",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293442262534299653",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 07:00:41 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/eapTa6RSlB",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/54uZ9i1Dyq",
        "expanded_url" : "https://www.youtube.com/watch?v=qBVEmTyU-xk",
        "display_url" : "youtube.com/watch?v=qBVEmT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293439282758053892",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293439282758053892",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 06:48:50 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/54uZ9i1Dyq",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/6fUlYxcw2B",
        "expanded_url" : "https://www.youtube.com/watch?v=nZyzLTnBa2g",
        "display_url" : "youtube.com/watch?v=nZyzLT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293363192605716481",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293363192605716481",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:46:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/6fUlYxcw2B",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mIgvm59e1a",
        "expanded_url" : "https://www.youtube.com/watch?v=Gnbs0OKKClQ",
        "display_url" : "youtube.com/watch?v=Gnbs0O…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293363176789090305",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293363176789090305",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:46:25 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/mIgvm59e1a",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1Qsl3Vs59Q",
        "expanded_url" : "https://www.youtube.com/watch?v=s2uxh-wR9fc",
        "display_url" : "youtube.com/watch?v=s2uxh-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293361766282362880",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293361766282362880",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:40:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1Qsl3Vs59Q",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/GpU6Hz40fS",
        "expanded_url" : "https://www.youtube.com/watch?v=Wf3jzDb4H7o",
        "display_url" : "youtube.com/watch?v=Wf3jzD…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293357236396277760",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293357236396277760",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:22:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/GpU6Hz40fS",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lCt7qhkYNo",
        "expanded_url" : "https://www.youtube.com/watch?v=ASMQxb87hdY",
        "display_url" : "youtube.com/watch?v=ASMQxb…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/SyyOL6gIuo",
        "expanded_url" : "https://www.youtube.com/watch?v=11eBZd7zdbs",
        "display_url" : "youtube.com/watch?v=11eBZd…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1293356000527839233",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293356000527839233",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:17:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lCt7qhkYNo https://t.co/SyyOL6gIuo",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/dFrgGJgYcA",
        "expanded_url" : "https://www.youtube.com/watch?v=EpWGhCTw_l8",
        "display_url" : "youtube.com/watch?v=EpWGhC…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/Dy1yMsIYOS",
        "expanded_url" : "https://en.wikipedia.org/wiki/Say_Anything_(band)",
        "display_url" : "en.wikipedia.org/wiki/Say_Anyth…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1293355575162462208",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293355575162462208",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 12 01:16:13 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/dFrgGJgYcA https://t.co/Dy1yMsIYOS",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/p6jzi8M7EL",
        "expanded_url" : "https://www.youtube.com/watch?v=iLedPuUA5tM",
        "display_url" : "youtube.com/watch?v=iLedPu…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293024340032671750",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293024340032671750",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:20:00 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/p6jzi8M7EL",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/4yyFnAlNsx",
        "expanded_url" : "https://en.wikipedia.org/wiki/GCHQ",
        "display_url" : "en.wikipedia.org/wiki/GCHQ",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1293022507943911424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293022507943911424",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:12:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/4yyFnAlNsx &lt;--- This butthole",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rz41rMQYSF",
        "expanded_url" : "https://www.youtube.com/watch?v=ycH9dGXq13w",
        "display_url" : "youtube.com/watch?v=ycH9dG…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293022146902417408",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293022146902417408",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:11:17 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/rz41rMQYSF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/H45de0PP47",
        "expanded_url" : "https://www.youtube.com/watch?v=h2zgB93KANE",
        "display_url" : "youtube.com/watch?v=h2zgB9…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293021730533851138",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293021730533851138",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:09:38 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/H45de0PP47",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qcNLiTGwCz",
        "expanded_url" : "https://www.youtube.com/watch?v=LDsxtBVLyss",
        "display_url" : "youtube.com/watch?v=LDsxtB…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/3huSYzdClO",
        "expanded_url" : "https://www.youtube.com/watch?v=nlIQ2KCYG7Y",
        "display_url" : "youtube.com/watch?v=nlIQ2K…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1293020685128708098",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293020685128708098",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:05:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/qcNLiTGwCz https://t.co/3huSYzdClO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xJeWXUM0xl",
        "expanded_url" : "https://www.youtube.com/watch?v=svZ666KgWqM",
        "display_url" : "youtube.com/watch?v=svZ666…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293019917680222208",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293019917680222208",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 03:02:26 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/xJeWXUM0xl",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1293018356698636289/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/duJCS8hhWP",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfG5Vd0UEAIbjPi.jpg",
        "id_str" : "1293018346464481282",
        "id" : "1293018346464481282",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfG5Vd0UEAIbjPi.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/duJCS8hhWP"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1293018356698636289",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293018356698636289",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 02:56:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/duJCS8hhWP",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1293018356698636289/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/duJCS8hhWP",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfG5Vd0UEAIbjPi.jpg",
        "id_str" : "1293018346464481282",
        "video_info" : {
          "aspect_ratio" : [ "249", "121" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EfG5Vd0UEAIbjPi.mp4"
          } ]
        },
        "id" : "1293018346464481282",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfG5Vd0UEAIbjPi.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "242",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/duJCS8hhWP"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iakYly3O96",
        "expanded_url" : "https://www.youtube.com/watch?v=tNnlYyByWQQ",
        "display_url" : "youtube.com/watch?v=tNnlYy…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/e6in4ordv9",
        "expanded_url" : "https://en.wikipedia.org/wiki/Evergreen_(Broods_album)",
        "display_url" : "en.wikipedia.org/wiki/Evergreen…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1293017961595191296",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1293017961595191296",
    "possibly_sensitive" : false,
    "created_at" : "Tue Aug 11 02:54:39 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/iakYly3O96 https://t.co/e6in4ordv9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/X85vf2uQhC",
        "expanded_url" : "https://www.youtube.com/watch?v=bWZw_saplr4",
        "display_url" : "youtube.com/watch?v=bWZw_s…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292904563935043584",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292904563935043584",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 19:24:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/X85vf2uQhC",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rGNX0lYOg0",
        "expanded_url" : "https://www.youtube.com/watch?v=vfm-oitJ5N4",
        "display_url" : "youtube.com/watch?v=vfm-oi…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292899070801874944/photo/1",
        "indices" : [ "78", "101" ],
        "url" : "https://t.co/wPzb3VdPNV",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfFM2T1U0AAUMYf.jpg",
        "id_str" : "1292899063952625664",
        "id" : "1292899063952625664",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfFM2T1U0AAUMYf.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/wPzb3VdPNV"
      } ],
      "hashtags" : [ {
        "text" : "prettymuch",
        "indices" : [ "66", "77" ]
      } ]
    },
    "display_text_range" : [ "0", "101" ],
    "favorite_count" : "0",
    "id_str" : "1292899070801874944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292899070801874944",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 19:02:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/rGNX0lYOg0 abandon ship. you're on your own fuckers. #prettymuch https://t.co/wPzb3VdPNV",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1292899070801874944/photo/1",
        "indices" : [ "78", "101" ],
        "url" : "https://t.co/wPzb3VdPNV",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfFM2T1U0AAUMYf.jpg",
        "id_str" : "1292899063952625664",
        "video_info" : {
          "aspect_ratio" : [ "249", "136" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EfFM2T1U0AAUMYf.mp4"
          } ]
        },
        "id" : "1292899063952625664",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfFM2T1U0AAUMYf.jpg",
        "sizes" : {
          "large" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "272",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/wPzb3VdPNV"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/dk2bZq3MUr",
        "expanded_url" : "https://www.youtube.com/watch?v=S6FozSwCaDA",
        "display_url" : "youtube.com/watch?v=S6FozS…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292889196604977152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292889196604977152",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 18:22:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/dk2bZq3MUr",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/jJTXyXge0T",
        "expanded_url" : "https://www.youtube.com/watch?v=nBHkIWAJitg",
        "display_url" : "youtube.com/watch?v=nBHkIW…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292886442167820288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292886442167820288",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 18:12:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jJTXyXge0T",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ZL9linU8ZC",
        "expanded_url" : "https://www.youtube.com/watch?v=WTw51Ynkn7A",
        "display_url" : "youtube.com/watch?v=WTw51Y…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1292885318648000512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1292885318648000512",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 10 18:07:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ZL9linU8ZC",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ "0", "7" ],
        "id_str" : "15647676",
        "id" : "15647676"
      } ],
      "urls" : [ {
        "url" : "https://t.co/4abSBRvz7j",
        "expanded_url" : "https://youtu.be/poiWToILTFA",
        "display_url" : "youtu.be/poiWToILTFA",
        "indices" : [ "13", "36" ]
      } ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1239574562171486209",
    "id_str" : "1239580688891785218",
    "in_reply_to_user_id" : "15647676",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239580688891785218",
    "in_reply_to_status_id" : "1239574562171486209",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 15:54:01 +0000 2020",
    "favorited" : false,
    "full_text" : "@DHSgov Rofl https://t.co/4abSBRvz7j",
    "lang" : "en",
    "in_reply_to_screen_name" : "DHSgov",
    "in_reply_to_user_id_str" : "15647676"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "82", "90" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/Z33iTP0htL",
        "expanded_url" : "https://youtu.be/4WMmCtkhWi0",
        "display_url" : "youtu.be/4WMmCtkhWi0",
        "indices" : [ "54", "77" ]
      } ]
    },
    "display_text_range" : [ "0", "90" ],
    "favorite_count" : "0",
    "id_str" : "1239383526480338944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239383526480338944",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 02:50:34 +0000 2020",
    "favorited" : false,
    "full_text" : "A Day To Remember - Have Faith In Me (Official Video) https://t.co/Z33iTP0htL via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1239383074380472322",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239383074380472322",
    "created_at" : "Mon Mar 16 02:48:46 +0000 2020",
    "favorited" : false,
    "full_text" : "Cow water overboard boat field.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "75", "83" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/6Vp98YSdby",
        "expanded_url" : "https://youtu.be/Z3d7y1YrPvg",
        "display_url" : "youtu.be/Z3d7y1YrPvg",
        "indices" : [ "47", "70" ]
      } ]
    },
    "display_text_range" : [ "0", "114" ],
    "favorite_count" : "0",
    "id_str" : "1239381918728073217",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239381918728073217",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 02:44:10 +0000 2020",
    "favorited" : false,
    "full_text" : "28 Weeks Later (2007) Opening Scene (HD/60fps) https://t.co/6Vp98YSdby via @YouTube effects the elderly the worst?",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/WrZp21C73R",
        "expanded_url" : "https://music.apple.com/ca/album/bitches-aint-s-t/6654037?i=6654035",
        "display_url" : "music.apple.com/ca/album/bitch…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "id_str" : "1239060272733507584",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239060272733507584",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 05:26:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/WrZp21C73R",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "61", "69" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/9cJsS8wnjU",
        "expanded_url" : "https://youtu.be/r1x1o9UZn8M",
        "display_url" : "youtu.be/r1x1o9UZn8M",
        "indices" : [ "33", "56" ]
      } ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "2",
    "id_str" : "1239021718540173315",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239021718540173315",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 02:52:52 +0000 2020",
    "favorited" : false,
    "full_text" : "Darkest Hour - The Sadist Nation https://t.co/9cJsS8wnjU via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/PkJq0mdUOn",
        "expanded_url" : "https://music.apple.com/ca/album/best-mistake-mass-fx-remix/881847467?i=881847723",
        "display_url" : "music.apple.com/ca/album/best-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "id_str" : "1239021110047330304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239021110047330304",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 02:50:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/PkJq0mdUOn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LnoEq0SDgn",
        "expanded_url" : "https://music.apple.com/ca/album/forever/1113221212",
        "display_url" : "music.apple.com/ca/album/forev…",
        "indices" : [ "14", "37" ]
      } ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1239020655040802816",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239020655040802816",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 02:48:38 +0000 2020",
    "favorited" : false,
    "full_text" : "This HP cell? https://t.co/LnoEq0SDgn",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xv8t2MtIUQ",
        "expanded_url" : "https://music.apple.com/ca/album/%C3%B8-disambiguation-deluxe-edition/720136546",
        "display_url" : "music.apple.com/ca/album/%C3%B…",
        "indices" : [ "9", "32" ]
      } ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "id_str" : "1239020464787189760",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239020464787189760",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 02:47:53 +0000 2020",
    "favorited" : false,
    "full_text" : "Germans? https://t.co/xv8t2MtIUQ",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/8OVlRy96aM",
        "expanded_url" : "https://music.apple.com/ca/album/full-of-war/613220624",
        "display_url" : "music.apple.com/ca/album/full-…",
        "indices" : [ "10", "33" ]
      } ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "id_str" : "1239020289825968128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239020289825968128",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 15 02:47:11 +0000 2020",
    "favorited" : false,
    "full_text" : "Italians? https://t.co/8OVlRy96aM",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "138" ],
    "favorite_count" : "0",
    "id_str" : "1239019918093217794",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239019918093217794",
    "created_at" : "Sun Mar 15 02:45:43 +0000 2020",
    "favorited" : false,
    "full_text" : "They could be playing both sides like ive seen in the past. Either way. There’s a conversation about it’s release and now global pandemic.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "268" ],
    "favorite_count" : "0",
    "id_str" : "1239019671082299393",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239019671082299393",
    "created_at" : "Sun Mar 15 02:44:44 +0000 2020",
    "favorited" : false,
    "full_text" : "Intel: Trust me or not. IDGAF. There appears to be a pissing contest going on between cells or agencies regarding the release of COVID-19. I think it’s more so classes. But the conversation was threats and then go ahead. That being said I’m going off intel from music.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Cenk Uygur",
        "screen_name" : "cenkuygur",
        "indices" : [ "0", "10" ],
        "id_str" : "429227921",
        "id" : "429227921"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "84" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1238979045053751297",
    "id_str" : "1238982431585103874",
    "in_reply_to_user_id" : "429227921",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238982431585103874",
    "in_reply_to_status_id" : "1238979045053751297",
    "created_at" : "Sun Mar 15 00:16:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@cenkuygur It’s not just healthcare. It effects all industries not just governments.",
    "lang" : "en",
    "in_reply_to_screen_name" : "cenkuygur",
    "in_reply_to_user_id_str" : "429227921"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "122" ],
    "favorite_count" : "0",
    "id_str" : "1238945980352880640",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238945980352880640",
    "created_at" : "Sat Mar 14 21:51:54 +0000 2020",
    "favorited" : false,
    "full_text" : "Day 2,190: There’s something going on. There’s something going on. There’s something going on. There’s something going on.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "66", "74" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/aDo6vDQVpg",
        "expanded_url" : "https://youtu.be/wAIe9QtRKlc",
        "display_url" : "youtu.be/wAIe9QtRKlc",
        "indices" : [ "38", "61" ]
      } ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1238928599060631553",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238928599060631553",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 20:42:50 +0000 2020",
    "favorited" : false,
    "full_text" : "Trailer park boys - rocket appliances https://t.co/aDo6vDQVpg via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238928332667760640/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/11QOKtXhRA",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETGOv4EUcAAt2pl.jpg",
        "id_str" : "1238928325659095040",
        "id" : "1238928325659095040",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETGOv4EUcAAt2pl.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          },
          "small" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/11QOKtXhRA"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1238928332667760640",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238928332667760640",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 20:41:47 +0000 2020",
    "favorited" : false,
    "full_text" : "Weponization. https://t.co/11QOKtXhRA",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238928332667760640/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/11QOKtXhRA",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETGOv4EUcAAt2pl.jpg",
        "id_str" : "1238928325659095040",
        "video_info" : {
          "aspect_ratio" : [ "7", "3" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETGOv4EUcAAt2pl.mp4"
          } ]
        },
        "id" : "1238928325659095040",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETGOv4EUcAAt2pl.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          },
          "small" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          },
          "large" : {
            "w" : "560",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/11QOKtXhRA"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238901201996877824/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/Ucew1WPe7Y",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETF2EzgU4AA7-WM.jpg",
        "id_str" : "1238901197420945408",
        "id" : "1238901197420945408",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETF2EzgU4AA7-WM.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Ucew1WPe7Y"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1238901201996877824",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238901201996877824",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 18:53:58 +0000 2020",
    "favorited" : false,
    "full_text" : "The whole anal bum cover. https://t.co/Ucew1WPe7Y",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238901201996877824/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/Ucew1WPe7Y",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETF2EzgU4AA7-WM.jpg",
        "id_str" : "1238901197420945408",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETF2EzgU4AA7-WM.mp4"
          } ]
        },
        "id" : "1238901197420945408",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETF2EzgU4AA7-WM.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/Ucew1WPe7Y"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Ze3wWpqO6V",
        "expanded_url" : "https://music.apple.com/ca/album/in-completion/720136546?i=720136569",
        "display_url" : "music.apple.com/ca/album/in-co…",
        "indices" : [ "3", "26" ]
      } ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "id_str" : "1238900537350688769",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238900537350688769",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 18:51:20 +0000 2020",
    "favorited" : false,
    "full_text" : "32 https://t.co/Ze3wWpqO6V",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238899890928775168/video/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/2NeAjd2heB",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1238893622428221440/pu/img/d__--XgOPdNn_NYJ.jpg",
        "id_str" : "1238893622428221440",
        "id" : "1238893622428221440",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1238893622428221440/pu/img/d__--XgOPdNn_NYJ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/2NeAjd2heB"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1238899890928775168",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238899890928775168",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 18:48:46 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/2NeAjd2heB",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238899890928775168/video/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/2NeAjd2heB",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1238893622428221440/pu/img/d__--XgOPdNn_NYJ.jpg",
        "id_str" : "1238893622428221440",
        "video_info" : {
          "aspect_ratio" : [ "9", "16" ],
          "duration_millis" : "56327",
          "variants" : [ {
            "bitrate" : "632000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238893622428221440/pu/vid/320x568/FnH4jmjxUuUAw1fe.mp4?tag=10"
          }, {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238893622428221440/pu/vid/720x1280/BSEvv92NuezDmoLW.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238893622428221440/pu/vid/360x640/XHIRhb_epTfNb1OU.mp4?tag=10"
          }, {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1238893622428221440/pu/pl/Q2QezRVj6I9JriNQ.m3u8?tag=10"
          } ]
        },
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1238893622428221440",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1238893622428221440/pu/img/d__--XgOPdNn_NYJ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "display_url" : "pic.twitter.com/2NeAjd2heB"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238893612105994240/video/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/HS1OtJbZSA",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1238889773340585984/pu/img/bbtAeLpE3e7CMnH6.jpg",
        "id_str" : "1238889773340585984",
        "id" : "1238889773340585984",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1238889773340585984/pu/img/bbtAeLpE3e7CMnH6.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HS1OtJbZSA"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1238893612105994240",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238893612105994240",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 18:23:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/HS1OtJbZSA",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238893612105994240/video/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/HS1OtJbZSA",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1238889773340585984/pu/img/bbtAeLpE3e7CMnH6.jpg",
        "id_str" : "1238889773340585984",
        "video_info" : {
          "aspect_ratio" : [ "9", "16" ],
          "duration_millis" : "100115",
          "variants" : [ {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238889773340585984/pu/vid/720x1280/cVk4eqJRWc2Q3emI.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238889773340585984/pu/vid/360x640/4WOT4gDlr_Fvchmz.mp4?tag=10"
          }, {
            "bitrate" : "632000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1238889773340585984/pu/vid/320x568/SrBlmLnii_8XYbQP.mp4?tag=10"
          }, {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1238889773340585984/pu/pl/aiJSdomnyFZhA7uT.m3u8?tag=10"
          } ]
        },
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1238889773340585984",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1238889773340585984/pu/img/bbtAeLpE3e7CMnH6.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "display_url" : "pic.twitter.com/HS1OtJbZSA"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "69", "77" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/KMVI0KcRe9",
        "expanded_url" : "https://youtu.be/7VvkXA6xpqI",
        "display_url" : "youtu.be/7VvkXA6xpqI",
        "indices" : [ "41", "64" ]
      } ]
    },
    "display_text_range" : [ "0", "80" ],
    "favorite_count" : "0",
    "id_str" : "1238864274946060289",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238864274946060289",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 16:27:14 +0000 2020",
    "favorited" : false,
    "full_text" : "Super Mario 64 Voice Clip: \"Here We Go!\" https://t.co/KMVI0KcRe9 via @YouTube no",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1238730732320653312",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238730732320653312",
    "created_at" : "Sat Mar 14 07:36:35 +0000 2020",
    "favorited" : false,
    "full_text" : "Notice how both candidates hair isn’t even rooting for them?",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238674927231750145/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/LdWh1UNVEh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCoQryU4AAsY5z.jpg",
        "id_str" : "1238674902112067584",
        "id" : "1238674902112067584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCoQryU4AAsY5z.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/LdWh1UNVEh"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "id_str" : "1238674927231750145",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238674927231750145",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 14 03:54:50 +0000 2020",
    "favorited" : false,
    "full_text" : "I’m also a Dinosaur Rastafarian. https://t.co/LdWh1UNVEh",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1238674927231750145/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/LdWh1UNVEh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETCoQryU4AAsY5z.jpg",
        "id_str" : "1238674902112067584",
        "video_info" : {
          "aspect_ratio" : [ "133", "100" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETCoQryU4AAsY5z.mp4"
          } ]
        },
        "id" : "1238674902112067584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETCoQryU4AAsY5z.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "266",
            "h" : "200",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/LdWh1UNVEh"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "80" ],
    "favorite_count" : "0",
    "id_str" : "1238673725261664257",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1238673725261664257",
    "created_at" : "Sat Mar 14 03:50:04 +0000 2020",
    "favorited" : false,
    "full_text" : "If anyone asks I’m Black and Mexican. You Don’t Want Any Of This On Lock Nessay!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/k1uXpw5VW8",
        "expanded_url" : "https://en.wikipedia.org/wiki/Underground_City,_Montreal",
        "display_url" : "en.wikipedia.org/wiki/Undergrou…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/NSpIhSdiYA",
        "expanded_url" : "https://en.wikipedia.org/wiki/Canadian_Security_Intelligence_Service#Quebec_Region",
        "display_url" : "en.wikipedia.org/wiki/Canadian_…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1295256728187973632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295256728187973632",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:10:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/k1uXpw5VW8 https://t.co/NSpIhSdiYA 715 Peel St, Montreal, Quebec H3C 1B2",
    "lang" : "fr"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1RWQToOdtc",
        "expanded_url" : "https://www.youtube.com/watch?v=EOfFRDryVQM",
        "display_url" : "youtube.com/watch?v=EOfFRD…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/4AHqCHj7hP",
        "expanded_url" : "https://en.wikipedia.org/wiki/1993_World_Trade_Center_bombing",
        "display_url" : "en.wikipedia.org/wiki/1993_Worl…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/iqPYkFxWPt",
        "expanded_url" : "https://en.wikipedia.org/wiki/Snowdon_station",
        "display_url" : "en.wikipedia.org/wiki/Snowdon_s…",
        "indices" : [ "48", "71" ]
      } ]
    },
    "display_text_range" : [ "0", "224" ],
    "favorite_count" : "1",
    "id_str" : "1295256120005545990",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1295256120005545990",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:08:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1RWQToOdtc https://t.co/4AHqCHj7hP https://t.co/iqPYkFxWPt Codename \"Snowdon\" comes from a Bill Hicks visit to Canada where an audience member leaked in code the location of an underground blacksite in Montreal.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rekt6oUuE2",
        "expanded_url" : "https://www.youtube.com/watch?v=v290M8W-HFI",
        "display_url" : "youtube.com/watch?v=v290M8…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294704721794486272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294704721794486272",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 18:37:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/rekt6oUuE2",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LPWEIXF9vd",
        "expanded_url" : "https://www.youtube.com/watch?v=RfiQYRn7fBg",
        "display_url" : "youtube.com/watch?v=RfiQYR…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294704312245862400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294704312245862400",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 18:35:37 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/LPWEIXF9vd",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/3xvslWY228",
        "expanded_url" : "https://www.youtube.com/watch?v=uqcuoVJXzKY",
        "display_url" : "youtube.com/watch?v=uqcuoV…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/0oSY0FOvlv",
        "expanded_url" : "https://gf.me/u/ykarp3",
        "display_url" : "gf.me/u/ykarp3",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1294692729490796545",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294692729490796545",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 17:49:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3xvslWY228 https://t.co/0oSY0FOvlv",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/3hKE7Tn3M5",
        "expanded_url" : "https://www.youtube.com/watch?v=zwFxXMryRmc",
        "display_url" : "youtube.com/watch?v=zwFxXM…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294691258825183232",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294691258825183232",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 17:43:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/3hKE7Tn3M5",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/WD8RbGlbck",
        "expanded_url" : "https://www.youtube.com/watch?v=zUCC19UpQmg",
        "display_url" : "youtube.com/watch?v=zUCC19…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294689456876687360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294689456876687360",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 17:36:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/WD8RbGlbck",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tEMnwje2e1",
        "expanded_url" : "https://www.youtube.com/watch?v=4eE9_dOuf5s",
        "display_url" : "youtube.com/watch?v=4eE9_d…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294688235621244929",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294688235621244929",
    "possibly_sensitive" : false,
    "created_at" : "Sat Aug 15 17:31:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/tEMnwje2e1",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ucxziUiV60",
        "expanded_url" : "https://www.youtube.com/watch?v=kps4IKAnEWQ",
        "display_url" : "youtube.com/watch?v=kps4IK…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294379595584532480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294379595584532480",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 21:05:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ucxziUiV60",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1jHgNcIOKY",
        "expanded_url" : "https://www.youtube.com/watch?v=7hNDrV14liA",
        "display_url" : "youtube.com/watch?v=7hNDrV…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294378616650776577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294378616650776577",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 21:01:25 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1jHgNcIOKY",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1294345418642345984/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/scArZ3ljHd",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfZwSi4UMAEKdEZ.jpg",
        "id_str" : "1294345406818562049",
        "id" : "1294345406818562049",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfZwSi4UMAEKdEZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/scArZ3ljHd"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294345418642345984",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294345418642345984",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 18:49:30 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/scArZ3ljHd",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1294345418642345984/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/scArZ3ljHd",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EfZwSi4UMAEKdEZ.jpg",
        "id_str" : "1294345406818562049",
        "video_info" : {
          "aspect_ratio" : [ "80", "57" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EfZwSi4UMAEKdEZ.mp4"
          } ]
        },
        "id" : "1294345406818562049",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EfZwSi4UMAEKdEZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "342",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/scArZ3ljHd"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/TMG4bT0jwn",
        "expanded_url" : "https://www.twitter.com/nathanlkoch",
        "display_url" : "twitter.com/nathanlkoch",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294128167368581122",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294128167368581122",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 04:26:13 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/TMG4bT0jwn",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/fC17hEhAh2",
        "expanded_url" : "https://www.youtube.com/watch?v=GZDT-FsO9Uc",
        "display_url" : "youtube.com/watch?v=GZDT-F…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294124586162778112",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294124586162778112",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 04:11:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/fC17hEhAh2",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CBgb1IY5ck",
        "expanded_url" : "https://www.youtube.com/watch?v=GU_QrKzAf4I",
        "display_url" : "youtube.com/watch?v=GU_QrK…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294121350672482304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294121350672482304",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 03:59:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CBgb1IY5ck",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tXhCleQS0I",
        "expanded_url" : "https://nrc.canada.ca/en/certifications-evaluations-standards/canadas-official-time/nrc-shortwave-station-broadcasts-chu",
        "display_url" : "nrc.canada.ca/en/certificati…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294119886348722176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294119886348722176",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 03:53:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/tXhCleQS0I",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/9INbavLNKO",
        "expanded_url" : "https://www.youtube.com/watch?v=i3_dOWYHS7I",
        "display_url" : "youtube.com/watch?v=i3_dOW…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294119221262053377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294119221262053377",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 03:50:40 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/9INbavLNKO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/76mGmfqH9g",
        "expanded_url" : "https://www.youtube.com/watch?v=F8M4L8VnlkA",
        "display_url" : "youtube.com/watch?v=F8M4L8…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294119141855518720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294119141855518720",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 03:50:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/76mGmfqH9g",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cwCLvEkuAo",
        "expanded_url" : "https://www.youtube.com/watch?v=mt84J7U75e0",
        "display_url" : "youtube.com/watch?v=mt84J7…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294113444094869504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294113444094869504",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 03:27:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cwCLvEkuAo",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ybdLThontT",
        "expanded_url" : "https://voyager.jpl.nasa.gov/mission/spacecraft/instruments/rtg/",
        "display_url" : "voyager.jpl.nasa.gov/mission/spacec…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/qGMa0syHWw",
        "expanded_url" : "https://www.youtube.com/watch?v=B3uk5bJcyM8",
        "display_url" : "youtube.com/watch?v=B3uk5b…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/0DwSiOjS1c",
        "expanded_url" : "https://en.wikipedia.org/wiki/Carl_Sagan",
        "display_url" : "en.wikipedia.org/wiki/Carl_Sagan",
        "indices" : [ "48", "71" ]
      } ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1294092688455659520",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294092688455659520",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 02:05:14 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ybdLThontT https://t.co/qGMa0syHWw https://t.co/0DwSiOjS1c",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Qdbc0XkkJm",
        "expanded_url" : "https://en.wikipedia.org/wiki/Nick_Sagan",
        "display_url" : "en.wikipedia.org/wiki/Nick_Sagan",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/dyz3jwWJUS",
        "expanded_url" : "https://www.youtube.com/watch?v=eVF4kebiks4",
        "display_url" : "youtube.com/watch?v=eVF4ke…",
        "indices" : [ "24", "47" ]
      }, {
        "url" : "https://t.co/ps1ZCHnLod",
        "expanded_url" : "https://www.vastspace.ca",
        "display_url" : "vastspace.ca",
        "indices" : [ "48", "71" ]
      } ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1294086791914385408",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294086791914385408",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 01:41:48 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Qdbc0XkkJm https://t.co/dyz3jwWJUS https://t.co/ps1ZCHnLod",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iRQ7ePEM3p",
        "expanded_url" : "https://www.youtube.com/watch?v=W2w3H_oLSIU",
        "display_url" : "youtube.com/watch?v=W2w3H_…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294085140323250176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294085140323250176",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 01:35:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/iRQ7ePEM3p",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/sjrK6tm2EF",
        "expanded_url" : "https://en.wikipedia.org/wiki/Rothschild_family",
        "display_url" : "en.wikipedia.org/wiki/Rothschil…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1294084727272439808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294084727272439808",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 01:33:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/sjrK6tm2EF You guys can kiss my ass too by the way :D",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1294083876633993216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294083876633993216",
    "created_at" : "Fri Aug 14 01:30:13 +0000 2020",
    "favorited" : false,
    "full_text" : "Zeitgeist is their fucking Playbook.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/E4iPKBM9A0",
        "expanded_url" : "https://m.youtube.com/watch?v=Zl5MxbFAO00",
        "display_url" : "m.youtube.com/watch?v=Zl5Mxb…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1294076745847455746",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1294076745847455746",
    "possibly_sensitive" : false,
    "created_at" : "Fri Aug 14 01:01:53 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/E4iPKBM9A0",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tBmvSVvcFx",
        "expanded_url" : "https://www.youtube.com/watch?v=Nqjp4AEyGxA",
        "display_url" : "youtube.com/watch?v=Nqjp4A…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309438971685072896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309438971685072896",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:25:53 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/tBmvSVvcFx",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/EQd3CUVZis",
        "expanded_url" : "https://wikileaks.org/",
        "display_url" : "wikileaks.org",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1309438479793901568/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/NgU344zalt",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EiwPWjmXYAA1OBu.jpg",
        "id_str" : "1309438471845666816",
        "id" : "1309438471845666816",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EiwPWjmXYAA1OBu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NgU344zalt"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1309438479793901568",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309438479793901568",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:23:56 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/EQd3CUVZis https://t.co/NgU344zalt",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1309438479793901568/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/NgU344zalt",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EiwPWjmXYAA1OBu.jpg",
        "id_str" : "1309438471845666816",
        "video_info" : {
          "aspect_ratio" : [ "249", "104" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EiwPWjmXYAA1OBu.mp4"
          } ]
        },
        "id" : "1309438471845666816",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EiwPWjmXYAA1OBu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "208",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/NgU344zalt"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1309437783438696448",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309437783438696448",
    "created_at" : "Fri Sep 25 10:21:10 +0000 2020",
    "favorited" : false,
    "full_text" : "oh they mad",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cgdA9iNaXP",
        "expanded_url" : "http://www.youtubemultiplier.com/5f6dc4825e4e3-utopiashowwikileaksraininafrica.php",
        "display_url" : "youtubemultiplier.com/5f6dc4825e4e3-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309437764161671169",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309437764161671169",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:21:05 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cgdA9iNaXP",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1309427314414022656/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/HE7U5CdTNu",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EiwFMp4XsAMgwZU.jpg",
        "id_str" : "1309427306616827907",
        "id" : "1309427306616827907",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EiwFMp4XsAMgwZU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          },
          "large" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          },
          "small" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HE7U5CdTNu"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309427314414022656",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309427314414022656",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 09:39:34 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/HE7U5CdTNu",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1309427314414022656/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/HE7U5CdTNu",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EiwFMp4XsAMgwZU.jpg",
        "id_str" : "1309427306616827907",
        "video_info" : {
          "aspect_ratio" : [ "125", "79" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EiwFMp4XsAMgwZU.mp4"
          } ]
        },
        "id" : "1309427306616827907",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EiwFMp4XsAMgwZU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          },
          "large" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          },
          "small" : {
            "w" : "250",
            "h" : "158",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/HE7U5CdTNu"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/YELaCXvOzu",
        "expanded_url" : "https://en.wikipedia.org/wiki/Utopia_(British_TV_series)",
        "display_url" : "en.wikipedia.org/wiki/Utopia_(B…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "149" ],
    "favorite_count" : "0",
    "id_str" : "1309426656927461378",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309426656927461378",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 09:36:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/YELaCXvOzu Oh yeah. I forgot about this British TV Show from 2013. Thanks for bring it to my attention! I remember it being super aerie!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rAXGh1J0VT",
        "expanded_url" : "https://www.youtube.com/watch?v=VG5kkTLjp2M",
        "display_url" : "youtube.com/watch?v=VG5kkT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1296148148243410945",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1296148148243410945",
    "possibly_sensitive" : false,
    "created_at" : "Wed Aug 19 18:12:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/rAXGh1J0VT",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/hneTII04rP",
        "expanded_url" : "https://www.youtube.com/watch?v=6K0AmeM3BCQ",
        "display_url" : "youtube.com/watch?v=6K0Ame…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "0",
    "id_str" : "1295423475796996098",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295423475796996098",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 18:13:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/hneTII04rP For the years gone by!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1295272464876859392/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/4YEsobByZX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Efm7bvFUYAAA6Nb.jpg",
        "id_str" : "1295272453015363584",
        "id" : "1295272453015363584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Efm7bvFUYAAA6Nb.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/4YEsobByZX"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295272464876859392",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295272464876859392",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 08:13:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/4YEsobByZX",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathankoch_leak/status/1295272464876859392/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/4YEsobByZX",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Efm7bvFUYAAA6Nb.jpg",
        "id_str" : "1295272453015363584",
        "video_info" : {
          "aspect_ratio" : [ "1", "1" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Efm7bvFUYAAA6Nb.mp4"
          } ]
        },
        "id" : "1295272453015363584",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Efm7bvFUYAAA6Nb.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "498",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/4YEsobByZX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Ap7EcXNlbh",
        "expanded_url" : "https://youtu.be/Gc_nr8U10Lc",
        "display_url" : "youtu.be/Gc_nr8U10Lc",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295264353914982400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295264353914982400",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:41:01 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Ap7EcXNlbh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/KeExasWDmh",
        "expanded_url" : "https://www.youtube.com/watch?v=qBvcjfxJCxQ",
        "display_url" : "youtube.com/watch?v=qBvcjf…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295261113903284224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295261113903284224",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:28:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/KeExasWDmh",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/VXg8HIuX1l",
        "expanded_url" : "https://en.wikipedia.org/wiki/Turn:_Washington%27s_Spies",
        "display_url" : "en.wikipedia.org/wiki/Turn:_Was…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295260173510950912",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295260173510950912",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:24:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/VXg8HIuX1l",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/TpCa6U1dS9",
        "expanded_url" : "https://www.cia.gov/index.html",
        "display_url" : "cia.gov/index.html",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295259883227381760",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295259883227381760",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:23:15 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/TpCa6U1dS9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/6jHfbuYVRU",
        "expanded_url" : "https://en.wikipedia.org/wiki/George_W._Bush",
        "display_url" : "en.wikipedia.org/wiki/George_W.…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295259742718185473",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295259742718185473",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:22:42 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/6jHfbuYVRU",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/bjigyTDQzL",
        "expanded_url" : "https://www.youtube.com/watch?v=O0zkD7uOyco",
        "display_url" : "youtube.com/watch?v=O0zkD7…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295259663974375424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295259663974375424",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:22:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/bjigyTDQzL",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/vxWTzE88KZ",
        "expanded_url" : "https://en.wikipedia.org/wiki/Yourcodenameis:milo",
        "display_url" : "en.wikipedia.org/wiki/Yourcoden…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295259446218616832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295259446218616832",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:21:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/vxWTzE88KZ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wwoKilUI5h",
        "expanded_url" : "https://www.youtube.com/watch?v=aC4BC-Hxq9g",
        "display_url" : "youtube.com/watch?v=aC4BC-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1295259032274350080",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295259032274350080",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 17 07:19:52 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wwoKilUI5h",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iviMgR4K9e",
        "expanded_url" : "https://www.youtube.com/watch?v=TcXPpVzwczs",
        "display_url" : "youtube.com/watch?v=TcXPpV…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049788198899713",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049788198899713",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:47:46 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/iviMgR4K9e",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "0",
    "id_str" : "1336049691461472258",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049691461472258",
    "created_at" : "Mon Dec 07 20:47:23 +0000 2020",
    "favorited" : false,
    "full_text" : "BIOLOGICAL WARFARE!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "0",
    "id_str" : "1336049550570582016",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049550570582016",
    "created_at" : "Mon Dec 07 20:46:50 +0000 2020",
    "favorited" : false,
    "full_text" : "A LEAKI LEAK",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0FaSocqLnt",
        "expanded_url" : "https://youtu.be/0miQIty-HeA?t=200",
        "display_url" : "youtu.be/0miQIty-HeA?t=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049520627499009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049520627499009",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:46:42 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0FaSocqLnt",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/fIvzpabkll",
        "expanded_url" : "https://youtu.be/-nufOttSLoI?t=192",
        "display_url" : "youtu.be/-nufOttSLoI?t=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049491716186113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049491716186113",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:46:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/fIvzpabkll",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/1gQqkfTQ0r",
        "expanded_url" : "https://www.youtube.com/watch?v=5yrtnJKAi6M",
        "display_url" : "youtube.com/watch?v=5yrtnJ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049461802356736",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049461802356736",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:46:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/1gQqkfTQ0r",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/EJ2AkRBZai",
        "expanded_url" : "https://www.youtube.com/watch?v=9lMn8GZIBPw&feature=emb_title",
        "display_url" : "youtube.com/watch?v=9lMn8G…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049431980863489",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049431980863489",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:46:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/EJ2AkRBZai",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/VT7xDLMAhX",
        "expanded_url" : "https://www.youtube.com/watch?v=orhrsjDwamY",
        "display_url" : "youtube.com/watch?v=orhrsj…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049381494063104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049381494063104",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:46:09 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/VT7xDLMAhX",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Mf32Jrl0N3",
        "expanded_url" : "http://viewsync.net/watch?v=HlpPXp49d8k&t=0&v=FG95QvnReNA&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=HlpPXp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336049331816656896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336049331816656896",
    "possibly_sensitive" : false,
    "created_at" : "Mon Dec 07 20:45:57 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Mf32Jrl0N3",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iZBZDebDI9",
        "expanded_url" : "https://www.youtube.com/watch?v=3sPQcSBMVFc",
        "display_url" : "youtube.com/watch?v=3sPQcS…",
        "indices" : [ "10", "33" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1334728049225388032",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1334728049225388032",
    "possibly_sensitive" : false,
    "created_at" : "Fri Dec 04 05:15:39 +0000 2020",
    "favorited" : false,
    "full_text" : "Thank you https://t.co/iZBZDebDI9 Cincinnati Cell for the tip off.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "id_str" : "1334727914298855425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1334727914298855425",
    "created_at" : "Fri Dec 04 05:15:07 +0000 2020",
    "favorited" : false,
    "full_text" : "Syringes. Pump house.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/fAyDABeCvl",
        "expanded_url" : "https://youtu.be/wW0WRqnLYMw?t=147",
        "display_url" : "youtu.be/wW0WRqnLYMw?t=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "129" ],
    "favorite_count" : "0",
    "id_str" : "1334727762427346944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1334727762427346944",
    "possibly_sensitive" : false,
    "created_at" : "Fri Dec 04 05:14:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/fAyDABeCvl Refs to Coronavirus and biological warfare in Batman Returns. Watch from 2:27 to 3:29. Sights and sounds.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/uH99W2NdzE",
        "expanded_url" : "http://www.youtubemultiplier.com/5f91231b556c5-themessenger6566516515619865185984.php",
        "display_url" : "youtubemultiplier.com/5f91231b556c5-…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1319160157981437952",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1319160157981437952",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 22 06:14:25 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/uH99W2NdzE Greater minds",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/F1bgUaf1b9",
        "expanded_url" : "https://www.youtube.com/watch?v=6FOUqQt3Kg0",
        "display_url" : "youtube.com/watch?v=6FOUqQ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309449847213355009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309449847213355009",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 11:09:06 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/F1bgUaf1b9",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/NhutLSVwIu",
        "expanded_url" : "https://www.youtube.com/watch?v=0GNFQ39PElw",
        "display_url" : "youtube.com/watch?v=0GNFQ3…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309449175701094400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309449175701094400",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 11:06:26 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/NhutLSVwIu",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/5SlQ1kH7wk",
        "expanded_url" : "https://www.youtube.com/watch?v=hG3xLxTo5zU",
        "display_url" : "youtube.com/watch?v=hG3xLx…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309448211929673729",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309448211929673729",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 11:02:36 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/5SlQ1kH7wk",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cDie9Zm0TQ",
        "expanded_url" : "https://www.youtube.com/watch?v=DTS9iJc4PLA",
        "display_url" : "youtube.com/watch?v=DTS9iJ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309446971233636353",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309446971233636353",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:57:40 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cDie9Zm0TQ",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/klnAw9lKg7",
        "expanded_url" : "https://www.youtube.com/watch?v=6vbDtlVq92I",
        "display_url" : "youtube.com/watch?v=6vbDtl…",
        "indices" : [ "45", "68" ]
      } ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "0",
    "id_str" : "1309445213711196160",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309445213711196160",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:50:41 +0000 2020",
    "favorited" : false,
    "full_text" : "A decade of Railroading. It do be like that. https://t.co/klnAw9lKg7 Welcome to my life!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/B0TEqGcplO",
        "expanded_url" : "https://viewsync.net/watch?v=bpOSxM0rNPM&t=0&v=dtgOzzBMl2o&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=bpOSxM…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309442238695571456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309442238695571456",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:38:52 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/B0TEqGcplO",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "0",
    "id_str" : "1309441135371313153",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309441135371313153",
    "created_at" : "Fri Sep 25 10:34:29 +0000 2020",
    "favorited" : false,
    "full_text" : "I don't want to hear anymore of your bullshit! STFU! Dated 2013.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/jnXeyNw6Un",
        "expanded_url" : "https://www.youtube.com/watch?v=bpOSxM0rNPM",
        "display_url" : "youtube.com/watch?v=bpOSxM…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1309440412982095872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309440412982095872",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 10:31:37 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/jnXeyNw6Un",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lCzEzKzJ1f",
        "expanded_url" : "https://mstdn.social/@blackvslight",
        "display_url" : "mstdn.social/@blackvslight",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1336501369369346053",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1336501369369346053",
    "possibly_sensitive" : false,
    "created_at" : "Wed Dec 09 02:42:12 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lCzEzKzJ1f",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698333343010821/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/Y7abCQuX0L",
        "media_url" : "http://pbs.twimg.com/media/ETfYZXGUwAAJ6or.jpg",
        "id_str" : "1240698152572731392",
        "id" : "1240698152572731392",
        "media_url_https" : "https://pbs.twimg.com/media/ETfYZXGUwAAJ6or.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Y7abCQuX0L"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1240698333343010821",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240698333343010821",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 19 17:55:08 +0000 2020",
    "favorited" : false,
    "full_text" : "Ominous billboards spotted in Regina. Depicting... https://t.co/Y7abCQuX0L",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698333343010821/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/Y7abCQuX0L",
        "media_url" : "http://pbs.twimg.com/media/ETfYZXGUwAAJ6or.jpg",
        "id_str" : "1240698152572731392",
        "id" : "1240698152572731392",
        "media_url_https" : "https://pbs.twimg.com/media/ETfYZXGUwAAJ6or.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Y7abCQuX0L"
      }, {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698333343010821/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/Y7abCQuX0L",
        "media_url" : "http://pbs.twimg.com/media/ETfYZXHU8AIbh25.jpg",
        "id_str" : "1240698152576937986",
        "id" : "1240698152576937986",
        "media_url_https" : "https://pbs.twimg.com/media/ETfYZXHU8AIbh25.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Y7abCQuX0L"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698044162519040/photo/1",
        "indices" : [ "263", "286" ],
        "url" : "https://t.co/1MGHNIwP02",
        "media_url" : "http://pbs.twimg.com/media/ETfXKk7U0AEpDqb.jpg",
        "id_str" : "1240696799075028993",
        "id" : "1240696799075028993",
        "media_url_https" : "https://pbs.twimg.com/media/ETfXKk7U0AEpDqb.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/1MGHNIwP02"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "286" ],
    "favorite_count" : "0",
    "id_str" : "1240698044162519040",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240698044162519040",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 19 17:53:59 +0000 2020",
    "favorited" : false,
    "full_text" : "Dystopian Checkin: Pandemic sweeping globe after hostile actors release weaponized virus. World leaders pussy footing around issues. Expecting mass casualties. Public being told to quarantine. Global markets crashing. Expecting global shortages in coming months. https://t.co/1MGHNIwP02",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698044162519040/photo/1",
        "indices" : [ "263", "286" ],
        "url" : "https://t.co/1MGHNIwP02",
        "media_url" : "http://pbs.twimg.com/media/ETfXKk7U0AEpDqb.jpg",
        "id_str" : "1240696799075028993",
        "id" : "1240696799075028993",
        "media_url_https" : "https://pbs.twimg.com/media/ETfXKk7U0AEpDqb.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/1MGHNIwP02"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240392025905733633/photo/1",
        "indices" : [ "112", "135" ],
        "url" : "https://t.co/NIy70ER9Kq",
        "media_url" : "http://pbs.twimg.com/media/ETbBzrYU0AAh1f6.jpg",
        "id_str" : "1240391840949391360",
        "id" : "1240391840949391360",
        "media_url_https" : "https://pbs.twimg.com/media/ETbBzrYU0AAh1f6.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "small" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NIy70ER9Kq"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "135" ],
    "favorite_count" : "0",
    "id_str" : "1240392025905733633",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240392025905733633",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 18 21:37:59 +0000 2020",
    "favorited" : false,
    "full_text" : "Everyone's freakin' out about that them there wu han tang virus and i be over here like \"Jesus take the wheel!\" https://t.co/NIy70ER9Kq",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240392025905733633/photo/1",
        "indices" : [ "112", "135" ],
        "url" : "https://t.co/NIy70ER9Kq",
        "media_url" : "http://pbs.twimg.com/media/ETbBzrYU0AAh1f6.jpg",
        "id_str" : "1240391840949391360",
        "id" : "1240391840949391360",
        "media_url_https" : "https://pbs.twimg.com/media/ETbBzrYU0AAh1f6.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          },
          "small" : {
            "w" : "640",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NIy70ER9Kq"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240266959016452096/photo/1",
        "indices" : [ "74", "97" ],
        "url" : "https://t.co/69lyvVN4Zv",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETZQOGyUMAU5rCN.jpg",
        "id_str" : "1240266950657191941",
        "id" : "1240266950657191941",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETZQOGyUMAU5rCN.jpg",
        "sizes" : {
          "large" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "140",
            "h" : "140",
            "resize" : "crop"
          },
          "small" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/69lyvVN4Zv"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "97" ],
    "favorite_count" : "0",
    "id_str" : "1240266959016452096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240266959016452096",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 18 13:21:00 +0000 2020",
    "favorited" : false,
    "full_text" : "Linguistics is a funny game. COVID-19 is now “Chinese Virus”. Bad Asians! https://t.co/69lyvVN4Zv",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240266959016452096/photo/1",
        "indices" : [ "74", "97" ],
        "url" : "https://t.co/69lyvVN4Zv",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETZQOGyUMAU5rCN.jpg",
        "id_str" : "1240266950657191941",
        "video_info" : {
          "aspect_ratio" : [ "25", "14" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETZQOGyUMAU5rCN.mp4"
          } ]
        },
        "id" : "1240266950657191941",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETZQOGyUMAU5rCN.jpg",
        "sizes" : {
          "large" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "140",
            "h" : "140",
            "resize" : "crop"
          },
          "small" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "250",
            "h" : "140",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/69lyvVN4Zv"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1240202956072300544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240202956072300544",
    "created_at" : "Wed Mar 18 09:06:41 +0000 2020",
    "favorited" : false,
    "full_text" : "Help me, Help you!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "269" ],
    "favorite_count" : "0",
    "id_str" : "1240202924787003394",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240202924787003394",
    "created_at" : "Wed Mar 18 09:06:33 +0000 2020",
    "favorited" : false,
    "full_text" : "Someone jokingly told me \"What do we pay you guys for?\" referring to people already working high paying gigs and the intelligence that I have brought forth. I need actions right now. Living in a Homeless Shelter dealing with totally asinine issues isn't helping anyone.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "228" ],
    "favorite_count" : "0",
    "id_str" : "1240202000349855747",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240202000349855747",
    "created_at" : "Wed Mar 18 09:02:53 +0000 2020",
    "favorited" : false,
    "full_text" : "Is my phone ringing? No. Locally. Nationally. I don't expect much from these people. There are certain people in the States I'd expect to turn up but I am seeing no results. There's some real shit going on right now and Nothing.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "235" ],
    "favorite_count" : "0",
    "id_str" : "1240201669322801152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240201669322801152",
    "created_at" : "Wed Mar 18 09:01:34 +0000 2020",
    "favorited" : false,
    "full_text" : "Being honest here. I am exhausted and at a loss. I have shown my peers mountains of intelligence the past few years regarding a myriad of topics. Then I start showing them all this current stuff and they go \"you have our attention now\"",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240037092291272710/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/c7TdXai2CO",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETV_KIwU4AASDlg.jpg",
        "id_str" : "1240037084536037376",
        "id" : "1240037084536037376",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETV_KIwU4AASDlg.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          },
          "large" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          },
          "small" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/c7TdXai2CO"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1240037092291272710",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240037092291272710",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 22:07:36 +0000 2020",
    "favorited" : false,
    "full_text" : "Ummmmm https://t.co/c7TdXai2CO",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240037092291272710/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/c7TdXai2CO",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETV_KIwU4AASDlg.jpg",
        "id_str" : "1240037084536037376",
        "video_info" : {
          "aspect_ratio" : [ "53", "40" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETV_KIwU4AASDlg.mp4"
          } ]
        },
        "id" : "1240037084536037376",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETV_KIwU4AASDlg.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          },
          "large" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          },
          "small" : {
            "w" : "212",
            "h" : "160",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/c7TdXai2CO"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/WfiS7DdZIE",
        "expanded_url" : "https://memes.getyarn.io/yarn-clip/6a6169dc-c2b3-4fb3-9d14-d4549e1df2d6/text",
        "display_url" : "memes.getyarn.io/yarn-clip/6a61…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240036917153910785",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240036917153910785",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 22:06:54 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/WfiS7DdZIE",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239968521099956227/photo/1",
        "indices" : [ "10", "33" ],
        "url" : "https://t.co/wfeZe6i2ac",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETVAybfUEAE_QwZ.jpg",
        "id_str" : "1239968507527172097",
        "id" : "1239968507527172097",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETVAybfUEAE_QwZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "large" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/wfeZe6i2ac"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "id_str" : "1239968521099956227",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239968521099956227",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 17:35:07 +0000 2020",
    "favorited" : false,
    "full_text" : "Bullshit. https://t.co/wfeZe6i2ac",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239968521099956227/photo/1",
        "indices" : [ "10", "33" ],
        "url" : "https://t.co/wfeZe6i2ac",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETVAybfUEAE_QwZ.jpg",
        "id_str" : "1239968507527172097",
        "video_info" : {
          "aspect_ratio" : [ "69", "58" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETVAybfUEAE_QwZ.mp4"
          } ]
        },
        "id" : "1239968507527172097",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETVAybfUEAE_QwZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          },
          "large" : {
            "w" : "414",
            "h" : "348",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/wfeZe6i2ac"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xOywvfoOaj",
        "expanded_url" : "https://music.apple.com/ca/album/welcome-to-our-new-war/1485044174?i=1485044187",
        "display_url" : "music.apple.com/ca/album/welco…",
        "indices" : [ "7", "30" ]
      } ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1239968252459016193",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239968252459016193",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 17:34:03 +0000 2020",
    "favorited" : false,
    "full_text" : "Mhhhhh https://t.co/xOywvfoOaj",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239736577552572418/photo/1",
        "indices" : [ "73", "96" ],
        "url" : "https://t.co/yorcUINgHs",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETRt1geVAAAexLu.jpg",
        "id_str" : "1239736563451363328",
        "id" : "1239736563451363328",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETRt1geVAAAexLu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/yorcUINgHs"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "96" ],
    "favorite_count" : "0",
    "id_str" : "1239736577552572418",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239736577552572418",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 02:13:27 +0000 2020",
    "favorited" : false,
    "full_text" : "“Who wrote that Thrice album?” Wouldn’t you like to know Mother Fuckers! https://t.co/yorcUINgHs",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239736577552572418/photo/1",
        "indices" : [ "73", "96" ],
        "url" : "https://t.co/yorcUINgHs",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETRt1geVAAAexLu.jpg",
        "id_str" : "1239736563451363328",
        "video_info" : {
          "aspect_ratio" : [ "83", "42" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETRt1geVAAAexLu.mp4"
          } ]
        },
        "id" : "1239736563451363328",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETRt1geVAAAexLu.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "252",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/yorcUINgHs"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "53", "61" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/kgnfoMR4Yx",
        "expanded_url" : "https://youtu.be/EIHtFDpLFqw",
        "display_url" : "youtu.be/EIHtFDpLFqw",
        "indices" : [ "25", "48" ]
      } ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "0",
    "id_str" : "1239735153674485761",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239735153674485761",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 02:07:48 +0000 2020",
    "favorited" : false,
    "full_text" : "Thrice - All That's Left https://t.co/kgnfoMR4Yx via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "104", "112" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/cln6XzZQqc",
        "expanded_url" : "https://youtu.be/8RKto0Yh4so",
        "display_url" : "youtu.be/8RKto0Yh4so",
        "indices" : [ "76", "99" ]
      } ]
    },
    "display_text_range" : [ "0", "112" ],
    "favorite_count" : "0",
    "id_str" : "1239734037058433029",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239734037058433029",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 02:03:22 +0000 2020",
    "favorited" : false,
    "full_text" : "SNOWDEN Official Trailer (2015) Joseph Gordon-Levitt, Shailene Woodley M... https://t.co/cln6XzZQqc via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239733821622214656/photo/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/52uo0h2NOV",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETRrVN2UMAEExxE.jpg",
        "id_str" : "1239733809672630273",
        "id" : "1239733809672630273",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETRrVN2UMAEExxE.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/52uo0h2NOV"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "0",
    "id_str" : "1239733821622214656",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239733821622214656",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 17 02:02:30 +0000 2020",
    "favorited" : false,
    "full_text" : "Things I don’t have time for. Weird aggressions. https://t.co/52uo0h2NOV",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239733821622214656/photo/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/52uo0h2NOV",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETRrVN2UMAEExxE.jpg",
        "id_str" : "1239733809672630273",
        "video_info" : {
          "aspect_ratio" : [ "20", "11" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETRrVN2UMAEExxE.mp4"
          } ]
        },
        "id" : "1239733809672630273",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETRrVN2UMAEExxE.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          },
          "large" : {
            "w" : "320",
            "h" : "176",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/52uo0h2NOV"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239622604475908096/photo/1",
        "indices" : [ "16", "39" ],
        "url" : "https://t.co/BGJVCrdxZa",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETQGLyuUUAgtbvL.jpg",
        "id_str" : "1239622597098098696",
        "id" : "1239622597098098696",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETQGLyuUUAgtbvL.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/BGJVCrdxZa"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1239622604475908096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239622604475908096",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 18:40:34 +0000 2020",
    "favorited" : false,
    "full_text" : "Mutual Respect. https://t.co/BGJVCrdxZa",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239622604475908096/photo/1",
        "indices" : [ "16", "39" ],
        "url" : "https://t.co/BGJVCrdxZa",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETQGLyuUUAgtbvL.jpg",
        "id_str" : "1239622597098098696",
        "video_info" : {
          "aspect_ratio" : [ "249", "140" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETQGLyuUUAgtbvL.mp4"
          } ]
        },
        "id" : "1239622597098098696",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETQGLyuUUAgtbvL.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/BGJVCrdxZa"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239621615383498754/photo/1",
        "indices" : [ "20", "43" ],
        "url" : "https://t.co/BvLqQ5aire",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETQFSNoUUAANR3L.jpg",
        "id_str" : "1239621607888277504",
        "id" : "1239621607888277504",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETQFSNoUUAANR3L.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/BvLqQ5aire"
      } ],
      "hashtags" : [ {
        "text" : "PENTAGON",
        "indices" : [ "0", "9" ]
      } ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1239621615383498754",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239621615383498754",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 18:36:38 +0000 2020",
    "favorited" : false,
    "full_text" : "#PENTAGON bruhhhhhh https://t.co/BvLqQ5aire",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239621615383498754/photo/1",
        "indices" : [ "20", "43" ],
        "url" : "https://t.co/BvLqQ5aire",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETQFSNoUUAANR3L.jpg",
        "id_str" : "1239621607888277504",
        "video_info" : {
          "aspect_ratio" : [ "25", "14" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETQFSNoUUAANR3L.mp4"
          } ]
        },
        "id" : "1239621607888277504",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETQFSNoUUAANR3L.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "168",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/BvLqQ5aire"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239581322739191808/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/T7KXfv1FFT",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETPgoRoU8AACv5J.jpg",
        "id_str" : "1239581304988954624",
        "id" : "1239581304988954624",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETPgoRoU8AACv5J.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          },
          "small" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/T7KXfv1FFT"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1239581322739191808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239581322739191808",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 16 15:56:32 +0000 2020",
    "favorited" : false,
    "full_text" : "Hehehe https://t.co/T7KXfv1FFT",
    "lang" : "tl",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1239581322739191808/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/T7KXfv1FFT",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETPgoRoU8AACv5J.jpg",
        "id_str" : "1239581304988954624",
        "video_info" : {
          "aspect_ratio" : [ "49", "45" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETPgoRoU8AACv5J.mp4"
          } ]
        },
        "id" : "1239581304988954624",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETPgoRoU8AACv5J.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          },
          "small" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "294",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/T7KXfv1FFT"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1240888235192025090",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240888235192025090",
    "created_at" : "Fri Mar 20 06:29:44 +0000 2020",
    "favorited" : false,
    "full_text" : "Depleted reserves.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "id_str" : "1240888157752586240",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240888157752586240",
    "created_at" : "Fri Mar 20 06:29:26 +0000 2020",
    "favorited" : false,
    "full_text" : "Government insolvency.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1240878006488317952",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240878006488317952",
    "created_at" : "Fri Mar 20 05:49:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Now with that intel. Watch Resident Evil: The Final Chapter. Sony Pictures",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "52", "60" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/7bKA2cgao4",
        "expanded_url" : "https://youtu.be/4h6bjyvlbpM",
        "display_url" : "youtu.be/4h6bjyvlbpM",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1240871978614927360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240871978614927360",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 05:25:08 +0000 2020",
    "favorited" : false,
    "full_text" : "Twista - Kill Us All HQ https://t.co/7bKA2cgao4 via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1240858908521984002",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240858908521984002",
    "created_at" : "Fri Mar 20 04:33:12 +0000 2020",
    "favorited" : false,
    "full_text" : "Project MAC? Maybe",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1240854854643249153",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240854854643249153",
    "created_at" : "Fri Mar 20 04:17:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Maybe. Maybe not. What the fuck do I know.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/BJ7dN4BiZa",
        "expanded_url" : "https://m.youtube.com/watch?v=HlppElW_DFY",
        "display_url" : "m.youtube.com/watch?v=HlppEl…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240854257936392192",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240854257936392192",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 04:14:43 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/BJ7dN4BiZa",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/zfaMzsgMuk",
        "expanded_url" : "https://en.wikipedia.org/wiki/Phase-shift_keying",
        "display_url" : "en.wikipedia.org/wiki/Phase-shi…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1240852429677060096",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240852429677060096",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 04:07:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/zfaMzsgMuk Phase 1",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/wqbjYmXR8X",
        "expanded_url" : "https://www.youtube.com/watch?v=spyTqeP8i7c",
        "display_url" : "youtube.com/watch?v=spyTqe…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1240851186846072832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240851186846072832",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 04:02:31 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/wqbjYmXR8X It was an awful movie but.....",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/gymtBgJEUo",
        "expanded_url" : "https://en.wikipedia.org/wiki/Gustave_Dor%C3%A9",
        "display_url" : "en.wikipedia.org/wiki/Gustave_D…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240848118310039553",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240848118310039553",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:50:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/gymtBgJEUo",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240847863371812864/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/q3hLTglD9D",
        "media_url" : "http://pbs.twimg.com/media/EThgixjUUAICmWh.jpg",
        "id_str" : "1240847847873859586",
        "id" : "1240847847873859586",
        "media_url_https" : "https://pbs.twimg.com/media/EThgixjUUAICmWh.jpg",
        "sizes" : {
          "small" : {
            "w" : "613",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "811",
            "h" : "900",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "811",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/q3hLTglD9D"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240847863371812864",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240847863371812864",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:49:19 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/q3hLTglD9D",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240847863371812864/photo/1",
        "indices" : [ "0", "23" ],
        "url" : "https://t.co/q3hLTglD9D",
        "media_url" : "http://pbs.twimg.com/media/EThgixjUUAICmWh.jpg",
        "id_str" : "1240847847873859586",
        "id" : "1240847847873859586",
        "media_url_https" : "https://pbs.twimg.com/media/EThgixjUUAICmWh.jpg",
        "sizes" : {
          "small" : {
            "w" : "613",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "811",
            "h" : "900",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "811",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/q3hLTglD9D"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cfhkjwi3Yv",
        "expanded_url" : "https://www.youtube.com/watch?v=5wXtm7YIRWM",
        "display_url" : "youtube.com/watch?v=5wXtm7…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240847295643410432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240847295643410432",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:47:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cfhkjwi3Yv",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Qslj50lPin",
        "expanded_url" : "https://www.youtube.com/watch?v=q0Lf1WAFGMw",
        "display_url" : "youtube.com/watch?v=q0Lf1W…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240846873411215361",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240846873411215361",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:45:23 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/Qslj50lPin",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lQMG9mHqeF",
        "expanded_url" : "https://www.youtube.com/watch?v=1paTrimD6O4",
        "display_url" : "youtube.com/watch?v=1paTri…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240845785459126273",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240845785459126273",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:41:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lQMG9mHqeF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/XIdWHvNgcR",
        "expanded_url" : "https://www.youtube.com/watch?v=XKVmpJaMffM",
        "display_url" : "youtube.com/watch?v=XKVmpJ…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1240845165251588097",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240845165251588097",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 03:38:35 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/XIdWHvNgcR",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "120" ],
    "favorite_count" : "0",
    "id_str" : "1240827926196543488",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240827926196543488",
    "created_at" : "Fri Mar 20 02:30:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Fuck it. Run deficits. Print money out of thin air.  Devalue and over inflate the currency. Oh what? We do that already.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "280" ],
    "favorite_count" : "0",
    "id_str" : "1240826025828691970",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240826025828691970",
    "created_at" : "Fri Mar 20 02:22:32 +0000 2020",
    "favorited" : false,
    "full_text" : "Do margins matter when shits hitting the fan? Hey yo. Mr Dinosour! You see that asteroid. It’s about to seriously fuck shit up and we’re all going to die. I’ll buy that Jeep off you for 10,000 grand. What your going to do with it with those tiny hands and 30 minutes is totally up",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "109" ],
    "favorite_count" : "0",
    "id_str" : "1240824904506736640",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240824904506736640",
    "created_at" : "Fri Mar 20 02:18:05 +0000 2020",
    "favorited" : false,
    "full_text" : "Tax industry? Correct over inflation? Turn capitalism into socialism in times of cataclysm? Fucked if I know.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240823917008130050/photo/1",
        "indices" : [ "188", "211" ],
        "url" : "https://t.co/I89ttpGUtJ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EThKxahUwAAviAZ.jpg",
        "id_str" : "1240823910133710848",
        "id" : "1240823910133710848",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EThKxahUwAAviAZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          },
          "large" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/I89ttpGUtJ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "211" ],
    "favorite_count" : "0",
    "id_str" : "1240823917008130050",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240823917008130050",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 02:14:09 +0000 2020",
    "favorited" : false,
    "full_text" : "Ok ok. Capital circle theory. Covid takes months to play out. Tax dollars support governments. No tax dollars to fund government. Income tax. Property tax. Nothing. Governmental collapse. https://t.co/I89ttpGUtJ",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240823917008130050/photo/1",
        "indices" : [ "188", "211" ],
        "url" : "https://t.co/I89ttpGUtJ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EThKxahUwAAviAZ.jpg",
        "id_str" : "1240823910133710848",
        "video_info" : {
          "aspect_ratio" : [ "122", "85" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EThKxahUwAAviAZ.mp4"
          } ]
        },
        "id" : "1240823910133710848",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EThKxahUwAAviAZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          },
          "large" : {
            "w" : "244",
            "h" : "170",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/I89ttpGUtJ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "216" ],
    "favorite_count" : "0",
    "id_str" : "1240799797893689344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240799797893689344",
    "created_at" : "Fri Mar 20 00:38:19 +0000 2020",
    "favorited" : false,
    "full_text" : "There are members of our society that lack the mental fortitude to grasp what the fuck is going on. Over the next two weeks, shits going to get real. Pull your heads out of your fucking asses and smarten the fuck up!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/28iSDZ322B",
        "expanded_url" : "https://m.youtube.com/watch?v=7KgKpSCLHdY",
        "display_url" : "m.youtube.com/watch?v=7KgKpS…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "174" ],
    "favorite_count" : "0",
    "id_str" : "1240737420397539328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240737420397539328",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 19 20:30:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/28iSDZ322B Financial Assistance = Commerce. Commerce = Human Interaction. Human Interaction = Not Social Distancing. We’re literally fucked no matter what we do.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/FtTcRkSdgZ",
        "expanded_url" : "https://en.wikipedia.org/wiki/Four_Horsemen_of_the_Apocalypse",
        "display_url" : "en.wikipedia.org/wiki/Four_Hors…",
        "indices" : [ "44", "67" ]
      } ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "0",
    "id_str" : "1240700873048592388",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240700873048592388",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 19 18:05:13 +0000 2020",
    "favorited" : false,
    "full_text" : "Four Horsemen of the Apocalypse - Wikipedia https://t.co/FtTcRkSdgZ",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698921678077952/photo/1",
        "indices" : [ "27", "50" ],
        "url" : "https://t.co/V6rAQgDC3H",
        "media_url" : "http://pbs.twimg.com/media/ETfZAHbUYAAMCT7.jpg",
        "id_str" : "1240698818380718080",
        "id" : "1240698818380718080",
        "media_url_https" : "https://pbs.twimg.com/media/ETfZAHbUYAAMCT7.jpg",
        "sizes" : {
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/V6rAQgDC3H"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1240698921678077952",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240698921678077952",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 19 17:57:28 +0000 2020",
    "favorited" : false,
    "full_text" : "Whatever the fuck this is: https://t.co/V6rAQgDC3H",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1240698921678077952/photo/1",
        "indices" : [ "27", "50" ],
        "url" : "https://t.co/V6rAQgDC3H",
        "media_url" : "http://pbs.twimg.com/media/ETfZAHbUYAAMCT7.jpg",
        "id_str" : "1240698818380718080",
        "id" : "1240698818380718080",
        "media_url_https" : "https://pbs.twimg.com/media/ETfZAHbUYAAMCT7.jpg",
        "sizes" : {
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/V6rAQgDC3H"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "id_str" : "1240698693340114944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240698693340114944",
    "created_at" : "Thu Mar 19 17:56:34 +0000 2020",
    "favorited" : false,
    "full_text" : "Canadian Charter of Rights and Freedoms Violation. Being told I am not allowed to leave dwelling. Must contact management before hand.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "55", "63" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/Zd24iVmpSA",
        "expanded_url" : "https://youtu.be/xNsCDspCOk4",
        "display_url" : "youtu.be/xNsCDspCOk4",
        "indices" : [ "27", "50" ]
      } ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1241443310004088834",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241443310004088834",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 19:15:24 +0000 2020",
    "favorited" : false,
    "full_text" : "WALL-E - Give Me the Plant https://t.co/Zd24iVmpSA via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/6KjGXoL8L7",
        "expanded_url" : "http://www.paypal.me/signalsout",
        "display_url" : "paypal.me/signalsout",
        "indices" : [ "46", "69" ]
      } ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1241439687778004992",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241439687778004992",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 19:01:01 +0000 2020",
    "favorited" : false,
    "full_text" : "Send monies. Interac: af@sasktel.net  PayPal: https://t.co/6KjGXoL8L7",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241437285129699328/photo/1",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/KhJXPFLPMS",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETp4n6fU8AAwe5I.jpg",
        "id_str" : "1241437274404876288",
        "id" : "1241437274404876288",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETp4n6fU8AAwe5I.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/KhJXPFLPMS"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1241437285129699328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241437285129699328",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 18:51:28 +0000 2020",
    "favorited" : false,
    "full_text" : "Feels. World burning. https://t.co/KhJXPFLPMS",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241437285129699328/photo/1",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/KhJXPFLPMS",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETp4n6fU8AAwe5I.jpg",
        "id_str" : "1241437274404876288",
        "video_info" : {
          "aspect_ratio" : [ "83", "56" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETp4n6fU8AAwe5I.mp4"
          } ]
        },
        "id" : "1241437274404876288",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETp4n6fU8AAwe5I.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "336",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/KhJXPFLPMS"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241430891399806976/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/jglUZeUjPj",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpyz3uUMAA6bDN.jpg",
        "id_str" : "1241430882751098880",
        "id" : "1241430882751098880",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpyz3uUMAA6bDN.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/jglUZeUjPj"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1241430891399806976",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241430891399806976",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 18:26:03 +0000 2020",
    "favorited" : false,
    "full_text" : "Oh wow. Such concern. Very fishy. https://t.co/jglUZeUjPj",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241430891399806976/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/jglUZeUjPj",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpyz3uUMAA6bDN.jpg",
        "id_str" : "1241430882751098880",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETpyz3uUMAA6bDN.mp4"
          } ]
        },
        "id" : "1241430882751098880",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpyz3uUMAA6bDN.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/jglUZeUjPj"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241428454869880832/photo/1",
        "indices" : [ "29", "52" ],
        "url" : "https://t.co/UfYwnoiJqh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpwl0zUcAEqds9.jpg",
        "id_str" : "1241428442425356289",
        "id" : "1241428442425356289",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpwl0zUcAEqds9.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/UfYwnoiJqh"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "0",
    "id_str" : "1241428454869880832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241428454869880832",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 18:16:22 +0000 2020",
    "favorited" : false,
    "full_text" : "These are our noble leaders. https://t.co/UfYwnoiJqh",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241428454869880832/photo/1",
        "indices" : [ "29", "52" ],
        "url" : "https://t.co/UfYwnoiJqh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpwl0zUcAEqds9.jpg",
        "id_str" : "1241428442425356289",
        "video_info" : {
          "aspect_ratio" : [ "4", "3" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETpwl0zUcAEqds9.mp4"
          } ]
        },
        "id" : "1241428442425356289",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpwl0zUcAEqds9.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          },
          "small" : {
            "w" : "480",
            "h" : "360",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/UfYwnoiJqh"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241426408754139138/photo/1",
        "indices" : [ "28", "51" ],
        "url" : "https://t.co/cWWxYFHYPn",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpuvBOU0AA04Zd.jpg",
        "id_str" : "1241426401355419648",
        "id" : "1241426401355419648",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpuvBOU0AA04Zd.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/cWWxYFHYPn"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "0",
    "id_str" : "1241426408754139138",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241426408754139138",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 18:08:15 +0000 2020",
    "favorited" : false,
    "full_text" : "Distopian Pandemic of 2020. https://t.co/cWWxYFHYPn",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241426408754139138/photo/1",
        "indices" : [ "28", "51" ],
        "url" : "https://t.co/cWWxYFHYPn",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETpuvBOU0AA04Zd.jpg",
        "id_str" : "1241426401355419648",
        "video_info" : {
          "aspect_ratio" : [ "249", "140" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETpuvBOU0AA04Zd.mp4"
          } ]
        },
        "id" : "1241426401355419648",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETpuvBOU0AA04Zd.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/cWWxYFHYPn"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241208133600473088/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/LxPnjnGykh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETmoNnAUEAA-AQ3.jpg",
        "id_str" : "1241208124079345664",
        "id" : "1241208124079345664",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETmoNnAUEAA-AQ3.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          },
          "large" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          },
          "small" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/LxPnjnGykh"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1241208133600473088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241208133600473088",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 03:40:54 +0000 2020",
    "favorited" : false,
    "full_text" : "Hehehe https://t.co/LxPnjnGykh",
    "lang" : "tl",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241208133600473088/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/LxPnjnGykh",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETmoNnAUEAA-AQ3.jpg",
        "id_str" : "1241208124079345664",
        "video_info" : {
          "aspect_ratio" : [ "230", "153" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETmoNnAUEAA-AQ3.mp4"
          } ]
        },
        "id" : "1241208124079345664",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETmoNnAUEAA-AQ3.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          },
          "large" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          },
          "small" : {
            "w" : "460",
            "h" : "306",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/LxPnjnGykh"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241207763989983232/photo/1",
        "indices" : [ "47", "70" ],
        "url" : "https://t.co/gRj6YPgaby",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETmn4ICUMAA2iyg.jpg",
        "id_str" : "1241207754988990464",
        "id" : "1241207754988990464",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETmn4ICUMAA2iyg.jpg",
        "sizes" : {
          "small" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/gRj6YPgaby"
      } ],
      "hashtags" : [ {
        "text" : "fml",
        "indices" : [ "42", "46" ]
      } ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "0",
    "id_str" : "1241207763989983232",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241207763989983232",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 21 03:39:26 +0000 2020",
    "favorited" : false,
    "full_text" : "We’ll be alright out here in the country. #fml https://t.co/gRj6YPgaby",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241207763989983232/photo/1",
        "indices" : [ "47", "70" ],
        "url" : "https://t.co/gRj6YPgaby",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETmn4ICUMAA2iyg.jpg",
        "id_str" : "1241207754988990464",
        "video_info" : {
          "aspect_ratio" : [ "13", "7" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETmn4ICUMAA2iyg.mp4"
          } ]
        },
        "id" : "1241207754988990464",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETmn4ICUMAA2iyg.jpg",
        "sizes" : {
          "small" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "390",
            "h" : "210",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/gRj6YPgaby"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buckley AFB",
        "screen_name" : "Buckley_AFB",
        "indices" : [ "0", "12" ],
        "id_str" : "1037767418",
        "id" : "1037767418"
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ "13", "20" ],
        "id_str" : "8775672",
        "id" : "8775672"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241084547397087233/photo/1",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/xE65zpsZnD",
        "media_url" : "http://pbs.twimg.com/media/ETk3ylwUMAEmCNF.jpg",
        "id_str" : "1241084514585030657",
        "id" : "1241084514585030657",
        "media_url_https" : "https://pbs.twimg.com/media/ETk3ylwUMAEmCNF.jpg",
        "sizes" : {
          "medium" : {
            "w" : "960",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "544",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/xE65zpsZnD"
      } ],
      "hashtags" : [ {
        "text" : "auroracolorado",
        "indices" : [ "21", "36" ]
      }, {
        "text" : "bouldercolorado",
        "indices" : [ "37", "53" ]
      }, {
        "text" : "denver",
        "indices" : [ "54", "61" ]
      } ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1241084547397087233",
    "in_reply_to_user_id" : "1037767418",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241084547397087233",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 19:29:48 +0000 2020",
    "favorited" : false,
    "full_text" : "@Buckley_AFB @usarmy #auroracolorado #bouldercolorado #denver https://t.co/xE65zpsZnD",
    "lang" : "und",
    "in_reply_to_screen_name" : "Buckley_AFB",
    "in_reply_to_user_id_str" : "1037767418",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241084547397087233/photo/1",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/xE65zpsZnD",
        "media_url" : "http://pbs.twimg.com/media/ETk3ylwUMAEmCNF.jpg",
        "id_str" : "1241084514585030657",
        "id" : "1241084514585030657",
        "media_url_https" : "https://pbs.twimg.com/media/ETk3ylwUMAEmCNF.jpg",
        "sizes" : {
          "medium" : {
            "w" : "960",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "544",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/xE65zpsZnD"
      }, {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241084547397087233/photo/1",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/xE65zpsZnD",
        "media_url" : "http://pbs.twimg.com/media/ETk3ym4UEAABn36.jpg",
        "id_str" : "1241084514887012352",
        "id" : "1241084514887012352",
        "media_url_https" : "https://pbs.twimg.com/media/ETk3ym4UEAABn36.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/xE65zpsZnD"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/cyYuSph6n0",
        "expanded_url" : "https://apps.dtic.mil/dtic/tr/fulltext/u2/681342.pdf",
        "display_url" : "apps.dtic.mil/dtic/tr/fullte…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "55" ],
    "favorite_count" : "0",
    "id_str" : "1241077160737046528",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241077160737046528",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 19:00:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/cyYuSph6n0 PDFs at the bottom of the page.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/K2wVrTk4a6",
        "expanded_url" : "https://multicians.org/project-mac.html",
        "display_url" : "multicians.org/project-mac.ht…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1241076034654441472",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241076034654441472",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 18:55:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/K2wVrTk4a6 43 PsyOPs.",
    "lang" : "tl"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/RTyQ68SjIR",
        "expanded_url" : "https://www.youtube.com/watch?v=mi7L2RV8_7Q",
        "display_url" : "youtube.com/watch?v=mi7L2R…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1241057528659632129",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241057528659632129",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 17:42:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/RTyQ68SjIR",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/GxfQV7ifid",
        "expanded_url" : "https://www.youtube.com/watch?v=5JqGB1Sntao",
        "display_url" : "youtube.com/watch?v=5JqGB1…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1241057002240872448",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241057002240872448",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 17:40:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/GxfQV7ifid",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/HDzEx7hVvE",
        "expanded_url" : "https://www.youtube.com/watch?v=o15TNTxyva8",
        "display_url" : "youtube.com/watch?v=o15TNT…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1241055191484391424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241055191484391424",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 17:33:09 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/HDzEx7hVvE",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/03TL4ke9MO",
        "expanded_url" : "https://www.youtube.com/watch?v=NzlG28B-R8Y",
        "display_url" : "youtube.com/watch?v=NzlG28…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241053431357263872/photo/1",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/eNltffR36I",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkbgvfUMAAloy_.jpg",
        "id_str" : "1241053421634859008",
        "id" : "1241053421634859008",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkbgvfUMAAloy_.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          },
          "large" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          },
          "small" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/eNltffR36I"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1241053431357263872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241053431357263872",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 17:26:10 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/03TL4ke9MO Most Dystopian shit I have ever seen! https://t.co/eNltffR36I",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241053431357263872/photo/1",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/eNltffR36I",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkbgvfUMAAloy_.jpg",
        "id_str" : "1241053421634859008",
        "video_info" : {
          "aspect_ratio" : [ "333", "151" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETkbgvfUMAAloy_.mp4"
          } ]
        },
        "id" : "1241053421634859008",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkbgvfUMAAloy_.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          },
          "large" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          },
          "small" : {
            "w" : "666",
            "h" : "302",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/eNltffR36I"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1241040961402109953",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241040961402109953",
    "created_at" : "Fri Mar 20 16:36:37 +0000 2020",
    "favorited" : false,
    "full_text" : "a pattern is a pattern, i didn't write this shit!",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/HBN7ridjkF",
        "expanded_url" : "https://www.youtube.com/watch?v=U4Ue3nXABuk",
        "display_url" : "youtube.com/watch?v=U4Ue3n…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241040741301796864/photo/1",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/vSL1Era6SP",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkP-KdUEAAL_fU.jpg",
        "id_str" : "1241040732950892544",
        "id" : "1241040732950892544",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkP-KdUEAAL_fU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          },
          "small" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/vSL1Era6SP"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1241040741301796864",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241040741301796864",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 16:35:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/HBN7ridjkF FEAR! https://t.co/vSL1Era6SP",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241040741301796864/photo/1",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/vSL1Era6SP",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkP-KdUEAAL_fU.jpg",
        "id_str" : "1241040732950892544",
        "video_info" : {
          "aspect_ratio" : [ "3", "2" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETkP-KdUEAAL_fU.mp4"
          } ]
        },
        "id" : "1241040732950892544",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkP-KdUEAAL_fU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          },
          "small" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "360",
            "h" : "240",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/vSL1Era6SP"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241028037623177216/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/SRKbW75A1Y",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkEakkUwAMgISf.jpg",
        "id_str" : "1241028026856423427",
        "id" : "1241028026856423427",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkEakkUwAMgISf.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          },
          "small" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/SRKbW75A1Y"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1241028037623177216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241028037623177216",
    "possibly_sensitive" : false,
    "created_at" : "Fri Mar 20 15:45:16 +0000 2020",
    "favorited" : false,
    "full_text" : "(Shrug) https://t.co/SRKbW75A1Y",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241028037623177216/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/SRKbW75A1Y",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETkEakkUwAMgISf.jpg",
        "id_str" : "1241028026856423427",
        "video_info" : {
          "aspect_ratio" : [ "219", "167" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETkEakkUwAMgISf.mp4"
          } ]
        },
        "id" : "1241028026856423427",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETkEakkUwAMgISf.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          },
          "small" : {
            "w" : "438",
            "h" : "334",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/SRKbW75A1Y"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "0",
    "id_str" : "1240893034557915138",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240893034557915138",
    "created_at" : "Fri Mar 20 06:48:48 +0000 2020",
    "favorited" : false,
    "full_text" : "Wow.",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "id_str" : "1240893004165967872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240893004165967872",
    "created_at" : "Fri Mar 20 06:48:41 +0000 2020",
    "favorited" : false,
    "full_text" : "Yeah. It’s all here.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1240889870660202496",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240889870660202496",
    "created_at" : "Fri Mar 20 06:36:14 +0000 2020",
    "favorited" : false,
    "full_text" : "People in the cities will head outward. Turn on each other.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1240889648831815685",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240889648831815685",
    "created_at" : "Fri Mar 20 06:35:21 +0000 2020",
    "favorited" : false,
    "full_text" : "Resource wars",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "id_str" : "1240888312417513472",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1240888312417513472",
    "created_at" : "Fri Mar 20 06:30:02 +0000 2020",
    "favorited" : false,
    "full_text" : "Continued biological attacks.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lWfJ7Mdb9E",
        "expanded_url" : "https://youtu.be/3S8PCeKl7bk",
        "display_url" : "youtu.be/3S8PCeKl7bk",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1244293051595579393/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/uqsG9BkC94",
        "media_url" : "http://pbs.twimg.com/media/EUSd6riXQAQXI__.jpg",
        "id_str" : "1244293028505927684",
        "id" : "1244293028505927684",
        "media_url_https" : "https://pbs.twimg.com/media/EUSd6riXQAQXI__.jpg",
        "sizes" : {
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/uqsG9BkC94"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1244293051595579393",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1244293051595579393",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 29 15:59:16 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lWfJ7Mdb9E https://t.co/uqsG9BkC94",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1244293051595579393/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/uqsG9BkC94",
        "media_url" : "http://pbs.twimg.com/media/EUSd6riXQAQXI__.jpg",
        "id_str" : "1244293028505927684",
        "id" : "1244293028505927684",
        "media_url_https" : "https://pbs.twimg.com/media/EUSd6riXQAQXI__.jpg",
        "sizes" : {
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/uqsG9BkC94"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "239" ],
    "favorite_count" : "0",
    "id_str" : "1242930077156818944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1242930077156818944",
    "created_at" : "Wed Mar 25 21:43:17 +0000 2020",
    "favorited" : false,
    "full_text" : "Me leaking coronavirus intel could be potentially helping adversarial components. It’s what I’m not saying. It’s alarming to say the least. The worlds on fire and there’s not much I can do about it from here. Good luck and god speed. Over.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "45", "53" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/WDndWx0lbL",
        "expanded_url" : "https://youtu.be/cZZ4ve922S4",
        "display_url" : "youtu.be/cZZ4ve922S4",
        "indices" : [ "17", "40" ]
      } ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1242542802304520193",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1242542802304520193",
    "possibly_sensitive" : false,
    "created_at" : "Tue Mar 24 20:04:24 +0000 2020",
    "favorited" : false,
    "full_text" : "All of the dots! https://t.co/WDndWx0lbL via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241943402163220481/photo/1",
        "indices" : [ "64", "87" ],
        "url" : "https://t.co/uzE5auZ6iR",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETxE79zU0AEU0Wn.jpg",
        "id_str" : "1241943394240221185",
        "id" : "1241943394240221185",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETxE79zU0AEU0Wn.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/uzE5auZ6iR"
      } ],
      "hashtags" : [ {
        "text" : "AF",
        "indices" : [ "60", "63" ]
      } ]
    },
    "display_text_range" : [ "0", "87" ],
    "favorite_count" : "0",
    "id_str" : "1241943402163220481",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241943402163220481",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 23 04:22:35 +0000 2020",
    "favorited" : false,
    "full_text" : "What I imagine yall are like right now! Work that shit out! #AF https://t.co/uzE5auZ6iR",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241943402163220481/photo/1",
        "indices" : [ "64", "87" ],
        "url" : "https://t.co/uzE5auZ6iR",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETxE79zU0AEU0Wn.jpg",
        "id_str" : "1241943394240221185",
        "video_info" : {
          "aspect_ratio" : [ "249", "140" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETxE79zU0AEU0Wn.mp4"
          } ]
        },
        "id" : "1241943394240221185",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETxE79zU0AEU0Wn.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          },
          "large" : {
            "w" : "498",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/uzE5auZ6iR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/nrwIYbG1R0",
        "expanded_url" : "https://en.wikipedia.org/wiki/Big_lie",
        "display_url" : "en.wikipedia.org/wiki/Big_lie",
        "indices" : [ "23", "46" ]
      } ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "0",
    "id_str" : "1241821880719265792",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241821880719265792",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 20:19:42 +0000 2020",
    "favorited" : false,
    "full_text" : "Big lie. Cough cough.  https://t.co/nrwIYbG1R0",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241816653962178565/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/Qmj0ZaJkX1",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETvRqGUUwAAGsoc.jpg",
        "id_str" : "1241816643451273216",
        "id" : "1241816643451273216",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETvRqGUUwAAGsoc.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          },
          "large" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Qmj0ZaJkX1"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1241816653962178565",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241816653962178565",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 19:58:56 +0000 2020",
    "favorited" : false,
    "full_text" : "It’s happening right now. https://t.co/Qmj0ZaJkX1",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241816653962178565/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/Qmj0ZaJkX1",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETvRqGUUwAAGsoc.jpg",
        "id_str" : "1241816643451273216",
        "video_info" : {
          "aspect_ratio" : [ "50", "31" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETvRqGUUwAAGsoc.mp4"
          } ]
        },
        "id" : "1241816643451273216",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETvRqGUUwAAGsoc.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          },
          "large" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "400",
            "h" : "248",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/Qmj0ZaJkX1"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tcfhCrqZoG",
        "expanded_url" : "https://www.cdc.gov/coronavirus/2019-ncov/cases-updates/cases-in-us.html",
        "display_url" : "cdc.gov/coronavirus/20…",
        "indices" : [ "93", "116" ]
      } ]
    },
    "display_text_range" : [ "0", "116" ],
    "favorite_count" : "0",
    "id_str" : "1241814533615697920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241814533615697920",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 19:50:31 +0000 2020",
    "favorited" : false,
    "full_text" : "Cases in U.S. | CDC NYC reporting 9000 cases. America reporting close to 16000 cases? Ummmmm https://t.co/tcfhCrqZoG",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "58" ],
    "favorite_count" : "0",
    "id_str" : "1241805258466029568",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241805258466029568",
    "created_at" : "Sun Mar 22 19:13:39 +0000 2020",
    "favorited" : false,
    "full_text" : "80% of Americans live in Urban settings. Think about that.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/SB3TgKNRkY",
        "expanded_url" : "https://www.youtube.com/watch?v=1X4AirT_LiE",
        "display_url" : "youtube.com/watch?v=1X4Air…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1241794249139474432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241794249139474432",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 18:29:55 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/SB3TgKNRkY",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CO4Hbk8CPm",
        "expanded_url" : "https://music.apple.com/ca/album/intro/1184701557?i=1184702093",
        "display_url" : "music.apple.com/ca/album/intro…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1241792773176455168",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241792773176455168",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 18:24:03 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/CO4Hbk8CPm",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241790798783381504/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/SM4p6mygeY",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETu6JKtUYAAjPOC.jpg",
        "id_str" : "1241790788926726144",
        "id" : "1241790788926726144",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETu6JKtUYAAjPOC.jpg",
        "sizes" : {
          "small" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/SM4p6mygeY"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1241790798783381504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241790798783381504",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 18:16:12 +0000 2020",
    "favorited" : false,
    "full_text" : "Just over here chillin. Doin my thang. https://t.co/SM4p6mygeY",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241790798783381504/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/SM4p6mygeY",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETu6JKtUYAAjPOC.jpg",
        "id_str" : "1241790788926726144",
        "video_info" : {
          "aspect_ratio" : [ "145", "81" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETu6JKtUYAAjPOC.mp4"
          } ]
        },
        "id" : "1241790788926726144",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETu6JKtUYAAjPOC.jpg",
        "sizes" : {
          "small" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "290",
            "h" : "162",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/SM4p6mygeY"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "104", "112" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/WE2EdzfPpf",
        "expanded_url" : "https://youtu.be/FAn4gyUAI6Q",
        "display_url" : "youtu.be/FAn4gyUAI6Q",
        "indices" : [ "76", "99" ]
      } ]
    },
    "display_text_range" : [ "0", "112" ],
    "favorite_count" : "0",
    "id_str" : "1241789002929172481",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241789002929172481",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 18:09:04 +0000 2020",
    "favorited" : false,
    "full_text" : "THE GHOST INSIDE - UNSPOKEN - HARDCORE WORLDWIDE (OFFICIAL HD VERSION HCWW) https://t.co/WE2EdzfPpf via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "38", "46" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/VAHpw6nJ7R",
        "expanded_url" : "https://youtu.be/O0zkD7uOyco",
        "display_url" : "youtu.be/O0zkD7uOyco",
        "indices" : [ "10", "33" ]
      } ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "0",
    "id_str" : "1241786918028726273",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241786918028726273",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 18:00:47 +0000 2020",
    "favorited" : false,
    "full_text" : "Antitrust https://t.co/VAHpw6nJ7R via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241786372219793408/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/9omUo89QVc",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETu2HpSU8AEfM_-.jpg",
        "id_str" : "1241786364728766465",
        "id" : "1241786364728766465",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETu2HpSU8AEfM_-.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/9omUo89QVc"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1241786372219793408",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241786372219793408",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 17:58:37 +0000 2020",
    "favorited" : false,
    "full_text" : "Ummmmm. https://t.co/9omUo89QVc",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241786372219793408/photo/1",
        "indices" : [ "8", "31" ],
        "url" : "https://t.co/9omUo89QVc",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETu2HpSU8AEfM_-.jpg",
        "id_str" : "1241786364728766465",
        "video_info" : {
          "aspect_ratio" : [ "249", "139" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETu2HpSU8AEfM_-.mp4"
          } ]
        },
        "id" : "1241786364728766465",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETu2HpSU8AEfM_-.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/9omUo89QVc"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "58", "66" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/6JvHIpMih8",
        "expanded_url" : "https://youtu.be/WSNXKZn_xY0",
        "display_url" : "youtu.be/WSNXKZn_xY0",
        "indices" : [ "30", "53" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1241786230301265920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241786230301265920",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 17:58:03 +0000 2020",
    "favorited" : false,
    "full_text" : "The Maine - We All Roll Along https://t.co/6JvHIpMih8 via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241783300814802944/photo/1",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/id8O5AaasE",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETuzUxnUYAERDTF.jpg",
        "id_str" : "1241783291767709697",
        "id" : "1241783291767709697",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETuzUxnUYAERDTF.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/id8O5AaasE"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1241783300814802944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241783300814802944",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 17:46:24 +0000 2020",
    "favorited" : false,
    "full_text" : "I sure I could be a little more professional. https://t.co/id8O5AaasE",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241783300814802944/photo/1",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/id8O5AaasE",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETuzUxnUYAERDTF.jpg",
        "id_str" : "1241783291767709697",
        "video_info" : {
          "aspect_ratio" : [ "249", "139" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETuzUxnUYAERDTF.mp4"
          } ]
        },
        "id" : "1241783291767709697",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETuzUxnUYAERDTF.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "small" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "498",
            "h" : "278",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/id8O5AaasE"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "151" ],
    "favorite_count" : "0",
    "id_str" : "1241643605220929538",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241643605220929538",
    "created_at" : "Sun Mar 22 08:31:18 +0000 2020",
    "favorited" : false,
    "full_text" : "They’re using you cock suckers to talk in code about the shit they’re about to pull. You’re just to stupid to realize it. It’s like 911 all over again.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241576735855919104/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/maeqPUtsB6",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETr3cs9UEAEEp-_.jpg",
        "id_str" : "1241576719770718209",
        "id" : "1241576719770718209",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETr3cs9UEAEEp-_.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/maeqPUtsB6"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1241576735855919104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1241576735855919104",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 22 04:05:35 +0000 2020",
    "favorited" : false,
    "full_text" : "(shifty eyes) https://t.co/maeqPUtsB6",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1241576735855919104/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/maeqPUtsB6",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/ETr3cs9UEAEEp-_.jpg",
        "id_str" : "1241576719770718209",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/ETr3cs9UEAEEp-_.mp4"
          } ]
        },
        "id" : "1241576719770718209",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/ETr3cs9UEAEEp-_.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/maeqPUtsB6"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "117" ],
    "favorite_count" : "0",
    "id_str" : "1247438710926237696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247438710926237696",
    "created_at" : "Tue Apr 07 08:18:59 +0000 2020",
    "favorited" : false,
    "full_text" : "It's the upper class. Both sides are in on it. There's not much I can do about it from here. This is what's going on.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/GMV5nmDbQa",
        "expanded_url" : "https://youtu.be/wRMXTvsCBwQ",
        "display_url" : "youtu.be/wRMXTvsCBwQ",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/fI81c2QYeH",
        "expanded_url" : "https://en.wikipedia.org/wiki/Refused",
        "display_url" : "en.wikipedia.org/wiki/Refused",
        "indices" : [ "24", "47" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1247438563966251008/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/6t6Ba2BhzC",
        "media_url" : "http://pbs.twimg.com/media/EU_KrADUUAEFPSN.jpg",
        "id_str" : "1247438461902016513",
        "id" : "1247438461902016513",
        "media_url_https" : "https://pbs.twimg.com/media/EU_KrADUUAEFPSN.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "477",
            "h" : "715",
            "resize" : "fit"
          },
          "small" : {
            "w" : "454",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "477",
            "h" : "715",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/6t6Ba2BhzC"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1247438563966251008",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247438563966251008",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 07 08:18:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/GMV5nmDbQa https://t.co/fI81c2QYeH https://t.co/6t6Ba2BhzC",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1247438563966251008/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/6t6Ba2BhzC",
        "media_url" : "http://pbs.twimg.com/media/EU_KrADUUAEFPSN.jpg",
        "id_str" : "1247438461902016513",
        "id" : "1247438461902016513",
        "media_url_https" : "https://pbs.twimg.com/media/EU_KrADUUAEFPSN.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "477",
            "h" : "715",
            "resize" : "fit"
          },
          "small" : {
            "w" : "454",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "477",
            "h" : "715",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/6t6Ba2BhzC"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/d0gPrxgZ9Q",
        "expanded_url" : "https://en.wikipedia.org/wiki/Paul_W._S._Anderson",
        "display_url" : "en.wikipedia.org/wiki/Paul_W._S…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1247437510474489857",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247437510474489857",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 07 08:14:13 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/d0gPrxgZ9Q The British ladies and gentleman.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/VsCSL6Fk95",
        "expanded_url" : "https://www.youtube.com/watch?v=DgwprntqqmE",
        "display_url" : "youtube.com/watch?v=Dgwprn…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1247437137261113345/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/eq0SFViTgF",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EU_JdREU8AELJDD.jpg",
        "id_str" : "1247437126439858177",
        "id" : "1247437126439858177",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EU_JdREU8AELJDD.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/eq0SFViTgF"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1247437137261113345",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247437137261113345",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 07 08:12:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/VsCSL6Fk95 https://t.co/eq0SFViTgF",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1247437137261113345/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/eq0SFViTgF",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EU_JdREU8AELJDD.jpg",
        "id_str" : "1247437126439858177",
        "video_info" : {
          "aspect_ratio" : [ "25", "14" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EU_JdREU8AELJDD.mp4"
          } ]
        },
        "id" : "1247437126439858177",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EU_JdREU8AELJDD.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "280",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/eq0SFViTgF"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/lpQSTRqEuS",
        "expanded_url" : "https://www.youtube.com/watch?v=PtyySlBW6kk",
        "display_url" : "youtube.com/watch?v=PtyySl…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "110" ],
    "favorite_count" : "0",
    "id_str" : "1247436888111108097",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247436888111108097",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 07 08:11:45 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/lpQSTRqEuS ego. eco. horror film. terror. eco terrorism. \"Were going to pin it on eco terrorists\"",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/dbnUIbScxF",
        "expanded_url" : "https://imgur.com/gallery/nacCMdT",
        "display_url" : "imgur.com/gallery/nacCMdT",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1247396297365053440",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247396297365053440",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 07 05:30:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/dbnUIbScxF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/bvzYK99llr",
        "expanded_url" : "https://m.imdb.com/title/tt0028358/",
        "display_url" : "m.imdb.com/title/tt002835…",
        "indices" : [ "97", "120" ]
      } ]
    },
    "display_text_range" : [ "0", "120" ],
    "favorite_count" : "0",
    "id_str" : "1247022807856418816",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1247022807856418816",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 06 04:46:20 +0000 2020",
    "favorited" : false,
    "full_text" : "Anyone else notice how coronavirus is playing out like the premise to HG Wells - Things to Come? https://t.co/bvzYK99llr",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1246312389903110144/photo/1",
        "indices" : [ "29", "52" ],
        "url" : "https://t.co/VOD8aDsULK",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EUvKgb2XgAEu4cG.jpg",
        "id_str" : "1246312380478488577",
        "id" : "1246312380478488577",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EUvKgb2XgAEu4cG.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "148",
            "h" : "148",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VOD8aDsULK"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "0",
    "id_str" : "1246312389903110144",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1246312389903110144",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 04 05:43:23 +0000 2020",
    "favorited" : false,
    "full_text" : "2020 can fuck off. I’m done. https://t.co/VOD8aDsULK",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1246312389903110144/photo/1",
        "indices" : [ "29", "52" ],
        "url" : "https://t.co/VOD8aDsULK",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EUvKgb2XgAEu4cG.jpg",
        "id_str" : "1246312380478488577",
        "video_info" : {
          "aspect_ratio" : [ "75", "37" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EUvKgb2XgAEu4cG.mp4"
          } ]
        },
        "id" : "1246312380478488577",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EUvKgb2XgAEu4cG.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "148",
            "h" : "148",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          },
          "small" : {
            "w" : "300",
            "h" : "148",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/VOD8aDsULK"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/m4gk0FtGms",
        "expanded_url" : "https://m.youtube.com/watch?feature=share&v=ashgP4YMdJw",
        "display_url" : "m.youtube.com/watch?feature=…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1244320936595087360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1244320936595087360",
    "possibly_sensitive" : false,
    "created_at" : "Sun Mar 29 17:50:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/m4gk0FtGms",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "219" ],
    "favorite_count" : "0",
    "id_str" : "1249478083809136642",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249478083809136642",
    "created_at" : "Sun Apr 12 23:22:44 +0000 2020",
    "favorited" : false,
    "full_text" : "They don't take me seriously. They're still doing PsyOPs shit on me. I've reached out to all kinds of people to show them Intel I'm finding. Still nothing. I'm out. They know exactly what's going on and aren't tell you.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/SyL4pQ0AGN",
        "expanded_url" : "https://viewsync.net/watch?v=c7ynwAgQlDQ&t=0&v=guI9jK9OlPg&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=c7ynwA…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249477534644727808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249477534644727808",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 12 23:20:33 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/SyL4pQ0AGN",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249232952833105920/photo/1",
        "indices" : [ "161", "184" ],
        "url" : "https://t.co/XwFxmfqShG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVYqveaUcAAc7-Y.jpg",
        "id_str" : "1249232941747564544",
        "id" : "1249232941747564544",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVYqveaUcAAc7-Y.jpg",
        "sizes" : {
          "small" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/XwFxmfqShG"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "184" ],
    "favorite_count" : "0",
    "id_str" : "1249232952833105920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249232952833105920",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 12 07:08:40 +0000 2020",
    "favorited" : false,
    "full_text" : "Don’t worry earth humans. Our noble politicians and military leaders have it all figured out. Everything will be okay. Okay. That’s a day in my life. Goodnight. https://t.co/XwFxmfqShG",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249232952833105920/photo/1",
        "indices" : [ "161", "184" ],
        "url" : "https://t.co/XwFxmfqShG",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVYqveaUcAAc7-Y.jpg",
        "id_str" : "1249232941747564544",
        "video_info" : {
          "aspect_ratio" : [ "1", "1" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVYqveaUcAAc7-Y.mp4"
          } ]
        },
        "id" : "1249232941747564544",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVYqveaUcAAc7-Y.jpg",
        "sizes" : {
          "small" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "300",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/XwFxmfqShG"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/msmJvdpwuO",
        "expanded_url" : "https://viewsync.net/watch?v=VNtsVP42bOE&t=0&v=VSIU_oDhju0&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=VNtsVP…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1249222291113660418",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249222291113660418",
    "possibly_sensitive" : false,
    "created_at" : "Sun Apr 12 06:26:18 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/msmJvdpwuO huh. no connection.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "101" ],
    "favorite_count" : "0",
    "id_str" : "1249059276104089601",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249059276104089601",
    "created_at" : "Sat Apr 11 19:38:32 +0000 2020",
    "favorited" : false,
    "full_text" : "I come in contact with stupid motherfuckers all day long. In fact I’m surrounded by them. Believe me.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249055500387463168/photo/1",
        "indices" : [ "66", "89" ],
        "url" : "https://t.co/vlG1jKleYD",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVWJWksVAAEXJIG.jpg",
        "id_str" : "1249055492564910081",
        "id" : "1249055492564910081",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVWJWksVAAEXJIG.jpg",
        "sizes" : {
          "medium" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          },
          "small" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/vlG1jKleYD"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "89" ],
    "favorite_count" : "0",
    "id_str" : "1249055500387463168",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249055500387463168",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 19:23:32 +0000 2020",
    "favorited" : false,
    "full_text" : "Everyone’s little voice right now. “Hello, yes this is the beast” https://t.co/vlG1jKleYD",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249055500387463168/photo/1",
        "indices" : [ "66", "89" ],
        "url" : "https://t.co/vlG1jKleYD",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVWJWksVAAEXJIG.jpg",
        "id_str" : "1249055492564910081",
        "video_info" : {
          "aspect_ratio" : [ "4", "3" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVWJWksVAAEXJIG.mp4"
          } ]
        },
        "id" : "1249055492564910081",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVWJWksVAAEXJIG.jpg",
        "sizes" : {
          "medium" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          },
          "small" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "360",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/vlG1jKleYD"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/uo7lFiNC71",
        "expanded_url" : "https://www.google.com/search?q=new+york+mass+graves&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjD7ZLu9d_oAhXKmuAKHblCD3kQ_AUoAXoECAsQAw&biw=1366&bih=683",
        "display_url" : "google.com/search?q=new+y…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1248886101315485696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248886101315485696",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 08:10:24 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/uo7lFiNC71 New York at the moment.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248880742622302210/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/EnrEHTavnd",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVTqaWfUcAAohGK.jpg",
        "id_str" : "1248880735122911232",
        "id" : "1248880735122911232",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVTqaWfUcAAohGK.jpg",
        "sizes" : {
          "medium" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "122",
            "h" : "122",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/EnrEHTavnd"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1248880742622302210",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248880742622302210",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 07:49:06 +0000 2020",
    "favorited" : false,
    "full_text" : "If you see something... https://t.co/EnrEHTavnd",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248880742622302210/photo/1",
        "indices" : [ "24", "47" ],
        "url" : "https://t.co/EnrEHTavnd",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVTqaWfUcAAohGK.jpg",
        "id_str" : "1248880735122911232",
        "video_info" : {
          "aspect_ratio" : [ "110", "61" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVTqaWfUcAAohGK.mp4"
          } ]
        },
        "id" : "1248880735122911232",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVTqaWfUcAAohGK.jpg",
        "sizes" : {
          "medium" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "small" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "large" : {
            "w" : "220",
            "h" : "122",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "122",
            "h" : "122",
            "resize" : "crop"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/EnrEHTavnd"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CiWeWagffP",
        "expanded_url" : "https://www.hfunderground.com/wiki/index.php/File:NWO.jpg",
        "display_url" : "hfunderground.com/wiki/index.php…",
        "indices" : [ "154", "177" ]
      }, {
        "url" : "https://t.co/PTvDf97ESb",
        "expanded_url" : "https://www.hfunderground.com/wiki/index.php/Voice_of_the_New_World_Order",
        "display_url" : "hfunderground.com/wiki/index.php…",
        "indices" : [ "178", "201" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248875865670221824/photo/1",
        "indices" : [ "202", "225" ],
        "url" : "https://t.co/TWRGcHJYN8",
        "media_url" : "http://pbs.twimg.com/media/EVTlyK8UEAAAF14.jpg",
        "id_str" : "1248875646782017536",
        "id" : "1248875646782017536",
        "media_url_https" : "https://pbs.twimg.com/media/EVTlyK8UEAAAF14.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "726",
            "h" : "1000",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "726",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "494",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/TWRGcHJYN8"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "225" ],
    "favorite_count" : "0",
    "id_str" : "1248875865670221824",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1248875865670221824",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 07:29:44 +0000 2020",
    "favorited" : false,
    "full_text" : "I'm aware misinformation is used to discredit sources. I'm not going to lie. This is Alex Jones type shit but I thought I would share. sidebandphone tag. https://t.co/CiWeWagffP https://t.co/PTvDf97ESb https://t.co/TWRGcHJYN8",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248875865670221824/photo/1",
        "indices" : [ "202", "225" ],
        "url" : "https://t.co/TWRGcHJYN8",
        "media_url" : "http://pbs.twimg.com/media/EVTlyK8UEAAAF14.jpg",
        "id_str" : "1248875646782017536",
        "id" : "1248875646782017536",
        "media_url_https" : "https://pbs.twimg.com/media/EVTlyK8UEAAAF14.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "726",
            "h" : "1000",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "726",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "494",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/TWRGcHJYN8"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248859894993670144/photo/1",
        "indices" : [ "41", "64" ],
        "url" : "https://t.co/9kUmBFMlGB",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVTXc0iU8AIZom-.jpg",
        "id_str" : "1248859886827401218",
        "id" : "1248859886827401218",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVTXc0iU8AIZom-.jpg",
        "sizes" : {
          "medium" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          },
          "large" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/9kUmBFMlGB"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "0",
    "id_str" : "1248859894993670144",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248859894993670144",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 06:26:16 +0000 2020",
    "favorited" : false,
    "full_text" : "The Giving Pledge. We don’t give a shit. https://t.co/9kUmBFMlGB",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248859894993670144/photo/1",
        "indices" : [ "41", "64" ],
        "url" : "https://t.co/9kUmBFMlGB",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVTXc0iU8AIZom-.jpg",
        "id_str" : "1248859886827401218",
        "video_info" : {
          "aspect_ratio" : [ "8", "5" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVTXc0iU8AIZom-.mp4"
          } ]
        },
        "id" : "1248859886827401218",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVTXc0iU8AIZom-.jpg",
        "sizes" : {
          "medium" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          },
          "large" : {
            "w" : "400",
            "h" : "250",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/9kUmBFMlGB"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "EARTH",
        "indices" : [ "57", "63" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/XtUkkhqN05",
        "expanded_url" : "https://viewsync.net/watch?v=fVMgnmi2D1w&t=0&v=rPLLXQDNoFI&t=0&mode=solo",
        "display_url" : "viewsync.net/watch?v=fVMgnm…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1248831057127854081",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248831057127854081",
    "possibly_sensitive" : false,
    "created_at" : "Sat Apr 11 04:31:40 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/XtUkkhqN05 Broadcasting on all frequencies. #EARTH",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/N9oqI1X5EW",
        "expanded_url" : "https://www.youtube.com/watch?v=B5cbkovLqMQ",
        "display_url" : "youtube.com/watch?v=B5cbko…",
        "indices" : [ "0", "23" ]
      }, {
        "url" : "https://t.co/SvSFr9e9rU",
        "expanded_url" : "https://www.ibm.com/ibm/history/exhibits/brazil/brazil_ch1.html",
        "display_url" : "ibm.com/ibm/history/ex…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1248504520306331651",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248504520306331651",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 10 06:54:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/N9oqI1X5EW https://t.co/SvSFr9e9rU",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248490399557025797/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/qzAqznQuFS",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVOHZKBUcAAGejP.jpg",
        "id_str" : "1248490387968126976",
        "id" : "1248490387968126976",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVOHZKBUcAAGejP.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          },
          "large" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/qzAqznQuFS"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1248490399557025797",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248490399557025797",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 10 05:58:01 +0000 2020",
    "favorited" : false,
    "full_text" : "Things https://t.co/qzAqznQuFS",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248490399557025797/photo/1",
        "indices" : [ "7", "30" ],
        "url" : "https://t.co/qzAqznQuFS",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVOHZKBUcAAGejP.jpg",
        "id_str" : "1248490387968126976",
        "video_info" : {
          "aspect_ratio" : [ "36", "23" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVOHZKBUcAAGejP.mp4"
          } ]
        },
        "id" : "1248490387968126976",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVOHZKBUcAAGejP.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          },
          "large" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "360",
            "h" : "230",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/qzAqznQuFS"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/oWY0MK31BK",
        "expanded_url" : "https://time.com/3003840/malaysia-airlines-ukraine-crash-top-aids-researchers-killed-aids2014-mh17/",
        "display_url" : "time.com/3003840/malays…",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248490177254715392/photo/1",
        "indices" : [ "66", "89" ],
        "url" : "https://t.co/F2GpTmFRmZ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVOHMdmU8AEr1ed.jpg",
        "id_str" : "1248490169885323265",
        "id" : "1248490169885323265",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVOHMdmU8AEr1ed.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/F2GpTmFRmZ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "89" ],
    "favorite_count" : "0",
    "id_str" : "1248490177254715392",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248490177254715392",
    "possibly_sensitive" : false,
    "created_at" : "Fri Apr 10 05:57:08 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/oWY0MK31BK  Plane, Airborne, Aids.... Airborne Aids? https://t.co/F2GpTmFRmZ",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248490177254715392/photo/1",
        "indices" : [ "66", "89" ],
        "url" : "https://t.co/F2GpTmFRmZ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EVOHMdmU8AEr1ed.jpg",
        "id_str" : "1248490169885323265",
        "video_info" : {
          "aspect_ratio" : [ "147", "100" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EVOHMdmU8AEr1ed.mp4"
          } ]
        },
        "id" : "1248490169885323265",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EVOHMdmU8AEr1ed.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "294",
            "h" : "200",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/F2GpTmFRmZ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xR2DUx5wEm",
        "expanded_url" : "https://youtu.be/bvophZ7XMIk",
        "display_url" : "youtu.be/bvophZ7XMIk",
        "indices" : [ "0", "23" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248311664937701377/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/VjoP6TVLVe",
        "media_url" : "http://pbs.twimg.com/media/EVLk1f6U4AAU6ci.jpg",
        "id_str" : "1248311654485385216",
        "id" : "1248311654485385216",
        "media_url_https" : "https://pbs.twimg.com/media/EVLk1f6U4AAU6ci.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          },
          "small" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VjoP6TVLVe"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1248311664937701377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1248311664937701377",
    "possibly_sensitive" : false,
    "created_at" : "Thu Apr 09 18:07:48 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/xR2DUx5wEm We’re all going to die. https://t.co/VjoP6TVLVe",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1248311664937701377/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/VjoP6TVLVe",
        "media_url" : "http://pbs.twimg.com/media/EVLk1f6U4AAU6ci.jpg",
        "id_str" : "1248311654485385216",
        "id" : "1248311654485385216",
        "media_url_https" : "https://pbs.twimg.com/media/EVLk1f6U4AAU6ci.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          },
          "small" : {
            "w" : "640",
            "h" : "640",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VjoP6TVLVe"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1250168045160390656/photo/1",
        "indices" : [ "27", "50" ],
        "url" : "https://t.co/rudn9kGXTi",
        "media_url" : "http://pbs.twimg.com/media/EVl9Kp9U0AEo4fP.jpg",
        "id_str" : "1250167993587257345",
        "id" : "1250167993587257345",
        "media_url_https" : "https://pbs.twimg.com/media/EVl9Kp9U0AEo4fP.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rudn9kGXTi"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1250168045160390656",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250168045160390656",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 21:04:23 +0000 2020",
    "favorited" : false,
    "full_text" : "Large Fries. Mkay. Thanks. https://t.co/rudn9kGXTi",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1250168045160390656/photo/1",
        "indices" : [ "27", "50" ],
        "url" : "https://t.co/rudn9kGXTi",
        "media_url" : "http://pbs.twimg.com/media/EVl9Kp9U0AEo4fP.jpg",
        "id_str" : "1250167993587257345",
        "id" : "1250167993587257345",
        "media_url_https" : "https://pbs.twimg.com/media/EVl9Kp9U0AEo4fP.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "960",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rudn9kGXTi"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/nNnawXl0FF",
        "expanded_url" : "https://m.youtube.com/watch?v=KHRUBp02JCU",
        "display_url" : "m.youtube.com/watch?v=KHRUBp…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1250145231309172736",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250145231309172736",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 19:33:44 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/nNnawXl0FF",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1250134512157237248/photo/1",
        "indices" : [ "2", "25" ],
        "url" : "https://t.co/EispJk1ISE",
        "media_url" : "http://pbs.twimg.com/media/EVles1-VAAAd3Vo.jpg",
        "id_str" : "1250134496067780608",
        "id" : "1250134496067780608",
        "media_url_https" : "https://pbs.twimg.com/media/EVles1-VAAAd3Vo.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/EispJk1ISE"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1250134512157237248",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250134512157237248",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 18:51:08 +0000 2020",
    "favorited" : false,
    "full_text" : "+ https://t.co/EispJk1ISE",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1250134512157237248/photo/1",
        "indices" : [ "2", "25" ],
        "url" : "https://t.co/EispJk1ISE",
        "media_url" : "http://pbs.twimg.com/media/EVles1-VAAAd3Vo.jpg",
        "id_str" : "1250134496067780608",
        "id" : "1250134496067780608",
        "media_url_https" : "https://pbs.twimg.com/media/EVles1-VAAAd3Vo.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          },
          "large" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          },
          "small" : {
            "w" : "500",
            "h" : "496",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/EispJk1ISE"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "62", "70" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/rWwLqKb389",
        "expanded_url" : "https://youtu.be/NDGxJoxNUpI",
        "display_url" : "youtu.be/NDGxJoxNUpI",
        "indices" : [ "34", "57" ]
      } ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "0",
    "id_str" : "1250132561357127680",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250132561357127680",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 18:43:23 +0000 2020",
    "favorited" : false,
    "full_text" : "Dead Prez - Hip-Hop [HQ/Explicit] https://t.co/rWwLqKb389 via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "47", "55" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/ESK3hAXadZ",
        "expanded_url" : "https://youtu.be/bf7NbRFyg3Y",
        "display_url" : "youtu.be/bf7NbRFyg3Y",
        "indices" : [ "19", "42" ]
      } ]
    },
    "display_text_range" : [ "0", "55" ],
    "favorite_count" : "0",
    "id_str" : "1250132367462797314",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250132367462797314",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 18:42:37 +0000 2020",
    "favorited" : false,
    "full_text" : "TV Static 10 Hours https://t.co/ESK3hAXadZ via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "COVID19",
        "indices" : [ "0", "8" ]
      }, {
        "text" : "NYCLockdown",
        "indices" : [ "9", "21" ]
      }, {
        "text" : "nyc",
        "indices" : [ "22", "26" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1250102412557385728",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1250102412557385728",
    "created_at" : "Tue Apr 14 16:43:35 +0000 2020",
    "favorited" : false,
    "full_text" : "#COVID19 #NYCLockdown #nyc Pandemic intel.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/SuPs9XODY7",
        "expanded_url" : "https://m.youtube.com/watch?v=ohz8_IafGwE",
        "display_url" : "m.youtube.com/watch?v=ohz8_I…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249852351143272449",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249852351143272449",
    "possibly_sensitive" : false,
    "created_at" : "Tue Apr 14 00:09:56 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/SuPs9XODY7",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/iXJtmFAkJC",
        "expanded_url" : "https://youtu.be/qZ0c0i9fLy0",
        "display_url" : "youtu.be/qZ0c0i9fLy0",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249845943509213184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249845943509213184",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 23:44:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/iXJtmFAkJC",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "127" ],
    "favorite_count" : "0",
    "id_str" : "1249843209011945476",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249843209011945476",
    "created_at" : "Mon Apr 13 23:33:36 +0000 2020",
    "favorited" : false,
    "full_text" : "I was actually losing weight in Saskatoon. They started rigorously targeting me in Regina and I gained weight. Nice try though.",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249843204788281344/video/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/nKEw9QrcZK",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1249841586562719744/pu/img/ND7xp03hdM4Q4S5T.jpg",
        "id_str" : "1249841586562719744",
        "id" : "1249841586562719744",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1249841586562719744/pu/img/ND7xp03hdM4Q4S5T.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/nKEw9QrcZK"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1249843204788281344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249843204788281344",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 23:33:35 +0000 2020",
    "favorited" : false,
    "full_text" : "It’s been like this for years. https://t.co/nKEw9QrcZK",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nathanlkoch/status/1249843204788281344/video/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/nKEw9QrcZK",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1249841586562719744/pu/img/ND7xp03hdM4Q4S5T.jpg",
        "id_str" : "1249841586562719744",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "duration_millis" : "18252",
          "variants" : [ {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1249841586562719744/pu/vid/1280x720/E_wk2XA3L1lcMs4c.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1249841586562719744/pu/vid/640x360/jpletXZMEFD1bX6X.mp4?tag=10"
          }, {
            "bitrate" : "256000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1249841586562719744/pu/vid/480x270/BVNq-Ijt9HrEHc2H.mp4?tag=10"
          }, {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1249841586562719744/pu/pl/2mE0bZP_mQ3z9Z_f.m3u8?tag=10"
          } ]
        },
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1249841586562719744",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1249841586562719744/pu/img/ND7xp03hdM4Q4S5T.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "display_url" : "pic.twitter.com/nKEw9QrcZK"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/ttyGQDXPL8",
        "expanded_url" : "https://m.youtube.com/watch?v=VmiazFHzpP8",
        "display_url" : "m.youtube.com/watch?v=VmiazF…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249794109172101121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249794109172101121",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 20:18:30 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/ttyGQDXPL8",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/SpJqyHs4Ar",
        "expanded_url" : "https://en.wikipedia.org/wiki/Guglielmo_Marconi",
        "display_url" : "en.wikipedia.org/wiki/Guglielmo…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249788060134301696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249788060134301696",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 19:54:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/SpJqyHs4Ar",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/4G54MjwzDj",
        "expanded_url" : "https://en.wikipedia.org/wiki/Stoning_of_the_Devil",
        "display_url" : "en.wikipedia.org/wiki/Stoning_o…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249786933439377411",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249786933439377411",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 19:49:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/4G54MjwzDj",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/H2ZxaN3Riz",
        "expanded_url" : "https://youtu.be/icErgB_ZmFM",
        "display_url" : "youtu.be/icErgB_ZmFM",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249786177919397889",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249786177919397889",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 19:46:59 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/H2ZxaN3Riz",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "84", "92" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/zdVB4Hrz4s",
        "expanded_url" : "https://youtu.be/TL_uiPbMTLU",
        "display_url" : "youtu.be/TL_uiPbMTLU",
        "indices" : [ "56", "79" ]
      } ]
    },
    "display_text_range" : [ "0", "117" ],
    "favorite_count" : "0",
    "id_str" : "1249769851746385920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249769851746385920",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 18:42:06 +0000 2020",
    "favorited" : false,
    "full_text" : "Bill Hicks The Infamous Loses It Chicago Showmovie file https://t.co/zdVB4Hrz4s via @YouTube the views in this videos",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/8fL8QLwSH0",
        "expanded_url" : "https://youtu.be/rHcmnowjfrQ",
        "display_url" : "youtu.be/rHcmnowjfrQ",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249752226270048256",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249752226270048256",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 17:32:04 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/8fL8QLwSH0",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/pHgoAVSCID",
        "expanded_url" : "https://youtu.be/z8ZqFlw6hYg",
        "display_url" : "youtu.be/z8ZqFlw6hYg",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249752070325862400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249752070325862400",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 17:31:27 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/pHgoAVSCID",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/347YCIs1BR",
        "expanded_url" : "https://en.wikipedia.org/wiki/Great_Architect_of_the_Universe",
        "display_url" : "en.wikipedia.org/wiki/Great_Arc…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "77" ],
    "favorite_count" : "0",
    "id_str" : "1249615429800091649",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249615429800091649",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 08:28:29 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/347YCIs1BR Inner voice \"God, I hope that niggas awake somewhere\"",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/axkrA9vj6F",
        "expanded_url" : "https://www.youtube.com/watch?v=hS7U9CbDUro",
        "display_url" : "youtube.com/watch?v=hS7U9C…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1249614667099435008",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249614667099435008",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 08:25:28 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/axkrA9vj6F",
    "lang" : "und"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ "62", "70" ],
        "id_str" : "10228272",
        "id" : "10228272"
      } ],
      "urls" : [ {
        "url" : "https://t.co/dVXcB3Mrtk",
        "expanded_url" : "https://youtu.be/iOxPsBialHY",
        "display_url" : "youtu.be/iOxPsBialHY",
        "indices" : [ "34", "57" ]
      } ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "0",
    "id_str" : "1249561995663282177",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249561995663282177",
    "possibly_sensitive" : false,
    "created_at" : "Mon Apr 13 04:56:10 +0000 2020",
    "favorited" : false,
    "full_text" : "Rich Kids Basher - English Subbed https://t.co/dVXcB3Mrtk via @YouTube",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "258" ],
    "favorite_count" : "0",
    "id_str" : "1249561841073881088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1249561841073881088",
    "created_at" : "Mon Apr 13 04:55:33 +0000 2020",
    "favorited" : false,
    "full_text" : "I’ve been over this on other platforms. Countries have agencies and cells. There is a cell that’s specifically been working for the upper class for the last 20 or so years. Irregardless of Nation. And there’s some overlap. This was planned. They do not care.",
    "lang" : "en"
  }
} ]