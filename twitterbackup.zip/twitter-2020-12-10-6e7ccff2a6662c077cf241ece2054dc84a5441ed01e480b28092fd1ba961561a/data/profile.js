window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "",
      "website" : "",
      "location" : ""
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1231001702049800192/LtkzsdRO.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1121079331357429765/1582328771"
  }
} ]